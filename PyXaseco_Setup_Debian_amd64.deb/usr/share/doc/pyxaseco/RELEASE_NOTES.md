# PyXaseco 1.3 - Production Release

Release date: 2026-10-21. Controller and Administrator Console version: 1.3.
Windows and Debian packages are unsigned. This release promotes the tested
preview14 application code without changing controller or Console behavior.

## Included

- Complete PyXaseco controller source, optional apps and TrackMania Forever
  dedicated-server templates for Windows and Linux.
- Administrator Console for multiple independent instances: registration of existing
  servers, runtime status, separate player/spectator counts, apps, configuration,
  local logs and explicit lifecycle actions through existing launchers or OS services.
- Setup with Python detection, isolated controller environments and dependency
  installation, optional standalone MariaDB setup, per-instance database provisioning
  and Basic/Advanced dedicated-server configuration.
- Instance right-click duplication with new account details, ports, database/user,
  isolated environment and management identity. Empty database by default; copying
  records is optional. The original is untouched and the copy never starts automatically.
- Full-server ZIP backups with optional SQL export and sensitive-content/consistency
  warnings. A folder-only ZIP does not contain MariaDB records.
- Ctrl/Shift selection for controller/dedicated/pair Start, Stop and Restart, reviewed
  names and separate results. Compact confirmations retain full details on request.
- Configurable Best CP Times rows and best-only personal CP updates, plus cleanup
  of lingering vote buttons after successful votes.

## Install Or Update

Use `PyXasecoSetup.exe` on Windows or `pyxaseco_1.3.0-1_amd64.deb` on Ubuntu/Debian.
See `INSTALL.md` for prerequisites, registration and configuration.

Install shared tools separately from server folders. Updating the Console does not
automatically replace existing controllers, apps, configuration, maps or databases.
Use reviewed per-instance maintenance for controller updates and keep backups first.
Existing Console inventories remain in place; installing this package starts no servers.
There are no new database migrations or runtime changes relative to preview14.

The source archive contains PyXaseco and its packaging recipes, not proprietary TMF
binaries or live-server data. Optional apps remain optional; app selection is explicit.

## Verification And Boundaries

- Compare downloaded artifact hashes with `SHA256SUMS` from the official project
  release. Hashes are integrity checks, not a verified publisher signature. Windows
  can display unknown-publisher/SmartScreen warnings; no certificate is supplied.
- Release approved by the maintainer following deployment testing. Previous code
  validation included 230 management/installer regression checks, final focused tests
  and packaged Windows startup checks. Package versions/hashes are recorded in BUILD.json;
  checks are recorded separately in source verification records. No universal OS
  certification is claimed.
- Real SQL provisioning/export/import and clean-host/service-account/reboot paths
  were not independently exercised by the build agent. Verify those paths for your
  environment before relying on unattended recovery or SQL backups.
- Duplication currently requires standard controller config.toml/.env and dedicated
  dedicated_cfg.txt / MatchSettings/MatchSettings.txt launch paths. Review copied
  custom app/API/Discord settings before starting a duplicate.
- ZIP backups contain credentials and are not encrypted. Running-instance backups
  may be inconsistent. SQL export covers tables/data, not users, triggers, routines
  or events. MariaDB client/dump tools are required for optional SQL operations.
- Linux package: amd64, Python 3.12+, kernel support for the supplied 32-bit x86
  dedicated server; optional Qt desktop dependencies are installed separately.
- OS service registration/removal is a separate explicit deployment step. TMF,
  Python, Qt and MariaDB retain their own licenses; review redistribution/source-offer
  obligations before public distribution. See TMF_TEMPLATE_NOTICE.txt and LICENSE.

Project and support: https://github.com/nilakite2/PyXaseco
