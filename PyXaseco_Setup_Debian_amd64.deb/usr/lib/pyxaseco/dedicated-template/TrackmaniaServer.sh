#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
exec "./TrackmaniaServer" /game_settings=MatchSettings/MatchSettings.txt /dedicated_cfg=dedicated_cfg.txt /nodaemon
