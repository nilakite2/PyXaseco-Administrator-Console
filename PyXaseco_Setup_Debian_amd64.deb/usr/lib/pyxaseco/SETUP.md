# PyXaseco Server Setup

See `DISTRIBUTION.md` for the graphical installation guide. This document describes
headless setup and packaging. The current package is unsigned. Existing-controller
upgrades use program maintenance rather than fresh setup.

## Windows

Double-click `PyXasecoAdministrator/PyXasecoSetup.bat`, run
`PyXasecoAdministrator/PyXasecoAdministrator.exe --setup` from the generated
package, or choose **Install new controller** in the console. The executable
contains its own GUI runtime, but the controller needs external Python 3.12+.
Keep the complete executable folder together, including `_internal` and the ZIP.

1. Choose **existing dedicated server** or **new server**. Existing mode installs
   only a new `PyXaseco/` subfolder; it does not rewrite maps, dedicated XML or
   MatchSettings. New mode copies the bundled platform executable and `GameData`
   tree into a new directory (or a chosen local replacement template). Server-prefixed
   filenames and launcher references use the instance name: `TechTest.exe` /
   `TechTest.bat` on Windows, `TechTest` / `TechTest.sh` on Linux. Service definitions
   and registry paths use that renamed executable. Only new-mode dedicated XML is configured.
2. Choose target, unique instance name, existing/shared managed Python, payload ZIP and its trusted
   SHA256. The target may be new or an existing empty folder; its parent must exist.
   Nonempty folders (including hidden entries) are refused. No existing controller is merged
   or replaced. Each installation uses a separate registry identity/environment.
   New names must be safe filenames: ASCII letters/numbers, spaces, _ . or -, starting
   with a letter/number and not ending with a dot or using a reserved Windows name.
3. Enter XML-RPC, database and MasterAdmin details. New mode also needs a
   TMF server account and distinct game/P2P/XML-RPC ports. XML-RPC stays local;
   template SuperAdmin/Admin/User passwords are replaced on the new copy.
4. Configure Basic/Advanced dedicated settings (new mode). Choose an isolated controller environment and network dependency installation
   (binary wheels only; no source-build fallback),
   optional management bridge, initial optional apps and service-definition preview.
   The GUI selects library installation and the bridge by default; headless defaults
   remain opt-in. GUI dependencies never enter the controller venv.
5. Review and confirm. Nothing starts automatically. Finish can open the console.

Database mode is `existing` (configure only), `verify` or `create`. Create mode creates
fresh database/user names and initializes tables; existing names are refused. No
firewall changes, game-service registration, TMF/WinSW download or existing-service
adoption occurs. Occupied ports and TMF account login still need acceptance checks.
Both database passwords may be empty, including the new instance user's password.
An empty value is sent as an empty password, not replaced or generated. MariaDB
must permit it; setup never changes existing account authentication. Passwordless
accounts should be restricted to local access; review displays a reminder.

Python 3.12 remains the Windows reference; newer Python 3.x interpreters are accepted.
Normal Linux interpreter/venv symlinks are supported without relaxing target-folder checks.
The isolated controller interpreter is `PyXaseco/.venv-pyxaseco/Scripts/python.exe`
on Windows or `PyXaseco/.venv-pyxaseco/bin/python` on Linux. Registry/service plans
use it. The existing `PyXaseco.bat` remains a standalone system-Python launcher;
it is not silently changed to use that environment. Generated `StartController.bat`
or `StartController.sh` uses the selected interpreter, as do service definitions.

## Additional Request Options

- `python_mode`: `existing` (default) or `managed` (Windows). In managed mode,
  `python` is a shared path ending with `python.exe`, outside the instance target.
- `database_mode`: `existing` (default), `verify`, or `create`.
- `database_admin_user`, `database_admin_password`: create-mode administrator
  credentials, used once and never saved. Supply only through private JSON/stdin.
- `database_user_host`: explicit user host, default `localhost`; no wildcard grants.
- `dedicated_settings`: allowlisted XML path/value pairs for new mode, e.g.
  `{"server_options/max_players": 64, "server_options/allow_challenge_download": true}`.
  See `pyxaseco/management/dedicated_settings.py` for all settings.

Library repair is restricted to isolated environments and pinned binary wheels.
Post-copy failures preserve the new files/registration for inspection or repair.

## Headless Linux / Windows

The distribution root's `install.py`, payload ZIP and build record are sufficient;
Qt is not imported. Verify the distribution's origin before running the entrypoint.
Use a private JSON request file (mode 600 on Linux; restricted ACL on Windows), or
standard input. Do not put passwords in command arguments or paste them into logs.

Example request structure, with actual private values supplied locally:

```json
{
  "payload": "/srv/setup/controller-payload.zip",
  "sha256": "TRUSTED_SHA256_FROM_BUILD_OR_RELEASE_RECORD",
  "mode": "existing",
  "target": "/srv/tmf/Trial1",
  "name": "Trial 1",
  "python": "/usr/bin/python3.12",
  "environment": {
    "TM_LOGIN": "SuperAdmin", "TM_IP": "127.0.0.1", "TM_PORT": "5001",
    "TM_PASSWORD": "PRIVATE_VALUE", "MASTERADMIN_LOGINS": "your_login",
    "DB_HOST": "127.0.0.1", "DB_PORT": "3306", "DB_NAME": "trial1",
    "DB_USER": "pyxaseco", "DB_PASSWORD": "PRIVATE_VALUE"
  },
  "bridge": false,
  "create_venv": true,
  "install_dependencies": false,
  "service_definitions": false,
  "disabled_apps": ["records_rpg", "records_trial", "best_cp_times", "bestfinishes"]
}
```

```sh
python3.12 -B install.py --request /private/setup.json --registry /private/instances.json
python3.12 -B install.py --request /private/setup.json --registry /private/instances.json --apply REVIEW_HASH
```

The first call previews; the second requires that exact review hash. Changes to
request, template, package or inventory require another review. `--request -`
reads JSON from standard input. New mode adds `server_port`, `p2p_port`, `DEDI_LOGIN`
and `DEDI_PASSWORD`; optional `dedicated_source` overrides the bundled template.
With no override, setup uses `dedicated-template/` beside the payload ZIP.
Linux needs Python 3.12+ plus its venv/
ensurepip support (distribution package names depend on the chosen OS repository).
No root account is required for writable user-owned installation directories.

If dependency installation was not selected, install the pinned requirements
with the new environment's Python before controller startup. Setup never contacts
the game server/DB or launches the controller to test it.

## Failure And Trust Boundaries

- Archive extraction uses a strict file allowlist, bounded size, manifest hashes,
  duplicate/case-collision and unsafe-path checks. Active credentials, instance
  identity/token, caches, logs, state and build environments are not packaged.
  The build refuses populated credential/access-list TOML values it recognizes.
  Release defaults and custom settings still need human review.
- SHA256 checks detect changed bytes. A checksum shipped beside an unsigned package
  is not independent publisher authentication; public releases need trusted identity
  and distribution/license review. No claim of code signing is made here.
- Preview is read-only. Apply takes a cooperative install lock; a small persistent
  `.pyxaseco-install.lock` file may remain. Do not use directories writable by
  untrusted users. Links/junctions are refused, not used to redirect writes.
- Failure before publication removes only installer-owned staging. Failure after
  publication (venv/pip/registration, for example) preserves the new files and reports
  partial setup explicitly. It does not recursively delete a published installation
  that might already have been edited. Inspect it before retrying/registering.
- `.env` and newly copied dedicated config receive private file permissions/ACLs.
  A future service-account installation must deliberately grant required filesystem
  access. Generating definitions does not grant it or claim service readiness.
- Only the chosen Python interpreter and optional pip run during setup. They are
  trusted executables selected by the operator. Timeout/failure output is withheld
  because third-party errors can include private paths/index credentials.

## Build

Use the isolated GUI build environment and `requirements-build.txt`, then:

```powershell
.\.venv-admin\Scripts\python.exe -B packaging/build.py --output dist/stage-e --gui
```

Omit `--gui` for a platform-neutral source/headless package. Existing output folders
are refused. The source payload is deterministic for unchanged inputs. Windows
builds the Windows GUI only; a Linux GUI binary must be built/tested on Linux.
The controller and custom-app loader remain ordinary Python source, not frozen.
This command produces a portable console. `packaging/release.py` additionally
builds the Windows Inno Setup EXE, branded shortcuts and Ubuntu/Debian DEB.

The Windows build sanitizes its library-search PATH so unrelated developer tools'
ICU/OpenSSL DLLs are not harvested. It keeps the C++ runtime supplied by the pinned
Qt wheel at the bundle root instead of an older Python runtime copy. This fixes
the observed packaged-Qt startup failure without changing the system installation.

## Release Validation Scope

Program upgrade/backup/rollback and owned-file uninstall are implemented;
see `installer_maintenance.md` (or packaged `MAINTENANCE.md`). The maintainer approved
the unsigned 1.3 production release following deployment testing. Automated checks
and that acceptance do not certify every clean-host Windows/Linux installation,
service-account ACL/ownership arrangement or OS registration/recovery/reboot path.
Code signing is not included. Third-party distribution/license obligations still
apply; see `TMF_TEMPLATE_NOTICE.txt` and the release notes.

References: [PyInstaller bundling](https://pyinstaller.org/en/stable/spec-files.html),
[external-program isolation](https://pyinstaller.org/en/stable/common-issues-and-pitfalls.html).
