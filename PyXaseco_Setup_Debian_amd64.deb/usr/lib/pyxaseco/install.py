"""Headless distribution entrypoint; verify this distribution before executing it."""

import hashlib
import json
from pathlib import Path
import sys


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    payload = root / 'controller-payload.zip'
    record = json.loads((root / 'payload-build.json').read_text(encoding='utf-8'))
    if hashlib.sha256(payload.read_bytes()).hexdigest() != record['sha256']:
        raise SystemExit('Controller payload differs from the build record')
    sys.path.insert(0, str(payload))
    if len(sys.argv) > 1 and sys.argv[1] == 'maintain':
        sys.argv.pop(1)
        from pyxaseco.management.maintenance import main
    else:
        from pyxaseco.management.installation import main
    raise SystemExit(main())
