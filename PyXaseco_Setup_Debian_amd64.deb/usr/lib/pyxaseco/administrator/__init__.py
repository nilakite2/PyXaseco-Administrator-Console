"""Optional desktop client. Importing the controller never imports Qt."""
