"""Review and retain instance launchers without changing server files or services."""

import json
from pathlib import Path

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QFormLayout, QLineEdit, QLabel,
    QPushButton, QHBoxLayout, QFileDialog, QPlainTextEdit, QMessageBox)

from .processes import LaunchProfile
from .theme import STYLE
from .workers import WorkQueue


class LaunchersDialog(QDialog):
    def __init__(self, backend, instance, profile, parent=None):
        super().__init__(parent)
        self.backend, self.instance = backend, instance
        self.work = WorkQueue(self)
        self.review = None
        self.busy = False
        self.setWindowTitle('Existing launchers - ' + instance.name)
        self.setStyleSheet(STYLE)
        self.resize(790, 660)
        layout = QVBoxLayout(self)
        note = QLabel('Use your existing batch/script launchers, or leave them blank for direct executable startup. '
            'Launchers run their existing commands under your account. Only select files you trust. '
            'Saving changes only Console preferences; nothing is started or installed as a service.')
        note.setWordWrap(True)
        layout.addWidget(note)
        form = QFormLayout()
        self.fields = {}
        for key, caption in (('controller_launcher', 'Controller batch/script (optional)'),
                ('dedicated_executable', 'Dedicated server executable'),
                ('dedicated_launcher', 'Dedicated batch/script (optional)')):
            field = self.fields[key] = QLineEdit(getattr(profile, key))
            row = QHBoxLayout()
            row.addWidget(field)
            choose = QPushButton('Browse')
            choose.clicked.connect(lambda _checked=False, f=field: self.browse(f))
            row.addWidget(choose)
            form.addRow(caption, row)
            field.textChanged.connect(self.invalidate)
        self.arguments = QPlainTextEdit('\n'.join(profile.dedicated_args))
        self.arguments.setMaximumHeight(85)
        self.arguments.textChanged.connect(self.invalidate)
        form.addRow('Direct executable arguments\n(one per line; ignored with a launcher)', self.arguments)
        form.addRow('Controller working folder', QLabel(instance.controller))
        layout.addLayout(form)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output, 1)
        row = QHBoxLayout()
        self.preview_button = QPushButton('Review launchers')
        self.preview_button.clicked.connect(self.prepare)
        self.save_button = QPushButton('Save reviewed launchers')
        self.save_button.setObjectName('primary')
        self.save_button.setEnabled(False)
        self.save_button.clicked.connect(self.save)
        self.close_button = QPushButton('Close')
        self.close_button.clicked.connect(self.reject)
        for button in (self.preview_button, self.save_button, self.close_button):
            row.addWidget(button)
        layout.addLayout(row)

    def browse(self, field):
        path = QFileDialog.getOpenFileName(self, 'Existing executable or launcher')[0]
        if path:
            field.setText(path)

    def collect(self):
        return LaunchProfile(**{key: value.text() for key, value in self.fields.items()},
            dedicated_args=tuple(line for line in self.arguments.toPlainText().splitlines() if line))

    def invalidate(self):
        self.review = None
        self.save_button.setEnabled(False)

    def active(self, busy):
        self.busy = busy
        for field in (*self.fields.values(), self.arguments, self.close_button, self.preview_button):
            field.setEnabled(not busy)
        self.save_button.setEnabled(not busy and self.review is not None)

    def prepare(self):
        profile = self.collect()
        self.active(True)
        def done(value, error):
            self.review = value
            self.output.setPlainText(error or json.dumps(value, indent=2))
            self.active(False)
        self.work.submit('review', lambda: self.backend.preview_launchers(self.instance, profile), done, priority=1)

    def save(self):
        if not self.review or QMessageBox.question(self, 'Save launchers',
                'Save these launch settings for ' + self.instance.name + '? Nothing will start.') != QMessageBox.StandardButton.Yes:
            return
        profile, stamp = self.collect(), self.review['review']
        self.active(True)
        def done(value, error):
            self.output.setPlainText(error or 'Launch settings saved. No server files changed and nothing started.')
            self.review = None
            self.active(False)
        self.work.submit('save', lambda: self.backend.save_launchers(self.instance, profile, reviewed=stamp), done, priority=1)

    def reject(self):
        if not self.busy:
            self.work.close()
            super().reject()

    def closeEvent(self, event):
        if self.busy:
            event.ignore()
        else:
            self.work.close()
            event.accept()
