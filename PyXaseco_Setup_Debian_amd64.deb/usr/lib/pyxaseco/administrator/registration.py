"""Register a working installation using detected paths; never change its files."""

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
    QGroupBox, QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget)

from .discovery import inspect_installation, probe_python
from .workers import WorkQueue


class RegisterDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.work = WorkQueue(self)
        self.generation = 0
        self.inspected = ''
        self.manual_python = self.manual_dedicated = False
        self.manual_name = False
        self.checking = False
        self.setWindowTitle('Register an existing server')
        self.resize(710, 340)
        layout = QVBoxLayout(self)
        note = QLabel('Choose the existing server or PyXaseco folder. Registration does not install, overwrite or start anything.')
        note.setWordWrap(True)
        layout.addWidget(note)
        form = QFormLayout()
        self.folder, self.name = QLineEdit(), QLineEdit()
        self.name.textEdited.connect(lambda: setattr(self, 'manual_name', True))
        row = QHBoxLayout()
        row.addWidget(self.folder)
        pick = QPushButton('Browse')
        pick.clicked.connect(lambda: self.browse(self.folder, True))
        row.addWidget(pick)
        form.addRow('Existing server folder', row)
        form.addRow('Display name', self.name)
        layout.addLayout(form)
        self.status = QLabel('Python and the dedicated executable will be detected from this instance.')
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        advanced = QGroupBox('Advanced paths (override detection)')
        advanced.setCheckable(True)
        advanced.setChecked(False)
        outer = QVBoxLayout(advanced)
        content = QWidget()
        details = QFormLayout(content)
        outer.addWidget(content)
        content.hide()
        advanced.toggled.connect(content.setVisible)
        self.python, self.dedicated = QLineEdit(), QLineEdit()
        for caption, field in (('Python program', self.python), ('Dedicated executable (optional)', self.dedicated)):
            row = QHBoxLayout()
            row.addWidget(field)
            pick = QPushButton('Browse')
            pick.clicked.connect(lambda _checked=False, f=field: self.browse(f, False))
            row.addWidget(pick)
            details.addRow(caption, row)
        self.python.textEdited.connect(lambda: setattr(self, 'manual_python', True))
        self.dedicated.textEdited.connect(lambda: setattr(self, 'manual_dedicated', True))
        layout.addWidget(advanced)
        self.actions = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.actions.button(QDialogButtonBox.StandardButton.Ok).setText('Register server')
        self.actions.accepted.connect(self.accept)
        self.actions.rejected.connect(self.reject)
        layout.addWidget(self.actions)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(350)
        self.timer.timeout.connect(self.inspect)
        self.folder.textChanged.connect(self.folder_changed)
        self.ready(False)

    def ready(self, ready):
        self.actions.button(QDialogButtonBox.StandardButton.Ok).setEnabled(ready)

    def folder_changed(self):
        self.generation += 1
        self.inspected = ''
        self.ready(False)
        self.timer.start()

    def browse(self, field, directory):
        path = QFileDialog.getExistingDirectory(self, 'Existing server folder') if directory else QFileDialog.getOpenFileName(self, 'Existing executable or launcher')[0]
        if path:
            field.setText(path)
            if field is self.python:
                self.manual_python = True
            elif field is self.dedicated:
                self.manual_dedicated = True

    def inspect(self):
        folder, generation = self.folder.text(), self.generation
        if not folder:
            return
        self.status.setText('Inspecting existing paths and Python...')
        def done(value, error):
            if generation != self.generation:
                return
            if error:
                self.status.setText(error)
                return
            self.inspected = folder
            if not self.manual_name:
                self.name.setText(value['name'])
            if not self.manual_python:
                self.python.setText(value['python']['python'] if value['python'] else '')
            if not self.manual_dedicated:
                self.dedicated.setText(value['dedicated'])
            python = value['python']
            self.status.setText('XML-RPC: ' + value['xmlrpc'] + '\n' +
                ('Python ' + python['version'] + ': ' + python['python'] if python else
                 'No compatible Python found. Choose its location under Advanced paths.') + '\n' +
                ('Dedicated: ' + value['dedicated'] if value['dedicated'] else
                 'Dedicated executable is optional; select it under Advanced paths to enable its controls.'))
            if not value.get('management_support', True):
                self.status.setText(self.status.text() + '\nOlder controller: read-only until the Console support update is applied.')
            elif not value.get('connection_discovered', True):
                self.status.setText(self.status.text() + '\nConsole connection not discovered. Enable it later through Server actions > Python and database checks.')
            self.ready(True)
        self.work.submit('inspect:' + str(generation), lambda: inspect_installation(folder), done)

    def accept(self):
        if self.checking or self.inspected != self.folder.text():
            return
        python, generation = self.python.text(), self.generation
        self.checking = True
        self.ready(False)
        for field in (self.folder, self.name, self.python, self.dedicated):
            field.setEnabled(False)
        def done(value, error):
            self.checking = False
            for field in (self.folder, self.name, self.python, self.dedicated):
                field.setEnabled(True)
            if generation != self.generation:
                return
            if error:
                self.status.setText(error)
                self.ready(True)
            else:
                self.timer.stop()
                self.work.close()
                super(RegisterDialog, self).accept()
        self.work.submit('validate-python', lambda: probe_python(python), done, priority=1)

    def reject(self):
        self.timer.stop()
        self.work.close()
        super().reject()

    def closeEvent(self, event):
        self.reject()
        event.accept()
