"""Instance-scoped manual launchers and graceful control, never process-name kills."""

import asyncio
from dataclasses import asdict, dataclass, replace
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time
import tomllib

from pyxaseco.management.config_store import ManagementError, file_lock, runtime_lock
from pyxaseco.management.instances import configured_endpoint, read_dotenv
from pyxaseco.management.runtime_client import RuntimeClient


DEFAULT_ARGS = ('/game_settings=MatchSettings/MatchSettings.txt', '/dedicated_cfg=dedicated_cfg.txt')


def launch_summary(review):
    """Compact display only; paths outside the instance stay fully qualified."""
    controller = Path(review['controller'])
    root = controller.parent
    profile = review['profile']

    def short(value):
        if not value:
            return 'Not configured'
        path = Path(value)
        try:
            return str(path.relative_to(root))
        except ValueError:
            return str(path)

    def arguments(values):
        if not values:
            return '(none)'
        if os.name == 'nt':
            return subprocess.list2cmdline(list(values))
        import shlex
        return shlex.join(values)

    config = short(review['config'])
    dedicated_args = tuple(profile['dedicated_args'])
    if os.name != 'nt' and profile['dedicated_executable'] and not profile['dedicated_launcher']:
        dedicated_args += ('/nodaemon',)
    environment = review.get('environment_files', [])
    if environment:
        config = ', '.join(short(path) for path in environment) + ' (overrides ' + config + ')'
    lines = ['Parent path: ' + str(root.parent), 'Server folder: ' + (root.name or str(root)),
             'Python: ' + review['python'], '', 'Dedicated server:',
             '  Server: ' + (short(profile['dedicated_launcher']) if profile['dedicated_launcher'] else
                            'Direct launch' if profile['dedicated_executable'] else 'Not configured'),
             '  Executable: ' + short(profile['dedicated_executable']),
             '  Arguments: ' + ('supplied by the existing launcher' if profile['dedicated_launcher'] else
                               arguments(dedicated_args) if profile['dedicated_executable'] else '(none)')]
    dedicated_folder = review.get('dedicated_working_folder')
    if dedicated_folder and Path(dedicated_folder) != root:
        lines.append('  Working folder: ' + short(dedicated_folder))
    lines.extend(['', 'Controller:', '  Config: ' + config,
                  '  Executable: ' + (short(profile['controller_launcher']) if profile['controller_launcher'] else 'Python (above)'),
                  '  Arguments: ' + ('supplied by the existing launcher' if profile['controller_launcher'] else
                      arguments(('-u', '-B', short(controller / 'main.py'), short(review['config']))))])
    if profile['controller_launcher'] and Path(profile['controller_launcher']).parent != controller:
        lines.append('  Working folder: ' + short(controller))
    return '\n'.join(lines)


def _psutil():
    try:
        import psutil
        return psutil
    except ImportError as exc:
        raise ManagementError('Manual process controls require the updated Administrator Console (psutil).') from exc


def _path(value, cwd=None):
    path = Path(value)
    return os.path.normcase(str((Path(cwd) / path if cwd and not path.is_absolute() else path).resolve()))


@dataclass(frozen=True)
class LaunchProfile:
    controller_launcher: str = ''
    dedicated_executable: str = ''
    dedicated_launcher: str = ''
    dedicated_args: tuple = DEFAULT_ARGS

    @classmethod
    def defaults(cls, instance):
        dedicated = Path(instance.dedicated) if instance.dedicated else None
        if dedicated and dedicated.suffix.lower() in {'.bat', '.cmd', '.sh'}:
            native = dedicated.with_suffix('.exe' if os.name == 'nt' else '')
            return cls(dedicated_executable=str(native), dedicated_launcher=str(dedicated))
        launcher = (dedicated.with_suffix('.bat') if os.name == 'nt' else Path(str(dedicated) + '.sh')) if dedicated else None
        return cls(dedicated_executable=str(dedicated or ''),
                   dedicated_launcher=str(launcher) if launcher and launcher.is_file() else '')

    @classmethod
    def read(cls, instance, data=None):
        if data is None:
            return cls.defaults(instance)
        if not isinstance(data, dict) or data.keys() - cls.__dataclass_fields__.keys():
            raise ManagementError('Invalid launcher profile')
        profile = cls(**data)
        if not isinstance(profile.dedicated_args, (tuple, list)):
            raise ManagementError('Dedicated arguments must be a list')
        return replace(profile, dedicated_args=tuple(profile.dedicated_args))

    def validate(self, instance):
        if not Path(instance.python).is_file() or not Path(instance.config).is_file():
            raise ManagementError('Registered controller Python/configuration is missing')
        for launcher in (self.controller_launcher, self.dedicated_launcher):
            if launcher:
                file = Path(launcher)
                expected = {'.bat', '.cmd'} if os.name == 'nt' else {'.sh'}
                if not file.is_absolute() or not file.is_file() or file.suffix.lower() not in expected:
                    raise ManagementError('Choose an existing local batch file' if os.name == 'nt' else 'Choose an existing local shell script')
                if os.name == 'nt' and any(char in str(file) for char in '%!&|<>^"\r\n'):
                    raise ManagementError('Batch launcher paths cannot contain shell expansion characters')
        if self.dedicated_executable:
            file = Path(self.dedicated_executable)
            if not file.is_absolute() or not file.is_file() or os.name == 'nt' and file.suffix.lower() != '.exe':
                raise ManagementError('Dedicated process identification needs its actual executable, not the batch file')
        if self.dedicated_launcher and not self.dedicated_executable:
            raise ManagementError('Choose the dedicated executable as well as its launcher')
        for argument in self.dedicated_args:
            if not isinstance(argument, str) or any(ord(char) < 32 for char in argument):
                raise ManagementError('Invalid dedicated launch argument')
        return self

    def review(self, instance):
        self.validate(instance)
        scripts = {}
        for name in (self.controller_launcher, self.dedicated_launcher):
            if name:
                path = Path(name)
                if path.stat().st_size > 65536:
                    raise ManagementError('Launcher exceeds the 64 KiB review limit')
                scripts[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        value = {'instance': instance.id, 'controller': instance.controller, 'python': instance.python,
                 'config': instance.config, 'profile': asdict(self), 'launcher_hashes': scripts}
        candidates = (Path(instance.config).parent / '.env', Path(instance.controller) / '.env')
        value['environment_files'] = list(dict.fromkeys(str(path) for path in candidates if path.is_file()))
        stamp = hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
        return {'review': stamp, **value, 'controller_launch': self.controller_launcher or
                'Registered Python + main.py + registered config',
                'dedicated_launch': self.dedicated_launcher or 'Executable with the reviewed arguments',
                'controller_working_folder': instance.controller,
                'dedicated_working_folder': str(Path(self.dedicated_launcher or self.dedicated_executable).parent)
                    if self.dedicated_executable else '', 'starts_nothing': True}


class LocalProcesses:
    def __init__(self):
        self.lock = threading.Lock()
        self.at, self.rows = 0, []
        self.children = []
        self.paths = {}

    def resolved(self, value, cwd=None):
        # Share filesystem resolution across every instance in this snapshot only.
        key = (str(value), str(cwd) if cwd else None)
        with self.lock:
            if key not in self.paths:
                self.paths[key] = _path(value, cwd)
            return self.paths[key]

    def snapshot(self, *, fresh=False):
        ps = _psutil()
        with self.lock:
            if fresh or time.monotonic() - self.at > 2:
                ps.process_iter.cache_clear()
                self.rows = []
                self.paths.clear()
                attributes = ['pid', 'name', 'exe', 'cwd', 'cmdline', 'create_time']
                # Windows has no zombies; status() otherwise enumerates all process threads.
                if os.name != 'nt':
                    attributes.append('status')
                for process in ps.process_iter(attributes, ad_value=None):
                    self.rows.append(process.info)
                self.at = time.monotonic()
                self.children = [child for child in self.children if child.poll() is None]
            return list(self.rows)

    @staticmethod
    def _script(arguments):
        index = 1
        while index < len(arguments):
            item = arguments[index]
            if item in {'-c', '-m'}:
                return None
            if item in {'-X', '-W', '--check-hash-based-pycs'}:
                index += 2
            elif item.startswith('-'):
                index += 1
            else:
                return item
        return None

    def inspect(self, instance, profile, target, *, fresh=False):
        expected = instance.python if target == 'controller' else profile.dedicated_executable
        if not expected or not Path(expected).is_file():
            return {'state': 'not-configured', 'reason': 'Choose the actual executable in Configure launchers'}
        matches, uncertain = [], False
        snapshot = self.snapshot(fresh=fresh)
        expected_path = self.resolved(expected)
        expected_script = self.resolved(Path(instance.controller) / 'main.py') if target == 'controller' else None
        expected_config = self.resolved(instance.config) if target == 'controller' else None
        for row in snapshot:
            if row.get('status') == 'zombie':
                continue
            command = row.get('cmdline')
            executable = row.get('exe')
            if not executable:
                if (row.get('name') or '').lower() == Path(expected).name.lower():
                    uncertain = True
                continue
            same = self.resolved(executable) == expected_path
            if target == 'controller':
                same = same or bool(command and self.resolved(command[0]) == expected_path)
                if not same:
                    continue
                script = self._script(command) if command else None
                if not command or script and not Path(script).is_absolute() and not row.get('cwd'):
                    uncertain = True
                    continue
                if not script or self.resolved(script, row.get('cwd')) != expected_script:
                    continue
                if '--supervised' in command or '--service-plan' in command:
                    return {'state': 'service-managed', 'reason': 'Attach its OS service plan; do not use manual process controls'}
                tail = command[command.index(script) + 1:]
                config = next((item for item in tail if not item.startswith('-')), 'config.toml')
                if not Path(config).is_absolute() and not row.get('cwd'):
                    uncertain = True
                    continue
                if self.resolved(config, row.get('cwd')) != expected_config:
                    continue
            elif not same:
                continue
            if row.get('create_time') is None:
                uncertain = True
            else:
                matches.append({'pid': row['pid'], 'created': row['create_time'], 'executable': executable})
        if len(matches) > 1:
            return {'state': 'ambiguous', 'reason': 'More than one matching process; no automatic action is safe'}
        if uncertain:
            return {'state': 'unknown', 'reason': 'Process access is incomplete; no start/stop guess will be made'}
        return {'state': 'running', **matches[0]} if matches else {'state': 'stopped'}

    @staticmethod
    def alive(identity):
        ps = _psutil()
        try:
            process = ps.Process(identity['pid'])
            return (process.create_time() == identity['created'] and process.is_running()
                    and process.status() != ps.STATUS_ZOMBIE)
        except ps.NoSuchProcess:
            return False
        except ps.AccessDenied as exc:
            raise ManagementError('Cannot verify the original process; no replacement process will be started') from exc

    def status(self, instance, profile):
        return {'controller': self.inspect(instance, profile, 'controller'),
                'dedicated': self.inspect(instance, profile, 'dedicated'),
                'management': 'process', 'plan_attached': False,
                'owns_dedicated': bool(profile.dedicated_executable),
                'startup': 'Existing launcher / manual; no OS service installed'}

    @staticmethod
    def _bridge(instance):
        client = RuntimeClient(instance.controller)
        if client.instance_id != instance.id:
            raise ManagementError('Controller connection belongs to a different registered instance')
        return client

    def _controller_command(self, instance, kind):
        async def request():
            async with self._bridge(instance) as client:
                status = await client.status()
                await client.submit({'kind': kind})
                return status['context']['run_id']
        return asyncio.run(request())

    def _wait_exit(self, identity, timeout=45):
        deadline = time.monotonic() + timeout
        while self.alive(identity):
            if time.monotonic() >= deadline:
                raise ManagementError('Graceful shutdown timed out. No process was forcibly killed or restarted')
            time.sleep(.2)

    @staticmethod
    def _rpc_settings(instance):
        root = Path(instance.controller)
        env, config = read_dotenv(root / '.env'), tomllib.loads(Path(instance.config).read_text(encoding='utf-8'))
        tm = config.get('tmserver', {})
        host, port = configured_endpoint(root)
        if host not in {'127.0.0.1', 'localhost', '::1'}:
            raise ManagementError('Local process control requires a local XML-RPC endpoint')
        return host, port, env.get('TM_LOGIN') or tm.get('login') or 'SuperAdmin', env.get('TM_PASSWORD') or tm.get('password', '')

    def _verify_rpc_owner(self, instance, identity):
        host, port, _login, _password = self._rpc_settings(instance)
        if not self.alive(identity):
            raise ManagementError('Dedicated process changed before the request; refresh status')
        ps = _psutil()
        try:
            listeners = ps.Process(identity['pid']).net_connections(kind='tcp')
        except (ps.AccessDenied, ps.NoSuchProcess) as exc:
            raise ManagementError('Cannot verify which process owns the XML-RPC port; no stop request sent') from exc
        if not any(row.status == ps.CONN_LISTEN and row.laddr.port == port
                   and row.laddr.ip in {host, '0.0.0.0', '::'} for row in listeners):
            raise ManagementError('XML-RPC port does not belong to the selected dedicated executable; no stop request sent')

    def _stop_dedicated(self, instance, identity):
        self._verify_rpc_owner(instance, identity)
        async def stop():
            from pyxaseco.core.gbx_client import GbxClient, GbxError
            host, port, login, password = self._rpc_settings(instance)
            client = GbxClient()
            try:
                async with asyncio.timeout(12):
                    await client.connect(host, port, timeout=5)
                    await client.authenticate(login, password)
                    self._verify_rpc_owner(instance, identity)
                    try:
                        stopped = await client.query('StopServer')
                    except GbxError:
                        if self.alive(identity):
                            raise ManagementError('Dedicated StopServer request was not confirmed; inspect the server') from None
                        return
                    if stopped is not True:
                        raise ManagementError('Dedicated server refused StopServer; no forced termination issued')
                    await asyncio.sleep(2)
                    if self.alive(identity):
                        try:
                            await client.query('QuitGame')
                        except GbxError:
                            pass  # The server may close the connection before replying.
            finally:
                await client.disconnect()
        try:
            asyncio.run(stop())
        except ManagementError:
            raise
        except Exception as exc:
            raise ManagementError('Dedicated shutdown failed (' + type(exc).__name__ + '); credentials/details omitted') from exc
        self._wait_exit(identity)

    def _launch(self, instance, profile, target):
        from pyxaseco.management.installation import _spawn
        launcher = profile.controller_launcher if target == 'controller' else profile.dedicated_launcher
        cwd = Path(instance.controller) if target == 'controller' else Path(launcher or profile.dedicated_executable).parent
        if launcher and os.name == 'nt':
            shell = str(Path(os.environ.get('SystemRoot', 'C:/Windows')) / 'System32/cmd.exe')
            command = subprocess.list2cmdline([shell]) + ' /d /s /c ""' + launcher + '""'
        elif launcher:
            command = ['/bin/sh', launcher]
        elif target == 'controller':
            command = [instance.python, '-u', '-B', str(Path(instance.controller) / 'main.py'), instance.config]
        else:
            command = [profile.dedicated_executable, *profile.dedicated_args]
            if os.name != 'nt':
                command.append('/nodaemon')
        options = dict(cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=False)
        if os.name == 'nt':
            options['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
        else:
            options['start_new_session'] = True
        try:
            child = _spawn(command, **options)
        except OSError as exc:
            raise ManagementError('Could not launch the selected component (' + type(exc).__name__ + ')') from exc
        with self.lock:
            self.children.append(child)
        self.at = 0
        return child

    def _start(self, instance, profile, target):
        state = self.inspect(instance, profile, target, fresh=True)
        if state['state'] == 'running':
            if target == 'dedicated':
                self._verify_rpc_owner(instance, state)
            return state
        if state['state'] != 'stopped':
            raise ManagementError(state.get('reason', 'Component is not ready for manual startup'))
        if target == 'controller':
            source = (Path(instance.controller) / 'main.py').read_text(encoding='utf-8-sig')
            if 'MANAGEMENT_RUNTIME_LOCK = 1' not in source:
                raise ManagementError('Install the Console compatibility support before starting this controller here')
            with runtime_lock(Path(instance.controller)):
                pass  # The child acquires the same lock itself; do not race it while spawning.
            child = self._launch(instance, profile, target)
        else:
            child = self._launch(instance, profile, target)
        deadline = time.monotonic() + 45
        while time.monotonic() < deadline:
            state = self.inspect(instance, profile, target, fresh=True)
            if state['state'] == 'running':
                if target == 'dedicated':
                    try:
                        self._verify_rpc_owner(instance, state)
                    except ManagementError:
                        time.sleep(.2)
                        continue
                return state
            if child.poll() not in (None, 0):
                raise ManagementError('Launcher exited with code ' + str(child.returncode) + '; inspect the component logs')
            time.sleep(.2)
        raise ManagementError('Startup was not confirmed within 45 seconds. No second copy was launched; inspect logs before retrying')

    def _stop(self, instance, profile, target):
        state = self.inspect(instance, profile, target, fresh=True)
        if state['state'] == 'stopped':
            return
        if state['state'] != 'running':
            raise ManagementError(state.get('reason', 'Cannot identify this process safely'))
        if target == 'controller':
            self._controller_command(instance, 'controller.stop')
            self._wait_exit(state)
        else:
            self._stop_dedicated(instance, state)

    def action(self, instance, profile, target, action, *, reviewed):
        if target not in {'controller', 'dedicated', 'both'} or action not in {'start', 'stop', 'restart'}:
            raise ManagementError('Manual processes support Start, Stop and Restart only')
        if profile.review(instance)['review'] != reviewed:
            raise ManagementError('Launcher/profile changed after confirmation; review it again')
        if target in {'dedicated', 'both'} and not profile.dedicated_executable:
            raise ManagementError('Configure the dedicated executable and launcher first')
        root = Path(instance.controller)
        with file_lock(root / '.pyxaseco-launcher.lock'):
            if action == 'restart' and target == 'controller':
                state = self.inspect(instance, profile, 'controller', fresh=True)
                if state['state'] == 'stopped':
                    self._start(instance, profile, 'controller')
                elif state['state'] != 'running':
                    raise ManagementError(state.get('reason', 'Cannot identify this controller'))
                else:
                    old_run = self._controller_command(instance, 'controller.restart')
                    deadline = time.monotonic() + 45
                    while time.monotonic() < deadline:
                        try:
                            async def status():
                                async with self._bridge(instance) as client:
                                    return await client.status()
                            current = asyncio.run(status())
                            if current['context']['run_id'] != old_run:
                                break
                        except (ManagementError, OSError, ValueError):
                            pass
                        time.sleep(.3)
                    else:
                        raise ManagementError('Controller restart not confirmed; no duplicate process was launched')
            else:
                steps = []
                if action in {'stop', 'restart'}:
                    for component in (('controller', 'dedicated') if target == 'both' else (target,)):
                        steps.append(('stop', component))
                if action in {'start', 'restart'}:
                    for component in (('dedicated', 'controller') if target == 'both' else (target,)):
                        steps.append(('start', component))
                completed = []
                for operation, component in steps:
                    try:
                        if operation == 'start':
                            if profile.review(instance)['review'] != reviewed:
                                raise ManagementError('Launcher changed during the operation; review again before starting')
                            self._start(instance, profile, component)
                        else:
                            self._stop(instance, profile, component)
                    except Exception as exc:
                        detail = str(exc) if isinstance(exc, ManagementError) else 'Operation failed (' + type(exc).__name__ + ')'
                        prefix = 'Completed: ' + ', '.join(completed) + '. Remaining steps cancelled. ' if completed else ''
                        raise ManagementError(prefix + detail) from exc
                    completed.append(operation + ' ' + component)
        return {'action': action, 'target': target, 'management': 'process',
                'completed': True, 'force_killed': False, 'runtime_ready': 'Check the live controller status'}
