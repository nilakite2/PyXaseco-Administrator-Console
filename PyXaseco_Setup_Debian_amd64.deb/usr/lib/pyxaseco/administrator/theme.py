"""PyXaseco's supplied electric-blue/graphite desktop identity."""

import os
from pathlib import Path


def configure_font(app):
    from PySide6.QtGui import QFont, QFontDatabase
    if not QFontDatabase.families():
        # The Windows offscreen platform has no native font database.
        candidates = [Path(os.environ.get('SystemRoot', 'C:/Windows')) / 'Fonts/bahnschrift.ttf',
                      Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')]
        for path in candidates:
            if path.is_file():
                QFontDatabase.addApplicationFont(str(path))
    family = next((name for name in ('Bahnschrift', 'Noto Sans', 'DejaVu Sans')
                   if name in QFontDatabase.families()), 'Sans Serif')
    app.setFont(QFont(family, 10))

STYLE = """
QWidget { color: #e3ebf5; font-size: 14px; }
QMainWindow, QDialog { background: #101824; }
QScrollArea, QWidget#setupPage { background: #101824; }
QWidget#sidebar { background: #090f19; border-right: 1px solid #24354b; }
QFrame#hero { background: qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #162c48,stop:1 #0b1421);
 border: 1px solid #284669; border-radius: 12px; }
QFrame#card { background: #172536; border: 1px solid #2a3d55; border-radius: 8px; }
QLabel#heading { font-size: 27px; font-weight: bold; }
QLabel#cardValue { font-size: 22px; font-weight: bold; color: #67bcff; }
QLabel#muted { color: #9cacc0; }
QLabel#eyebrow { color: #77bfff; font-size: 12px; font-weight: bold; }
QPushButton { background: #22344b; border: 1px solid #395674; padding: 8px 13px; border-radius: 5px; }
QPushButton:hover { background: #2b496a; border-color: #63b6ff; }
QPushButton:pressed { background: #0757a4; }
QPushButton#primary { background: #0768cd; border-color: #308df0; font-weight: bold; }
QPushButton#danger { color: #ffbcaa; border-color: #98533f; }
QPushButton:disabled { color: #65758a; background: #17212e; border-color: #2b3745; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTreeWidget, QTableWidget, QListWidget {
 background: #101d2c; border: 1px solid #2a4058; border-radius: 5px; padding: 5px;
 selection-background-color: #164f83; selection-color: #ffffff; }
QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus { border-color: #399aff; }
QComboBox QAbstractItemView { background: #172536; selection-background-color: #164f83; }
QMenu { background: #142234; border: 1px solid #395674; padding: 5px; }
QMenu::item { padding: 7px 25px 7px 12px; }
QMenu::item:selected { background: #214466; }
QMenu::item:disabled { color: #65758a; }
QMenu::separator { height: 1px; background: #2a4058; margin: 5px; }
QListWidget { background: transparent; border: none; }
QListWidget::item { padding: 12px 6px; border-bottom: 1px solid #19273a; }
QListWidget::item:selected { background: #14395c; border-left: 3px solid #35a1ff; }
QHeaderView::section { background: #1e3249; padding: 8px; border: 0; color: #a9c8e7; font-weight: bold; }
QTableWidget, QTreeWidget { gridline-color: #24354b; alternate-background-color: #132235; }
QTabWidget::pane { border: 1px solid #2a4058; border-radius: 6px; padding: 8px; }
QTabBar::tab { background: #152132; color: #a4b6ca; padding: 11px 18px; margin-right: 4px; }
QTabBar::tab:selected { color: #ffffff; background: #214466; border-bottom: 3px solid #2f9eff; }
QCheckBox { spacing: 8px; }
QGroupBox { border: 1px solid #2a4058; border-radius: 5px; margin-top: 9px; padding-top: 12px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; color: #9cacc0; }
QSplitter::handle { background: #23364c; width: 2px; }
QStatusBar { background: #0b1420; color: #9cacc0; }
QScrollBar:vertical { background: #101824; width: 11px; }
QScrollBar::handle:vertical { background: #375472; border-radius: 4px; min-height: 24px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
"""
