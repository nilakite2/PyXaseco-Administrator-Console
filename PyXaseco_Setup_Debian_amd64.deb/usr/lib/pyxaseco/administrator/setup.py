"""Review-first fresh setup over the same installer used by the headless CLI."""

import json
import os
from pathlib import Path
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog,
    QFormLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
    QPushButton, QScrollArea, QTabWidget, QVBoxLayout, QWidget, QGroupBox, QSpinBox, QDoubleSpinBox)

from pyxaseco.management.installation import InstallRequest, apply, preview
from .theme import STYLE
from .workers import WorkQueue


ASSETS = Path(__file__).parent / 'assets'


def payload_defaults():
    root = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parents[1]
    for package in (root, root / 'dist'):
        payload, record = package / 'controller-payload.zip', package / 'payload-build.json'
        if payload.is_file() and record.is_file():
            try:
                return str(payload), json.loads(record.read_text())['sha256']
            except (OSError, ValueError, KeyError):
                pass
    return '', ''


class SetupDialog(QDialog):
    def __init__(self, backend, parent=None):
        super().__init__(parent)
        self.backend = backend
        self.work = WorkQueue(self)
        self.review = None
        self.request = None
        self.receipt = None
        self.busy = False
        self.python_detecting = True
        self.detected_python = None
        self.auto_python_mode = 'managed' if os.name == 'nt' else 'existing'
        self.setWindowTitle('PyXaseco Setup 1.3')
        self.setWindowIcon(QIcon(str(ASSETS / 'PyXaseco_Logo.png')))
        self.setStyleSheet(STYLE)
        self.resize(840, 790)
        layout = QVBoxLayout(self)
        banner = QLabel()
        banner.setPixmap(QPixmap(str(ASSETS / 'PyXaseco_Banner.png')).scaledToWidth(480, Qt.TransformationMode.SmoothTransformation))
        layout.addWidget(banner)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self.fields = {}
        paths = self.page('Installation')
        self.mode = QComboBox()
        self.mode.addItem('Install PyXaseco for an existing dedicated server', 'existing')
        self.mode.addItem('New server - deploy bundled TrackMania dedicated server', 'new')
        paths.addRow('Installation mode', self.mode)
        advanced = QGroupBox('Advanced settings')
        advanced.setCheckable(True)
        advanced.setChecked(False)
        advanced_layout = QVBoxLayout(advanced)
        advanced_content = QWidget()
        advanced_form = QFormLayout(advanced_content)
        advanced_layout.addWidget(advanced_content)
        advanced_content.hide()
        advanced.toggled.connect(advanced_content.setVisible)
        self.python_mode = QComboBox()
        self.python_mode.addItem('Automatic - find Python or set it up for me', 'auto')
        self.python_mode.addItem('Use an existing Python 3.12+ installation', 'existing')
        if os.name == 'nt':
            self.python_mode.addItem('Install a shared PyXaseco Python runtime', 'managed')
        advanced_form.addRow('Python selection', self.python_mode)
        for key, caption, browse in (
                ('target', 'Dedicated-server folder / new target', 'directory'),
                ('name', 'Instance name / new server filename', ''),
                ('python', 'Python interpreter', 'file')):
            field = QLineEdit()
            self.fields[key] = field
            if browse:
                row = QHBoxLayout()
                row.addWidget(field)
                pick = QPushButton('Browse')
                pick.clicked.connect(lambda _checked=False, f=field, d=browse == 'directory': self.browse(f, d))
                row.addWidget(pick)
                target_form = advanced_form if key == 'python' else paths
                target_form.addRow(caption, row)
                if key == 'python':
                    self.python_browse = pick
                    self.python_label = advanced_form.labelForField(row)
            else:
                paths.addRow(caption, field)
        if not getattr(sys, 'frozen', False):
            self.fields['python'].setText(getattr(sys, '_base_executable', sys.executable))
        self.existing_python = self.fields['python'].text()
        self.fields['python'].textEdited.connect(lambda text: setattr(self, 'existing_python', text))
        self.python_note = self.note('')
        paths.addRow(self.python_note)
        for key, caption in (('dedicated_source', 'Dedicated-server template'),
                             ('payload', 'Controller package'), ('sha256', 'Package SHA256')):
            field = self.fields[key] = QLineEdit()
            advanced_form.addRow(caption, field)
        paths.addRow(advanced)
        payload, digest = payload_defaults()
        self.fields['payload'].setText(payload)
        self.fields['sha256'].setText(digest)
        if payload and (Path(payload).parent / 'dedicated-template').is_dir():
            self.fields['dedicated_source'].setText(str(Path(payload).parent / 'dedicated-template'))
        self.fields['name'].setPlaceholderText('e.g. TechTest')
        self.fields['name'].setToolTip('New server filenames use this name. Letters, numbers, spaces, _, . and - are supported.')
        paths.addRow(self.note('Create a new server or connect PyXaseco to an existing dedicated server. '
            'Choose a new or empty folder for a new server. Existing server files are preserved.'))
        prerequisites = QPushButton('Check Python libraries and database service...')
        prerequisites.clicked.connect(self.prerequisites)
        advanced_form.addRow(prerequisites)
        connection = self.page('Connection')
        self.database_mode = QComboBox()
        for text, value in (('Use an existing database (configure only)', 'existing'),
                            ('Verify an existing database connection', 'verify'),
                            ('Create a new database and instance-specific user', 'create')):
            self.database_mode.addItem(text, value)
        connection.addRow('Database setup', self.database_mode)
        defaults = {'TM_LOGIN': 'SuperAdmin', 'TM_IP': '127.0.0.1', 'TM_PORT': '5000',
                    'DB_HOST': '127.0.0.1', 'DB_PORT': '3306', 'DB_NAME': 'pyxaseco', 'DB_USER': 'pyxaseco'}
        for key, caption in (
                ('TM_LOGIN', 'XML-RPC login'), ('TM_PASSWORD', 'XML-RPC password'),
                ('TM_IP', 'XML-RPC host'), ('TM_PORT', 'XML-RPC port'),
                ('MASTERADMIN_LOGINS', 'MasterAdmin logins (comma separated)'),
                ('DB_HOST', 'Database host'), ('DB_PORT', 'Database port'),
                ('DB_NAME', 'Database name'), ('DB_USER', 'Database user'),
                ('DB_PASSWORD', 'Database password (optional)'),
                ('DEDI_LOGIN', 'TMF server-account login (new mode)'),
                ('DEDI_PASSWORD', 'TMF server-account password (new mode)')):
            field = QLineEdit(defaults.get(key, ''))
            if key.endswith('PASSWORD'):
                field.setEchoMode(QLineEdit.EchoMode.Password)
            if key == 'DB_PASSWORD':
                field.setPlaceholderText('Leave blank for a passwordless account')
            self.fields[key] = field
            connection.addRow(caption, field)
        for key, caption, value in (('database_admin_user', 'Database administrator (create only)', 'root'),
                ('database_admin_password', 'Administrator password (optional, not saved)', ''),
                ('database_user_host', 'New user allowed host (create only)', 'localhost')):
            field = self.fields[key] = QLineEdit(value)
            if key.endswith('password'):
                field.setEchoMode(QLineEdit.EchoMode.Password)
                field.setPlaceholderText('Leave blank if the administrator has no password')
            connection.addRow(caption, field)
        for key, value in (('server_port', '2350'), ('p2p_port', '3450')):
            self.fields[key] = QLineEdit(value)
            connection.addRow('Game port' if key == 'server_port' else 'P2P port', self.fields[key])
        connection.addRow(self.note('One MariaDB service can serve every instance. Use a different database and user per server. '
            'Both password fields may be blank; passwordless access should be local-only. '
            'Create mode refuses existing names; administrator credentials are used once and never saved.'))
        dedicated = self.page('Dedicated server')
        dedicated.addRow(self.note('These settings configure dedicated_cfg.txt for new servers only. '
            'Existing dedicated-server configurations are not changed.'))
        dedicated_tabs = QTabWidget()
        dedicated.addRow(dedicated_tabs)
        self.dedicated_fields = {}
        from pyxaseco.management.dedicated_settings import SETTINGS
        for group in ('Basic', 'Advanced'):
            area, content = QScrollArea(), QWidget()
            area.setWidgetResizable(True)
            area.setMinimumHeight(300)
            area.setWidget(content)
            form = QFormLayout(content)
            dedicated_tabs.addTab(area, group)
            for item in (item for item in SETTINGS if item.group == group):
                if item.kind == 'bool':
                    field = QCheckBox()
                    field.setChecked(item.default)
                    field.toggled.connect(self.invalidate)
                elif item.kind in {'int', 'float'}:
                    field = QSpinBox() if item.kind == 'int' else QDoubleSpinBox()
                    field.setRange(item.minimum, item.maximum) if item.kind == 'float' else field.setRange(int(item.minimum), int(item.maximum))
                    field.setValue(item.default)
                    field.valueChanged.connect(self.invalidate)
                elif item.kind == 'choice':
                    field = QComboBox()
                    field.addItems(item.choices)
                    field.setCurrentText(item.default)
                    field.currentIndexChanged.connect(self.invalidate)
                else:
                    field = QLineEdit(item.default)
                    if item.secret:
                        field.setEchoMode(QLineEdit.EchoMode.Password)
                    field.textChanged.connect(self.invalidate)
                self.dedicated_fields[item.path] = field
                form.addRow(item.caption, field)
        self.dedicated_tabs = dedicated_tabs
        dedicated_tabs.setEnabled(False)
        choices = self.page('Apps and options')
        self.options = {}
        for key, caption, checked in (
                ('create_venv', 'Create isolated controller Python environment', True),
                ('install_dependencies', 'Install required Python libraries (internet connection required)', True),
                ('bridge', 'Connect this instance to the Administrator Console on startup', True),
                ('service_definitions', 'Generate service definitions for review only (do not register)', False)):
            item = QCheckBox(caption)
            item.setChecked(checked)
            self.options[key] = item
            choices.addRow(item)
        self.fields['service_user'] = QLineEdit()
        choices.addRow('Existing Linux service user (optional)', self.fields['service_user'])
        if os.name == 'nt':
            choices.labelForField(self.fields['service_user']).hide()
            self.fields['service_user'].hide()
        choices.addRow(self.note('Optional apps below start disabled unless selected. All app source remains available.'))
        self.optional = {}
        for app, caption in (('records_rpg', 'RPG Records'), ('records_trial', 'Trial Records'),
                ('best_cp_times', 'Best CP Times'), ('bestfinishes', 'Best Finishes'),
                ('bestcps', 'Best CPs'), ('bestsecs', 'Best Secs'), ('bestruns', 'Best Runs'), ('flexitime', 'FlexiTime')):
            self.optional[app] = QCheckBox(caption)
            choices.addRow(self.optional[app])
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.tabs.addTab(self.output, 'Review / Result')
        self.status = self.note('Choose folders and credentials, then review. Nothing starts automatically.')
        layout.addWidget(self.status)
        actions = QHBoxLayout()
        self.review_button = QPushButton('Review installation')
        self.review_button.clicked.connect(self.prepare)
        self.install_button = QPushButton('Install reviewed configuration')
        self.install_button.setObjectName('primary')
        self.install_button.setEnabled(False)
        self.install_button.clicked.connect(self.install)
        self.close_button = QPushButton('Cancel')
        self.close_button.clicked.connect(self.finish)
        self.open_console = QCheckBox('Open Administrator Console after setup')
        self.open_console.setChecked(True)
        self.open_console.setVisible(parent is None)
        layout.addWidget(self.open_console)
        for item in (self.review_button, self.install_button, self.close_button):
            actions.addWidget(item)
        layout.addLayout(actions)
        for item in self.fields.values():
            item.textChanged.connect(self.invalidate)
        for item in (*self.options.values(), *self.optional.values()):
            item.toggled.connect(self.invalidate)
        self.mode.currentIndexChanged.connect(self.invalidate)
        self.mode.currentIndexChanged.connect(self.mode_changed)
        self.connection_form = connection
        self.mode_changed()
        self.database_mode.currentIndexChanged.connect(self.invalidate)
        self.database_mode.currentIndexChanged.connect(self.database_changed)
        self.database_changed()
        self.python_mode.currentIndexChanged.connect(self.python_changed)
        self.python_changed()
        self.detect_python()

    def database_changed(self):
        create = self.database_mode.currentData() == 'create'
        for key in ('database_admin_user', 'database_admin_password', 'database_user_host'):
            self.fields[key].setVisible(create)
            self.connection_form.labelForField(self.fields[key]).setVisible(create)

    def mode_changed(self):
        new = self.mode.currentData() == 'new'
        self.dedicated_tabs.setEnabled(new)
        self.tabs.setTabVisible(2, new)
        for key in ('DEDI_LOGIN', 'DEDI_PASSWORD', 'server_port', 'p2p_port'):
            self.fields[key].setVisible(new)
            self.connection_form.labelForField(self.fields[key]).setVisible(new)

    def python_changed(self):
        mode = self.python_mode.currentData()
        automatic = mode == 'auto'
        managed = (self.auto_python_mode if automatic else mode) == 'managed'
        if not self.fields['python'].isReadOnly():
            self.existing_python = self.fields['python'].text()
        if automatic and self.detected_python:
            self.fields['python'].setText(self.detected_python['python'])
        elif managed:
            from pyxaseco.management.prerequisites import managed_python_default
            self.fields['python'].setText(str(managed_python_default()))
        else:
            self.fields['python'].setText(self.existing_python)
        self.fields['python'].setReadOnly(automatic or managed)
        self.python_browse.setEnabled(not automatic and not managed)
        self.python_label.setText('Python location (automatic)' if automatic or managed else 'Existing Python program')
        self.fields['python'].setPlaceholderText('Browse to python.exe, or select the shared runtime above')
        self.python_note.setText('Finding a compatible Python installation...' if automatic and self.python_detecting else
            'Python ' + self.detected_python['version'] + ' detected. Its libraries will use an isolated environment.'
            if automatic and self.detected_python else
            'Setup will install Python and the required libraries when you confirm installation. '
            'No Python selection or library check is needed first.' if managed else
            'Choose your existing python.exe, or select the shared runtime above to let setup install Python for you.')
        self.python_note.setToolTip(self.fields['python'].text())
        self.invalidate()

    def detect_python(self):
        from .discovery import discover_python
        self.python_detecting = True
        def find():
            return discover_python([instance.python for instance in self.backend.instances()], require_venv=True)
        def done(value, error):
            self.python_detecting = False
            self.detected_python = value
            self.auto_python_mode = 'existing' if value or os.name != 'nt' else 'managed'
            if self.python_mode.currentData() == 'auto':
                self.python_changed()
        self.work.submit('detect-python', find, done)

    def prerequisites(self):
        from .prerequisites import PrerequisitesDialog
        mode = self.auto_python_mode if self.python_mode.currentData() == 'auto' else self.python_mode.currentData()
        dialog = PrerequisitesDialog(self.fields['python'].text(), python_mode=mode, parent=self)
        dialog.exec()

    @staticmethod
    def note(text):
        label = QLabel(text)
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.PlainText)
        label.setObjectName('muted')
        return label

    def page(self, title):
        area, content = QScrollArea(), QWidget()
        content.setObjectName('setupPage')
        area.setWidgetResizable(True)
        area.setWidget(content)
        self.tabs.addTab(area, title)
        form = QFormLayout(content)
        form.setSpacing(13)
        return form

    def browse(self, field, directory):
        value = QFileDialog.getExistingDirectory(self, 'Choose existing folder') if directory else QFileDialog.getOpenFileName(self, 'Choose file')[0]
        if value:
            field.setText(value)

    def invalidate(self, *_args):
        self.review = None
        self.install_button.setEnabled(False)

    def collect(self):
        values = {key: field.text() for key, field in self.fields.items()}
        environment = {key: value for key, value in values.items() if key.isupper()}
        settings = {}
        if self.mode.currentData() == 'new':
            for key, field in self.dedicated_fields.items():
                settings[key] = (field.isChecked() if isinstance(field, QCheckBox) else
                    field.value() if isinstance(field, (QSpinBox, QDoubleSpinBox)) else
                    field.currentText() if isinstance(field, QComboBox) else field.text())
        return InstallRequest(**{key: values[key] for key in ('payload', 'sha256', 'target', 'name', 'python', 'dedicated_source', 'service_user')},
            mode=self.mode.currentData(), environment=environment,
            python_mode=self.auto_python_mode if self.python_mode.currentData() == 'auto' else self.python_mode.currentData(), dedicated_settings=settings,
            database_mode=self.database_mode.currentData(),
            **{key: values[key] for key in ('database_admin_user', 'database_admin_password', 'database_user_host')},
            server_port=int(values['server_port']), p2p_port=int(values['p2p_port']),
            disabled_apps=tuple(key for key, item in self.optional.items() if not item.isChecked()),
            **{key: item.isChecked() for key, item in self.options.items()})

    def set_busy(self, value):
        self.busy = value
        for index in range(self.tabs.count() - 1):
            self.tabs.widget(index).setEnabled(not value and self.receipt is None)
        self.review_button.setEnabled(not value and self.receipt is None)
        self.install_button.setEnabled(not value and self.review is not None and self.receipt is None)
        self.close_button.setEnabled(not value)

    def prepare(self):
        if self.python_mode.currentData() == 'auto' and self.python_detecting:
            self.status.setText('Python detection is still running. Please wait briefly, then review.')
            return
        try:
            self.request = self.collect()
        except ValueError:
            self.status.setText('Game/P2P ports must be integers.')
            return
        self.set_busy(True)
        self.status.setText('Checking package, paths and installation choices...')
        def done(result, error):
            self.review = result
            self.output.setPlainText(error or json.dumps(result, indent=2))
            self.status.setText(error or 'Review the exact changes before installing. Credentials are not displayed.')
            self.tabs.setCurrentWidget(self.output)
            self.set_busy(False)
        self.work.submit('review-install', lambda: preview(self.request, self.backend.registry), done, priority=1)

    def install(self):
        if not self.review or QMessageBox.question(self, 'Confirm fresh installation',
                'Install the reviewed files, Python components and database changes? Game and controller remain stopped.') != QMessageBox.StandardButton.Yes:
            return
        self.set_busy(True)
        self.status.setText('Installing. Python setup may take several minutes. Keep this window open.')
        def done(result, error):
            self.receipt = result
            self.review = None
            self.output.setPlainText(error or json.dumps(result, indent=2))
            self.status.setText(error or 'Installation complete. Start the dedicated server, then StartController in the PyXaseco folder.')
            self.fields['database_admin_password'].clear()
            if result:
                self.request = None
            self.close_button.setText('Finish' if result else 'Close')
            self.set_busy(False)
        self.work.submit('apply-install', lambda: apply(self.request, self.backend.registry, reviewed=self.review['review']), done, priority=1)

    def finish(self):
        if not self.busy:
            self.accept() if self.receipt else self.reject()

    def reject(self):
        if not self.busy:
            self.work.close()
            super().reject()

    def closeEvent(self, event):
        if self.busy:
            event.ignore()
        else:
            self.work.close()
            event.accept()
