"""Bounded local log following; no shell, whole-log reads or persistent GUI buffer."""

import hashlib
from pathlib import Path
import re
import threading
import tomllib

from pyxaseco.management.config_store import ManagementError
from pyxaseco.management.editing import secret_key
from pyxaseco.management.instances import read_dotenv


class LogTail:
    def __init__(self, root, *, source=None, allowed_root=None, dedicated_config=None):
        self.root = Path(root).resolve()
        self.source = source or (lambda: self.root / 'logfile.txt')
        self.allowed_root = Path(allowed_root).resolve() if allowed_root else self.root
        self.dedicated_config = dedicated_config
        self.position = 0
        self.identity = None
        self.partial = b''
        self.discard_line = False
        self._lock = threading.Lock()
        self._secrets_signature = None
        self._secrets = []

    def _redact(self, text):
        sources = [self.root / '.env', self.root / 'config.toml', self.root / 'settings.toml',
                   *sorted((self.root / 'apps').glob('*/app_defaults.toml'))]
        if self.dedicated_config is not None:
            sources.append(self.dedicated_config)
        signature = tuple((str(path), path.stat().st_mtime_ns, path.stat().st_size, path.stat().st_ino)
                          if path.exists() else None for path in sources)
        if signature != self._secrets_signature:
            secrets = []
            def collect(value, path=()):
                if isinstance(value, dict):
                    for key, item in value.items():
                        collect(item, (*path, key))
                elif isinstance(value, list):
                    for item in value:
                        collect(item, path)
                elif (isinstance(value, str) and value and path
                      and (secret_key((path[-1],)) or path[-1].lower() == 'url' and secret_key(path))):
                    secrets.append(value)
            if sources[0].is_file():
                if sources[0].is_symlink() or sources[0].stat().st_size > 4 * 1024 * 1024:
                    raise ManagementError('Unsafe .env redaction source')
                collect(read_dotenv(sources[0]))
            for source in sources[1:]:
                allowed = self.allowed_root if source == self.dedicated_config else self.root
                if source.is_symlink() or not source.resolve().is_relative_to(allowed):
                    raise ManagementError('Unsafe redaction source')
                if source.is_file():
                    if source.stat().st_size > 4 * 1024 * 1024:
                        raise ManagementError('Redaction source exceeds reading limit')
                    if source == self.dedicated_config:
                        from .dedicated_files import xml_fields, xml_secret
                        _values, fields = xml_fields(source.read_bytes(), 'dedicated')
                        secrets.extend(''.join(node['text']) for keys, node in fields.items()
                                       if xml_secret(keys) and node['text'])
                    else:
                        collect(tomllib.loads(source.read_text(encoding='utf-8')))
            self._secrets = sorted(set(secrets), key=len, reverse=True)
            self._secrets_signature = signature
        for secret in self._secrets:
            # Short/numeric passwords also occur in dates and public map IDs.
            # Mask them only in credential fields, handled below.
            if len(secret) >= 4 and not secret.isdecimal():
                text = re.sub(r'(?<!\w)' + re.escape(secret) + r'(?!\w)', '[redacted]', text)
        text = re.sub(r'https?://(?:\w+\.)?discord(?:app)?\.com/api/webhooks/\S+', '[redacted webhook]', text, flags=re.I)
        text = re.sub(r'(?i)\bBearer\s+[^\s"\x27,}]+', 'Bearer [redacted]', text)
        text = re.sub(r'(?i)((?<!\w)["\x27]?(?:[a-z0-9]+[_-])*(?:password|passwd|pwd|token|secret|authorization|api[_-]?key)["\x27]?\s*[:=]\s*)(?:"[^"\n]*"|\x27[^\x27\n]*\x27|[^\s,}]+)', r'\1[redacted]', text)
        return text

    def read(self, *, hide_sensitive=True):
        with self._lock:
            file = Path(self.source())
            if not file.resolve().is_relative_to(self.allowed_root):
                raise ManagementError('Log escapes the selected instance')
            for parent in (file, *file.parents):
                if parent == self.allowed_root:
                    break
                if parent.is_symlink() or getattr(parent, 'is_junction', lambda: False)():
                    raise ManagementError('Log links are not followed')
            if not file.exists():
                return {'text': '', 'notice': 'No ' + file.name + ' yet.'}
            if file.is_symlink():
                raise ManagementError('Log symlinks are not followed')
            with file.open('rb') as stream:
                stat = file.stat()
                prefix = hashlib.sha256(stream.read(64)).hexdigest() if stat.st_size >= 64 else None
                identity = (stat.st_dev, stat.st_ino)
                previous = self.identity
                rotated = previous is not None and (identity != previous[0] or stat.st_size < self.position
                    or (previous[1] is not None and prefix != previous[1]))
                if previous is None or rotated:
                    self.position = max(0, stat.st_size - 65536)
                    self.partial = b''
                    self.discard_line = self.position > 0
                self.identity = (identity, prefix)
                stream.seek(self.position)
                raw = self.partial + stream.read(65536)
                self.position = stream.tell()
            lines = raw.split(b'\n')
            self.partial = lines.pop()
            if self.discard_line and lines:
                lines.pop(0)
                self.discard_line = False
            if len(self.partial) > 8192:
                self.partial = b''
                self.discard_line = True
            text = b'\n'.join(lines[-2000:]).decode('utf-8', errors='replace')
            if hide_sensitive:
                try:
                    text = self._redact(text)
                except (OSError, ValueError):
                    return {'text': '', 'notice': 'Cannot load redaction settings; log output withheld. Disable Hide sensitive information to view the local log.'}
            text = re.sub(r'\x1b\[[0-9;]*[A-Za-z]|[\x00-\x08\x0b-\x1f\x7f]', '', text)
            text = '\n'.join(line if len(line) <= 4096 else line[:4096] + ' [line truncated]'
                             for line in text.split('\n'))
            return {'text': text, 'notice': 'Log rotated/truncated; following current file.' if rotated else ''}
