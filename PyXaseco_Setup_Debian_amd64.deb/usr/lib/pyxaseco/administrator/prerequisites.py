"""Explicit prerequisite inspection and repair for setup and existing instances."""

import json
import os
from pathlib import Path

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QPushButton,
    QPlainTextEdit, QMessageBox, QComboBox)

from pyxaseco.management import prerequisites as actions
from .workers import WorkQueue
from .theme import STYLE


class PrerequisitesDialog(QDialog):
    def __init__(self, python, *, controller=None, instance_id=None, python_mode='existing', parent=None):
        super().__init__(parent)
        self.python = python
        self.controller = Path(controller) if controller else None
        self.instance_id = instance_id
        self.work = WorkQueue(self)
        self.busy = False
        self.setWindowTitle('PyXaseco - Python and Database')
        self.setStyleSheet(STYLE)
        self.resize(730, 580)
        layout = QVBoxLayout(self)
        note = QLabel('Check this instance before starting it. Library repair affects only its isolated Python environment. '
            'MariaDB is shared by all instances; service actions require administrator approval.')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        if not controller:
            self.output.setPlainText('Python will be installed automatically when you finish setup. '
                'Close this window, complete the setup tabs, then click Review installation and Install reviewed configuration. '
                'You can still manage the database service here.' if python_mode == 'managed' else
                'To let setup install Python for you, close this window and select '
                '"Install a shared PyXaseco Python runtime" on the Installation tab.')
        layout.addWidget(self.output, 1)
        self.buttons = []
        for caption, callback in (('Check Python libraries', self.inspect),
                ('Install missing / mismatched libraries', self.repair),
                ('Find existing database services', self.services),
                ('Install standalone MariaDB...', self.install_database)):
            button = QPushButton(caption)
            button.clicked.connect(callback)
            layout.addWidget(button)
            self.buttons.append(button)
        if self.controller:
            check = QPushButton('Check this instance database connection')
            check.clicked.connect(self.database)
            layout.addWidget(check)
            self.buttons.append(check)
        if self.controller and self.instance_id:
            bridge = QPushButton('Enable Console connection on next controller start...')
            bridge.clicked.connect(self.bridge)
            layout.addWidget(bridge)
            self.buttons.append(bridge)
        self.service = QComboBox()
        layout.addWidget(self.service)
        start = QPushButton('Start selected database service...')
        start.clicked.connect(self.start_database)
        layout.addWidget(start)
        self.buttons.append(start)
        if os.name != 'nt':
            venv = QPushButton('Install OS Python venv support...')
            venv.clicked.connect(lambda: self.confirm('Install python3-venv using the OS package manager?',
                lambda: actions.install_linux_packages('python')))
            layout.addWidget(venv)
            self.buttons.append(venv)
        close = QPushButton('Close')
        close.clicked.connect(self.reject)
        layout.addWidget(close)
        self.buttons[1].setEnabled(self.controller is not None)

    def run(self, function, callback=None):
        self.busy = True
        for button in self.buttons:
            button.setEnabled(False)
        self.output.setPlainText('Working... Please keep this window open.')
        def done(value, error):
            self.busy = False
            for button in self.buttons:
                button.setEnabled(True)
            self.buttons[1].setEnabled(self.controller is not None)
            self.output.setPlainText(error or json.dumps(value, indent=2))
            if not error and callback:
                callback(value)
        self.work.submit('prerequisite', function, done, priority=1)

    def libraries(self, install=False):
        if self.controller:
            return actions.ensure_dependencies(self.python, self.controller / 'requirements.txt', install=install)
        # A setup check needs only the pinned package list, not an installed controller.
        if not install:
            return actions.worker(self.python, {'action': 'dependencies',
                'requirements_text': actions.packaged_requirements()})
        from pyxaseco.management.config_store import ManagementError
        raise ManagementError('Complete setup first. Libraries install into the new instance environment, not shared Python.')

    def inspect(self):
        self.run(self.libraries)

    def database(self):
        from pyxaseco.management.instances import read_dotenv
        self.run(lambda: actions.database_action(self.python, read_dotenv(self.controller / '.env')))

    def bridge(self):
        from pyxaseco.management.credentials import initialize_bridge
        self.confirm('The controller must be stopped. Enable its local Console connection for the next start?',
            lambda: initialize_bridge(self.controller, instance_id=self.instance_id, enable=True, offline=True))

    def repair(self):
        self.confirm('Install the pinned controller libraries in this instance environment? Internet access is required.',
                     lambda: self.libraries(True))

    def services(self):
        def show(services):
            self.service.clear()
            for item in services:
                self.service.addItem(item['name'] + ' (' + item['state'] + ')', item['name'])
        self.run(actions.database_services, show)

    def install_database(self):
        self.confirm('Install a standalone shared MariaDB service? Existing MySQL/MariaDB installations are never replaced. '
            'On Windows the MariaDB installer opens to choose the service settings and administrator password.',
            actions.install_database_service)

    def start_database(self):
        name = self.service.currentData()
        if name:
            self.confirm('Start database service ' + name + '? Other instances may use it.',
                         lambda: actions.start_database_service(name))

    def confirm(self, text, function):
        if not self.busy and QMessageBox.question(self, 'Confirm prerequisite action', text) == QMessageBox.StandardButton.Yes:
            self.run(function)

    def reject(self):
        if not self.busy:
            self.work.close()
            super().reject()

    def closeEvent(self, event):
        if self.busy:
            event.ignore()
        else:
            self.work.close()
            event.accept()
