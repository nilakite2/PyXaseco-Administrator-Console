"""python -m administrator [--registry PATH]. No controller is started by the GUI."""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(description='PyXaseco Administrator Console')
    parser.add_argument('--registry', help='Use a separate local instance registry JSON')
    parser.add_argument('--setup', action='store_true', help='Open the fresh installation wizard')
    parser.add_argument('--smoke-test', help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError as exc:
        if args.smoke_test:
            import json
            from pathlib import Path
            Path(args.smoke_test).write_text(json.dumps({'qt': False, 'error': str(exc)}))
        print('Bundled Qt failed to load; keep the entire executable folder together.'
              if getattr(sys, 'frozen', False) else
              'Install optional requirements-admin.txt in a separate GUI environment first.', file=sys.stderr)
        return 2
    from .backend import DesktopBackend
    from .window import ConsoleWindow
    from .setup import SetupDialog
    from .theme import configure_font
    if sys.platform == 'win32':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('PyXaseco.Administrator.1.3')
    app = QApplication(sys.argv[:1])
    app.setApplicationName('PyXaseco Administrator Console')
    app.setOrganizationName('PyXaseco')
    from pathlib import Path
    from PySide6.QtGui import QIcon
    app.setWindowIcon(QIcon(str(Path(__file__).parent / 'assets/PyXaseco_Logo.png')))
    configure_font(app)
    backend = DesktopBackend(args.registry)
    if args.smoke_test:
        import json
        from pathlib import Path
        target = Path(args.smoke_test)
        dialog = SetupDialog(backend)
        dialog.show()
        app.processEvents()
        dialog.grab().save(str(target.with_suffix('.png')))
        from pyxaseco.management.instances import Instance
        from .maintenance import MaintenanceDialog
        sample = Instance('0' * 32, 'Packaging check', str(Path.cwd()), str(Path.cwd() / 'config.toml'),
                          '', None, 'PyXaseco-' + '0' * 32, 'TMF-' + '0' * 32)
        maintenance = MaintenanceDialog(backend, sample)
        maintenance.show()
        app.processEvents()
        maintenance.grab().save(str(target.with_name(target.stem + '_maintenance').with_suffix('.png')))
        target.write_text(json.dumps({'qt': True, 'setup_tabs': dialog.tabs.count(),
            'maintenance_actions': maintenance.action.count(),
            'logo': (Path(__file__).parent / 'assets/PyXaseco_Logo.png').is_file(),
            'payload': bool(dialog.fields['payload'].text()), 'controller_started': False}))
        maintenance.close()
        dialog.close()
        return 0
    if args.setup:
        dialog = SetupDialog(backend)
        if not dialog.exec() or not dialog.open_console.isChecked():
            return 0
    window = ConsoleWindow(backend)
    window.show()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
