"""Bounded, read-only discovery for setup; never install or launch a controller."""

import json
import os
from pathlib import Path
import re
import shutil
import sys

from pyxaseco.management.config_store import ManagementError
from pyxaseco.management.instances import configured_endpoint, controller_root
from pyxaseco.management.prerequisites import managed_python_default, selected_python


def registry_pythons():
    if os.name != 'nt':
        return []
    import winreg
    paths = []
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
            try:
                with winreg.OpenKey(hive, r'Software\Python', 0, winreg.KEY_READ | view) as companies:
                    for index in range(winreg.QueryInfoKey(companies)[0]):
                        company = winreg.EnumKey(companies, index)
                        with winreg.OpenKey(companies, company) as tags:
                            for number in range(winreg.QueryInfoKey(tags)[0]):
                                tag = winreg.EnumKey(tags, number)
                                try:
                                    with winreg.OpenKey(tags, tag + r'\InstallPath') as install:
                                        try:
                                            paths.append(Path(winreg.QueryValueEx(install, 'ExecutablePath')[0]))
                                        except OSError:
                                            paths.append(Path(winreg.QueryValueEx(install, '')[0]) / 'python.exe')
                                except OSError:
                                    continue
            except OSError:
                continue
    return paths


def python_candidates(preferred=()):
    candidates = [*map(Path, preferred), managed_python_default(), *registry_pythons()]
    if not getattr(sys, 'frozen', False):
        candidates.append(Path(getattr(sys, '_base_executable', sys.executable)))
    for name in ('python3', 'python'):
        path = shutil.which(name)
        if path:
            candidates.append(Path(path))
    if os.name == 'nt':
        local = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local'))
        candidates.extend(sorted((local / 'Programs/Python').glob('Python*/python.exe'), reverse=True))
        candidates.extend(sorted(Path(os.environ.get('SystemDrive', 'C:') + '/').glob('Python3*/python.exe'), reverse=True))
    result, seen = [], set()
    for candidate in candidates:
        candidate = candidate.expanduser().absolute()
        key = os.path.normcase(str(candidate))
        if key not in seen and candidate.is_file():
            seen.add(key)
            # Do not execute the Windows Store aliases (which can open a store window).
            if os.name == 'nt' and ('microsoft/windowsapps' in candidate.as_posix().lower()
                    or not re.fullmatch(r'python[0-9.t-]*(?:-64)?\.exe', candidate.name, re.I)):
                continue
            result.append(candidate)
    return result


def probe_python(path, *, require_venv=False):
    from pyxaseco.management.installation import _run
    executable = selected_python(path)
    code = ('import importlib.util,json,sys; print(json.dumps({"version":list(sys.version_info[:3]),'
            '"venv":importlib.util.find_spec("venv") is not None,'
            '"ensurepip":importlib.util.find_spec("ensurepip") is not None}))')
    try:
        report = json.loads(_run([str(executable), '-I', '-B', '-c', code], timeout=3, capture=True))
        version = report['version']
        if (len(version) != 3 or any(type(part) is not int for part in version)
                or version[0] != 3 or version[1] < 12):
            raise ValueError('unsupported version')
        if require_venv and not (report['venv'] and report['ensurepip']):
            raise ValueError('venv support missing')
    except (KeyError, TypeError, ValueError, ManagementError) as exc:
        raise ManagementError('Choose Python 3.12 or newer' + (' with venv/pip support.' if require_venv else '.')) from exc
    return {'python': str(executable), 'version': '.'.join(map(str, version))}


def discover_python(preferred=(), *, require_venv=False):
    for candidate in python_candidates(preferred)[:8]:
        try:
            return probe_python(candidate, require_venv=require_venv)
        except (ManagementError, OSError):
            continue
    return None


def inspect_installation(folder):
    from .processes import LocalProcesses, _path, _psutil
    root = controller_root(folder)
    parent = root.parent
    running = []
    running_dedicated = set()
    executables = list(parent.glob('*.exe')) if os.name == 'nt' else [parent / 'TrackmaniaServer']
    executables = [path for path in executables if path.is_file()]
    native = {_path(path): path for path in executables}
    for process in _psutil().process_iter(['exe', 'cwd', 'cmdline'], ad_value=None):
        row = process.info
        executable, command, cwd = row.get('exe'), row.get('cmdline') or [], row.get('cwd')
        if executable and _path(executable) in native:
            running_dedicated.add(native[_path(executable)])
        script = LocalProcesses._script(command)
        if (executable and Path(executable).name.lower().startswith('python')
                and script and (Path(script).is_absolute() or cwd)
                and _path(script, cwd) == _path(root / 'main.py')):
            tail = command[command.index(script) + 1:]
            config = next((item for item in tail if not item.startswith('-')), 'config.toml')
            if (Path(config).is_absolute() or cwd) and _path(config, cwd) == _path(root / 'config.toml'):
                candidate = Path(command[0])
                if not candidate.is_absolute() and cwd:
                    candidate = Path(cwd) / candidate
                candidate = str(candidate) if candidate.is_file() else executable
                if candidate:
                    running.append(candidate)
    if len(set(running)) > 1:
        raise ManagementError('Multiple Python runtimes are running this controller. Review its existing processes first.')
    relative = ('Scripts/python.exe',) if os.name == 'nt' else ('bin/python',)
    preferred = [*running, *(root / name / suffix for name in ('.venv-pyxaseco', '.venv', 'venv') for suffix in relative)]
    python = discover_python(preferred)
    selected = next(iter(running_dedicated)) if len(running_dedicated) == 1 else None
    if selected is None and not running_dedicated and len(executables) == 1:
        selected = executables[0]
    host, port = configured_endpoint(root)
    entrypoint = root / 'main.py'
    support = entrypoint.stat().st_size <= 262144 and 'MANAGEMENT_RUNTIME_LOCK = 1' in entrypoint.read_text(encoding='utf-8-sig')
    return {'controller': str(root), 'name': parent.name if root.name.lower() == 'pyxaseco' else root.name,
            'python': python, 'dedicated': str(selected or ''), 'xmlrpc': f'{host}:{port}',
            'dedicated_ambiguous': len(executables) > 1 and selected is None,
            'python_running': bool(running), 'management_support': support,
            'connection_discovered': (root / '.management-endpoint.json').is_file()}
