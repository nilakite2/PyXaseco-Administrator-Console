"""Explicit stopped-instance program maintenance; never a fleet-wide updater."""

import json

from PySide6.QtWidgets import (QComboBox, QDialog, QFileDialog, QFormLayout,
    QHBoxLayout, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QVBoxLayout)

from .setup import SetupDialog, payload_defaults
from .theme import STYLE
from .workers import WorkQueue


class MaintenanceDialog(QDialog):
    def __init__(self, backend, instance, parent=None):
        super().__init__(parent)
        self.backend, self.instance = backend, instance
        self.work = WorkQueue(self)
        self.busy = False
        self.review = None
        self.arguments = None
        self.setWindowTitle('Program maintenance - ' + instance.name)
        self.setStyleSheet(STYLE)
        self.resize(850, 690)
        layout = QVBoxLayout(self)
        layout.addWidget(SetupDialog.note('Stopped controller only. Configuration, databases, maps, custom apps, venv and records stay in place.\n'
            'Uninstall removes unchanged owned program files only, and requires the controller OS service to be removed first.'))
        form = QFormLayout()
        self.action = QComboBox()
        for caption, action in (('Upgrade program files', 'upgrade'),
                ('Adopt a matching trusted baseline (older installs only)', 'adopt'),
                ('Roll back a recorded transaction', 'rollback'),
                ('Uninstall program files; retain all data', 'uninstall')):
            self.action.addItem(caption, action)
        form.addRow('Operation', self.action)
        self.payload, self.digest, self.transaction = QLineEdit(), QLineEdit(), QComboBox()
        payload, digest = payload_defaults()
        self.payload.setText(payload)
        self.digest.setText(digest)
        row = QHBoxLayout()
        row.addWidget(self.payload)
        choose = QPushButton('Browse ZIP')
        choose.clicked.connect(self.browse)
        row.addWidget(choose)
        form.addRow('Trusted incoming/baseline payload', row)
        form.addRow('Trusted SHA256', self.digest)
        row = QHBoxLayout()
        row.addWidget(self.transaction)
        self.refresh_button = QPushButton('Load history')
        self.refresh_button.clicked.connect(self.history)
        row.addWidget(self.refresh_button)
        form.addRow('Rollback transaction', row)
        layout.addLayout(form)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output, 1)
        self.status = SetupDialog.note('Review first. Maintenance does not stop/start the controller for you.')
        layout.addWidget(self.status)
        row = QHBoxLayout()
        self.review_button = QPushButton('Review operation')
        self.review_button.clicked.connect(self.prepare)
        self.apply_button = QPushButton('Apply reviewed operation')
        self.apply_button.setObjectName('primary')
        self.apply_button.setEnabled(False)
        self.apply_button.clicked.connect(self.apply)
        self.close_button = QPushButton('Close')
        self.close_button.clicked.connect(self.reject)
        for item in (self.review_button, self.apply_button, self.close_button):
            row.addWidget(item)
        layout.addLayout(row)
        for field in (self.payload, self.digest):
            field.textChanged.connect(self.invalidate)
        self.action.currentIndexChanged.connect(self.invalidate)
        self.transaction.currentIndexChanged.connect(self.invalidate)

    def browse(self):
        path = QFileDialog.getOpenFileName(self, 'Select trusted payload', filter='Controller ZIP (*.zip)')[0]
        if path:
            self.payload.setText(path)

    def invalidate(self, *_args):
        self.review = None
        self.apply_button.setEnabled(False)

    def set_busy(self, value):
        self.busy = value
        for field in (self.action, self.payload, self.digest, self.transaction,
                      self.refresh_button, self.review_button, self.close_button):
            field.setEnabled(not value)
        self.apply_button.setEnabled(not value and self.review is not None
                                     and self.review.get('can_apply', True))

    def history(self):
        self.set_busy(True)
        def done(result, error):
            self.transaction.clear()
            if error:
                self.status.setText(error)
            else:
                for item in result:
                    self.transaction.addItem(f"{item['action']} / {item['state']} / {item['id']}", item['id'])
            self.set_busy(False)
        self.work.submit('history', lambda: self.backend.maintenance(self.instance).transactions(), done, priority=1)

    def execute(self, arguments, reviewed=None):
        action, payload, digest, transaction = arguments
        manager = self.backend.maintenance(self.instance)
        if action == 'adopt':
            return manager.adopt(payload=payload, sha256=digest, reviewed=reviewed)
        if action == 'rollback':
            return manager.rollback(transaction or '', reviewed=reviewed)
        kwargs = {'payload': payload, 'sha256': digest}
        return manager.apply(action, reviewed=reviewed, **kwargs) if reviewed else manager.preview(action, **kwargs)

    def prepare(self):
        self.arguments = (self.action.currentData(), self.payload.text(), self.digest.text(), self.transaction.currentData())
        self.set_busy(True)
        def done(result, error):
            self.review = result
            self.output.setPlainText(error or json.dumps(result, indent=2))
            self.status.setText(error or 'Review the file list and conflicts. No files changed by preview.')
            self.set_busy(False)
        self.work.submit('review', lambda: self.execute(self.arguments), done, priority=1)

    def apply(self):
        if not self.review or QMessageBox.question(self, 'Confirm program maintenance',
                'Apply this reviewed operation to this installation only? No database operation or server start will occur.') != QMessageBox.StandardButton.Yes:
            return
        arguments, reviewed = self.arguments, self.review['review']
        self.set_busy(True)
        def done(result, error):
            self.review = None
            self.output.setPlainText(error or json.dumps(result, indent=2))
            self.status.setText(error or 'Completed. Nothing started. Retain the transaction backup for rollback.')
            self.set_busy(False)
        self.work.submit('apply', lambda: self.execute(arguments, reviewed), done, priority=1)

    def reject(self):
        if not self.busy:
            self.work.close()
            super().reject()

    def closeEvent(self, event):
        if self.busy:
            event.ignore()
        else:
            self.work.close()
            event.accept()
