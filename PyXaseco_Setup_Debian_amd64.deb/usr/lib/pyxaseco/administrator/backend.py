"""Desktop orchestration over headless interfaces, with no app imports or process ownership."""

import asyncio
from dataclasses import asdict
import json
import os
from pathlib import Path
import threading
import time
import tomllib
from uuid import uuid4

from pyxaseco.management.config_store import ManagementError, update_file
from pyxaseco.management.instances import InstanceRegistry
from pyxaseco.management.operations import ManagementOperations, read_config
from pyxaseco.management.instances import read_dotenv
from pyxaseco.management.editing import origin_hints
from pyxaseco.management.runtime_client import RuntimeClient
from pyxaseco.management.services import ServiceAdapter, ServicePlan


class DesktopBackend:
    def __init__(self, registry=None):
        self.registry = InstanceRegistry(registry)
        self.preferences = self.registry.path.with_name(self.registry.path.stem + '-console.json')
        self._lock = threading.Lock()
        self._catalog = {}
        from .processes import LocalProcesses
        self.processes = LocalProcesses()

    def instances(self):
        return self.registry.list()

    def display_settings(self):
        data = json.loads(self.preferences.read_text(encoding='utf-8')) if self.preferences.is_file() else {}
        hidden = data.get('hide_sensitive_information', True)
        return {'hide_sensitive_information': hidden if type(hidden) is bool else True}

    def save_display_settings(self, hidden):
        if type(hidden) is not bool:
            raise ManagementError('Invalid sensitive-information display setting')
        def change(text):
            data = json.loads(text) if text else {'version': 1}
            data['hide_sensitive_information'] = hidden
            return json.dumps(data, indent=2) + '\n'
        update_file(self.preferences, change, validator=json.loads, backup=False)
        return {'hide_sensitive_information': hidden}

    @staticmethod
    def _client(instance):
        client = RuntimeClient(instance.controller)
        if client.instance_id != instance.id:
            raise ManagementError('Bridge identity differs from this registered installation; provision it with --instance')
        return client

    def register(self, folder, name, python, dedicated=None):
        return self.registry.register(folder, name=name, python=python, dedicated=dedicated or None)

    def plan(self, instance):
        if not self.preferences.exists():
            return None
        data = json.loads(self.preferences.read_text(encoding='utf-8'))
        path = data.get('plans', {}).get(instance.id)
        if not path:
            return None
        plan = ServicePlan.read(path)
        if (plan.instance_id != instance.id or Path(plan.controller).resolve() != Path(instance.controller).resolve()
                or plan.controller_service != instance.controller_service
                or plan.dedicated_service != instance.dedicated_service
                or plan.platform != ('windows' if os.name == 'nt' else 'linux')):
            raise ManagementError('Service plan does not belong to this local installation')
        # Distinct Linux venvs can resolve to the same system Python binary.
        if Path(plan.python).absolute() != Path(instance.python).absolute():
            raise ManagementError('Service plan Python differs from the registered executable')
        if plan.owns_dedicated and Path(plan.dedicated).resolve() != Path(instance.dedicated or '').resolve():
            raise ManagementError('Service plan dedicated executable differs from the registered one')
        return plan

    def attach_plan(self, instance, path):
        # Validate before updating the per-user preference file, including cross-instance plans.
        source = ServicePlan.read(path)
        if (source.instance_id != instance.id or Path(source.controller).resolve() != Path(instance.controller).resolve()
                or source.platform != ('windows' if os.name == 'nt' else 'linux')
                or Path(source.python).absolute() != Path(instance.python).absolute()
                or (source.owns_dedicated and Path(source.dedicated).resolve() != Path(instance.dedicated or '').resolve())):
            raise ManagementError('Select the local service plan for this exact registered installation')
        self.preferences.parent.mkdir(parents=True, exist_ok=True)
        def change(text):
            data = json.loads(text) if text else {'version': 1, 'plans': {}}
            data.setdefault('plans', {})[instance.id] = str(Path(path).resolve())
            return json.dumps(data, indent=2) + '\n'
        update_file(self.preferences, change, validator=json.loads, backup=False)
        return {'attached': True, 'installed': False, 'started': False}

    @staticmethod
    def maintenance(instance):
        from pyxaseco.management.maintenance import Maintenance
        return Maintenance(instance)

    def services(self, instance):
        plan = self.plan(instance)
        if plan is None:
            try:
                service = ServiceAdapter(ServicePlan.from_instance(instance,
                    platform='windows' if os.name == 'nt' else 'linux')).status('controller')
            except ManagementError:
                service = {}
            if service.get('registered'):
                return {'controller': service, 'dedicated': {'state': 'unmanaged'},
                        'management': 'service', 'plan_attached': False, 'owns_dedicated': False}
            return self.processes.status(instance, self.launch_profile(instance))
        fallback = plan or ServicePlan.from_instance(instance, platform='windows' if os.name == 'nt' else 'linux')
        adapter = ServiceAdapter(fallback)
        return {'controller': adapter.status('controller'),
                'dedicated': adapter.status('dedicated') if plan and plan.owns_dedicated else
                    {'state': 'unmanaged', 'runtime_ready': 'unknown'},
                'plan_attached': plan is not None, 'owns_dedicated': bool(plan and plan.owns_dedicated)}

    def launch_profile(self, instance):
        from .processes import LaunchProfile
        data = json.loads(self.preferences.read_text(encoding='utf-8')) if self.preferences.is_file() else {}
        return LaunchProfile.read(instance, data.get('launchers', {}).get(instance.id))

    def preview_launchers(self, instance, profile=None):
        return (profile or self.launch_profile(instance)).review(instance)

    def save_launchers(self, instance, profile, *, reviewed):
        if profile.review(instance)['review'] != reviewed:
            raise ManagementError('Launchers changed after review; review again before saving')
        def change(text):
            data = json.loads(text) if text else {'version': 1}
            data.setdefault('launchers', {})[instance.id] = asdict(profile)
            return json.dumps(data, indent=2) + '\n'
        update_file(self.preferences, change, validator=json.loads)
        return {'saved': True, 'started': False, 'server_files_changed': False}

    def process_action(self, instance, target, action, *, reviewed):
        if self.plan(instance) is not None:
            raise ManagementError('This installation has an attached OS service plan; use service controls')
        return self.processes.action(instance, self.launch_profile(instance), target, action, reviewed=reviewed)

    def instance_tools(self):
        from .instance_tools import InstanceTools
        return InstanceTools(self)

    def batch_review(self, instances, target, action):
        if target not in {'controller', 'dedicated', 'both'} or action not in {'start', 'stop', 'restart'}:
            raise ManagementError('Choose a supported component and lifecycle action')
        if not instances or len({item.id for item in instances}) != len(instances):
            raise ManagementError('Choose distinct registered instances')
        rows = []
        for item in instances:
            row = {'instance': item.id, 'name': item.name, 'target': target, 'action': action}
            try:
                current = self.registry.get(item.id)
                if current != item:
                    raise ManagementError('Registration changed; refresh the instance list')
                plan = self.plan(item)
                if plan:
                    if target != 'controller' and not plan.owns_dedicated:
                        raise ManagementError('Dedicated component is not managed by this service plan')
                    row.update(mode='service', review=asdict(plan))
                else:
                    services = self.services(item)
                    if services.get('management') != 'process':
                        raise ManagementError('Connect this instance\'s existing OS service plan first')
                    profile = self.preview_launchers(item)
                    if target != 'controller' and not profile['profile']['dedicated_executable']:
                        raise ManagementError('Configure this instance\'s dedicated executable first')
                    row.update(mode='process', review=profile['review'])
                row['registration'] = asdict(item)
            except (ManagementError, OSError, ValueError) as exc:
                row['error'] = str(exc) if isinstance(exc, ManagementError) else 'Instance review failed; check paths and permissions'
            rows.append(row)
        return rows

    def batch_step(self, row):
        if row.get('error'):
            raise ManagementError(row['error'])
        item = self.registry.get(row['instance'])
        if asdict(item) != row['registration']:
            raise ManagementError('Registration changed after bulk review; refresh before retrying')
        if row['mode'] == 'service':
            plan = self.plan(item)
            if plan is None or asdict(plan) != row['review']:
                raise ManagementError('OS service plan changed after review')
            return self.service_action(item, row['target'], row['action'])
        return self.process_action(item, row['target'], row['action'], reviewed=row['review'])

    def poll(self, instance):
        result = {'sampled_at': time.time(), 'online': False, 'runtime': None, 'runtime_error': None}
        try:
            async def status():
                async with self._client(instance) as client:
                    return await client.status()
            result['runtime'] = asyncio.run(status())
            result['online'] = True
        except (ManagementError, OSError, ValueError):
            result['runtime_error'] = 'Runtime bridge unavailable or not enabled. This does not prove the controller is stopped.'
        try:
            result['services'] = self.services(instance)
        except (ManagementError, OSError, ValueError) as exc:
            result['services'] = {'error': type(exc).__name__, 'plan_attached': False,
                'controller': {'state': 'unknown'}, 'dedicated': {'state': 'unknown'}}
        return result

    def apps(self, instance, online=False):
        root = Path(instance.controller)
        paths = [root / 'apps.toml', *sorted((root / 'apps').glob('*/app.py'))]
        signature = tuple((str(path), path.stat().st_mtime_ns, path.stat().st_size) for path in paths)
        with self._lock:
            cached = self._catalog.get(instance.id)
        if cached is None or cached[0] != signature:
            rows = [asdict(row) for row in ManagementOperations(root).apps()]
            with self._lock:
                self._catalog[instance.id] = (signature, rows)
        else:
            rows = cached[1]
        rows = [dict(row) for row in rows]
        if online:
            async def inventory():
                async with self._client(instance) as client:
                    return await client.apps()
            live = asyncio.run(inventory())
            actual = {row['id']: row for row in live['apps']}
            for row in rows:
                runtime = actual.get(row['id'], {})
                for key in ('runtime_loaded', 'runtime_started', 'reload_supported', 'pending_restart'):
                    row[key] = runtime.get(key)
        return {'apps': rows, 'revision': read_config(ManagementOperations(root), 'apps.toml')['revision']}

    def config_files(self, instance):
        root = Path(instance.controller)
        paths = [*root.glob('*.toml'), *root.glob('apps/*/app_defaults.toml')]
        if (root / '.env').is_file():
            paths.append(root / '.env')
        files = sorted(path.relative_to(root).as_posix() for path in paths
                      if not path.is_symlink() and path.resolve().is_relative_to(root) and path.name != 'management.toml'
                      and path.parent.name != 'management_bridge')
        from .dedicated_files import CONFIGS
        dedicated = self.dedicated_files(instance)
        for name in CONFIGS:
            try:
                if dedicated.path(name).is_file():
                    files.append(name)
            except ManagementError:
                pass
        return files

    def dedicated_files(self, instance):
        from .dedicated_files import DedicatedFiles
        profile = self.launch_profile(instance)
        location = profile.dedicated_executable or profile.dedicated_launcher
        return DedicatedFiles(Path(location).parent if location else Path(instance.controller).parent)

    def log_sources(self, instance):
        return self.dedicated_files(instance).log_sources()

    def log_tail(self, instance, source):
        from .logs import LogTail
        if source == 'logfile.txt':
            return LogTail(instance.controller)
        files = self.dedicated_files(instance)
        files.log_path(source)
        return LogTail(instance.controller, source=lambda: files.log_path(source),
                       allowed_root=files.root, dedicated_config=files.path('GameData/Config/dedicated_cfg.txt'))

    def backups(self, instance, relative):
        from .dedicated_files import CONFIGS
        if relative in CONFIGS:
            return self.dedicated_files(instance).backups(relative)
        return ManagementOperations(instance.controller).backups(relative)

    def edit_dedicated(self, instance, payload):
        if payload['kind'] not in {'config.validate', 'config.write', 'config.restore'}:
            raise ManagementError('Unsupported dedicated file action')
        return self.dedicated_files(instance).edit(payload['file'], payload.get('path', ()), payload.get('value'),
            expected=payload['revision'], validate=payload['kind'] == 'config.validate',
            backup=payload.get('backup') if payload['kind'] == 'config.restore' else None)

    def read(self, instance, relative, *, hide_sensitive=True):
        from .dedicated_files import CONFIGS
        if relative in CONFIGS:
            return self.dedicated_files(instance).read(relative, hide_sensitive=hide_sensitive)
        operations = ManagementOperations(instance.controller)
        if hide_sensitive:
            return read_config(operations, relative)
        # Reveal only files this local operator can already read. The runtime API
        # and CLI keep their existing masked responses.
        text, stamp = operations.config.read(relative)
        data = read_dotenv(operations.config.path(relative)) if relative == '.env' else tomllib.loads(text)
        return {'revision': stamp, 'values': data, 'notes': origin_hints(relative)}

    def execute(self, instance, payload, *, online, request_id=None, run_id=None):
        if online:
            async def command():
                async with self._client(instance) as client:
                    if run_id and client.run_id != run_id:
                        raise ManagementError('Controller restarted since selection; refresh before issuing this command')
                    submitted = await client.submit(payload, request_id=request_id or uuid4().hex)
                    if payload['kind'] in {'controller.stop', 'controller.restart'}:
                        return submitted
                    return await client.wait(submitted['id'], timeout=10)
            return asyncio.run(command())
        operations = ManagementOperations(instance.controller)
        kind = payload['kind']
        if kind == 'config.validate':
            operations.validate_config_edit(payload['file'], tuple(payload['path']), payload['value'], expected=payload['revision'])
            return {'state': 'completed', 'result': {'valid': True, 'saved': False}}
        if kind == 'config.write':
            saved = operations.set_config(payload['file'], tuple(payload['path']), payload['value'], expected=payload['revision'], offline=True)
        elif kind == 'config.restore':
            saved = operations.restore_config(payload['file'], payload['backup'], expected=payload['revision'], offline=True)
        elif kind == 'app.state':
            saved = operations.set_app_state(payload['app'], payload['enabled'], expected=payload['revision'], offline=True)
        else:
            raise ManagementError('This operation requires the authenticated running controller')
        return {'state': 'completed', 'result': {**asdict(saved), 'saved': True, 'restart_required': True, 'runtime_applied': False}}

    def operation(self, instance, operation_id, run_id):
        async def query():
            async with self._client(instance) as client:
                if client.run_id != run_id:
                    raise ManagementError('Operation belongs to an earlier controller run; refresh disk/runtime state')
                return await client.result(operation_id)
        return asyncio.run(query())

    def service_action(self, instance, target, action):
        plan = self.plan(instance)
        if plan is None:
            raise ManagementError('Attach and review this installation\'s service plan first')
        return ServiceAdapter(plan).action(target, action, confirmed=True)
