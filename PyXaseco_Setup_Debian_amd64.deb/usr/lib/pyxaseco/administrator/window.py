"""Multi-installation desktop surface. All management I/O is dispatched to workers."""

import json
from pathlib import Path
import sys
import time
from uuid import uuid4

from PySide6.QtCore import Qt, QTimer, QItemSelectionModel
from PySide6.QtGui import QAction, QIcon, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
    QFormLayout, QFrame, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMainWindow, QMessageBox, QPlainTextEdit,
    QPushButton, QSplitter, QTableWidget, QTableWidgetItem, QTabWidget, QTreeWidget, QMenu,
    QTreeWidgetItem, QVBoxLayout, QWidget,
)

from pyxaseco.management.app_policy import MANAGEABLE_STANDALONE_APPS
from pyxaseco.management.editing import secret_key

from .backend import DesktopBackend
from .dedicated_files import CONFIGS, LATEST, xml_secret
from .registration import RegisterDialog
from .processes import launch_summary
from .theme import STYLE
from .workers import WorkQueue


ASSETS = Path(__file__).parent / 'assets'


def label(text='', name=None):
    value = QLabel(text)
    value.setTextFormat(Qt.TextFormat.PlainText)
    if name:
        value.setObjectName(name)
    return value


def button(text, callback, name=None):
    value = QPushButton(text)
    if name:
        value.setObjectName(name)
    value.clicked.connect(callback)
    return value


def table(headers):
    value = QTableWidget(0, len(headers))
    value.setHorizontalHeaderLabels(headers)
    value.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    value.verticalHeader().hide()
    value.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    value.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    value.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    value.setAlternatingRowColors(True)
    value.setWordWrap(False)
    return value


def rows(widget, values):
    widget.setRowCount(len(values))
    for row, cells in enumerate(values):
        for column, text in enumerate(cells):
            text = str(text)
            item = widget.item(row, column)
            if item is None:
                item = QTableWidgetItem(text)
                item.setToolTip(text)
                widget.setItem(row, column, item)
            elif item.text() != text:
                item.setText(text)
                item.setToolTip(text)


def state(value):
    return 'Unknown' if value is None else 'Yes' if value else 'No'


class ConsoleWindow(QMainWindow):
    def __init__(self, backend=None, *, auto_refresh=True):
        super().__init__()
        self.backend = backend or DesktopBackend()
        self.work = WorkQueue(self)
        self.instances = []
        self.samples = {}
        self.selected = None
        self.selection_generation = 0
        self.config_generation = 0
        self.privacy_generation = 0
        self.log_generation = 0
        self.hide_sensitive = True
        self.config_data = None
        self.config_context = None
        self.app_data = []
        self.app_revision = None
        self.last_operations = {}
        self.tails = {}
        self.batch_ids = set()
        self.setWindowTitle('PyXaseco Administrator Console 1.3')
        self.setWindowIcon(QIcon(str(ASSETS / 'PyXaseco_Logo.png')))
        self.resize(1460, 980)
        self.setMinimumSize(1120, 740)
        self.setStyleSheet(STYLE)
        self._build()
        self.timer = QTimer(self)
        self.timer.setInterval(5000)
        self.timer.timeout.connect(self.refresh_all)
        self.log_timer = QTimer(self)
        self.log_timer.setInterval(2000)
        self.log_timer.timeout.connect(self.follow_log)
        if auto_refresh:
            self.timer.start()
            self.log_timer.start()
        self.reload_instances()
        def display_settings(value, error):
            if not error and self.privacy_generation == 0:
                self.privacy_toggle.setChecked(value['hide_sensitive_information'])
        self.work.submit('display-settings', self.backend.display_settings, display_settings)

    def _build(self):
        central = QWidget()
        outer = QHBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        sidebar = QWidget()
        sidebar.setObjectName('sidebar')
        sidebar.setFixedWidth(254)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(18, 24, 18, 18)
        mark = label()
        mark.setPixmap(QPixmap(str(ASSETS / 'PyXaseco_Logo.png')).scaled(70, 70, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        side.addWidget(mark)
        side.addWidget(label('PyXaseco', 'heading'))
        side.addWidget(label('ADMINISTRATOR CONSOLE', 'eyebrow'))
        side.addSpacing(25)
        side.addWidget(label('LOCAL INSTANCES', 'eyebrow'))
        self.search = QLineEdit()
        self.search.setPlaceholderText('Find a server...')
        self.search.textChanged.connect(self.filter_instances)
        side.addWidget(self.search)
        self.instance_list = QListWidget()
        self.instance_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.instance_list.currentItemChanged.connect(self.select_instance)
        self.instance_list.itemSelectionChanged.connect(lambda: self.render_selected() if self.selected else None)
        self.instance_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.instance_list.customContextMenuRequested.connect(self.instance_context)
        side.addWidget(self.instance_list, 1)
        add = QPushButton('Add server')
        add.setObjectName('primary')
        add_menu = QMenu(add)
        add_menu.addAction('Register an existing PyXaseco server...', self.register_installation)
        add_menu.addAction('Install a new controller / server...', self.install_controller)
        add_menu.addSeparator()
        add_menu.addAction('Refresh all servers', self.refresh_all)
        add.setMenu(add_menu)
        side.addWidget(add)
        side.addWidget(label('Ctrl/Shift selects several. Right-click for actions.', 'muted'))
        self.registry_label = label('One console. Independent servers.', 'muted')
        self.registry_label.setWordWrap(True)
        side.addWidget(self.registry_label)
        outer.addWidget(sidebar)
        main = QWidget()
        content = QVBoxLayout(main)
        content.setContentsMargins(25, 22, 25, 18)
        content.setSpacing(15)
        hero = QFrame()
        hero.setObjectName('hero')
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(20, 16, 16, 16)
        title = QVBoxLayout()
        title.addWidget(label('TRACKMANIA FOREVER / LOCAL CONTROL', 'eyebrow'))
        self.title = label('Your servers, together.', 'heading')
        title.addWidget(self.title)
        self.subtitle = label('Register an instance to get started.', 'muted')
        self.subtitle.setWordWrap(True)
        self.subtitle.setMaximumHeight(44)
        title.addWidget(self.subtitle)
        hero_layout.addLayout(title, 1)
        banner = label()
        banner.setPixmap(QPixmap(str(ASSETS / 'PyXaseco_Banner.png')).scaled(360, 122, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        hero_layout.addWidget(banner)
        content.addWidget(hero)
        cards = QHBoxLayout()
        self.cards = {}
        for caption in ('CONTROLLER', 'DEDICATED SERVER', 'PLAYERS / SPECTATORS', 'DATABASE / PROVIDERS'):
            frame = QFrame()
            frame.setObjectName('card')
            box = QVBoxLayout(frame)
            box.addWidget(label(caption, 'eyebrow'))
            value = label('Unknown', 'cardValue')
            value.setWordWrap(True)
            box.addWidget(value)
            self.cards[caption] = value
            cards.addWidget(frame, 1)
        content.addLayout(cards)
        edit_target = QHBoxLayout()
        edit_target.addWidget(label('EDIT TARGET', 'eyebrow'))
        self.edit_mode = QComboBox()
        self.edit_mode.addItems(['Running controller', 'Stopped controller (offline)'])
        self.edit_mode.setToolTip('Offline writes still require the controller runtime lock to be free.')
        edit_target.addWidget(self.edit_mode)
        edit_target.addStretch()
        self.privacy_toggle = QCheckBox('Hide sensitive information')
        self.privacy_toggle.setChecked(True)
        self.privacy_toggle.setToolTip('Controls local log and configuration display only. Turn off to see passwords; avoid sharing screenshots while they are visible.')
        self.privacy_toggle.toggled.connect(self.privacy_changed)
        edit_target.addWidget(self.privacy_toggle)
        content.addLayout(edit_target)
        self.tabs = QTabWidget()
        self.tabs.currentChanged.connect(self.tab_changed)
        content.addWidget(self.tabs, 1)
        self._dashboard()
        self._services()
        self._apps()
        self._configuration()
        self._console()
        outer.addWidget(main, 1)
        self.setCentralWidget(central)
        self.statusBar().showMessage('Ready. Closing this console does not stop servers.')

    def privacy_changed(self, hidden):
        self.hide_sensitive = hidden
        self.privacy_generation += 1
        self.config_generation += 1
        self.config_data = None
        self.config_tree.clear()
        self.value_edit.clear()
        self.value_edit.setEchoMode(QLineEdit.EchoMode.Password if hidden else QLineEdit.EchoMode.Normal)
        self.secret_replace.setChecked(False)
        self.log_view.clear()
        self.tails.clear()
        self.log_notice.setText('Bounded tail; sensitive values are hidden.' if hidden else
                                'Sensitive values are visible. This affects only this Console, not logfile.txt.')
        self.save_display_settings()
        if self.selected:
            self.load_config(self.file_choice.currentText())
            self.follow_log(force=True)

    def save_display_settings(self):
        key = 'display-settings-save'
        if key in self.work.pending:
            return
        hidden = self.hide_sensitive
        def done(value, error):
            if error:
                self.message(error)
            if hidden != self.hide_sensitive:
                self.save_display_settings()
        self.work.submit(key, lambda: self.backend.save_display_settings(hidden), done, priority=1)

    def page(self, title):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 14, 12, 12)
        layout.setSpacing(12)
        self.tabs.addTab(page, title)
        return layout

    def _dashboard(self):
        layout = self.page('Dashboard')
        self.dashboard_note = label('Runtime connection and OS service status are separate. Unknown does not mean stopped.', 'muted')
        self.dashboard_note.setWordWrap(True)
        layout.addWidget(self.dashboard_note)
        self.fleet = table(['Instance', 'Console connection', 'Controller state', 'Players', 'Spectators', 'Uptime'])
        self.fleet.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.fleet.itemSelectionChanged.connect(self.fleet_selection_changed)
        self.fleet.cellDoubleClicked.connect(self.select_fleet_row)
        self.fleet.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.fleet.customContextMenuRequested.connect(self.fleet_context)
        layout.addWidget(self.fleet, 1)
        self.context_label = label('Mode / phase / map context will appear here.', 'muted')
        self.context_label.setWordWrap(True)
        layout.addWidget(self.context_label)

    def _services(self):
        layout = self.page('Services')
        note = label('Control this server below. Launchers, maintenance and advanced options are in Server actions. '
                     'Stopping the dedicated server disconnects players.', 'muted')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.server_menu = QMenu(self)
        self.server_menu.aboutToShow.connect(lambda: self.populate_server_menu(self.server_menu))
        self.server_actions = QPushButton('Server actions')
        self.server_actions.setMenu(self.server_menu)
        toolbar = QHBoxLayout()
        toolbar.addStretch()
        toolbar.addWidget(self.server_actions)
        layout.addLayout(toolbar)
        self.service_table = table(['Component', 'Process / service state', 'Startup', 'Readiness'])
        layout.addWidget(self.service_table, 1)
        controls = QHBoxLayout()
        self.service_target = QComboBox()
        self.service_target.addItems(['controller', 'dedicated', 'both'])
        controls.addWidget(self.service_target)
        self.service_buttons = []
        for caption, action in (('Start', 'start'), ('Stop', 'stop'), ('Restart', 'restart'),
                                ('Automatic startup', 'enable'), ('Manual startup', 'disable')):
            if action in {'enable', 'disable'}:
                item = QAction(caption, self)
                item.triggered.connect(lambda _checked=False, a=action: self.service_action(a))
            else:
                item = button(caption, lambda _checked=False, a=action: self.service_action(a))
                controls.addWidget(item)
            self.service_buttons.append(item)
            item.setProperty('service_action', action)
        layout.addLayout(controls)
        self.service_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.service_table.customContextMenuRequested.connect(self.service_context)

    def populate_server_menu(self, menu):
        menu.clear()
        selected = self.selected_instances()
        if len(selected) > 1:
            menu.addSection(f'{len(selected)} instances selected')
            for target, caption in (('controller', 'Controllers'), ('dedicated', 'Dedicated servers'), ('both', 'Both components')):
                group = menu.addMenu(caption)
                for action in ('start', 'stop', 'restart'):
                    group.addAction(action.title(), lambda _checked=False, t=target, a=action: self.batch_action(selected, t, a))
            menu.addSeparator()
            menu.addAction('Refresh all servers', self.refresh_all)
            return
        sample = self.sample()
        services = sample.get('services', {})
        capable = bool(services.get('plan_attached') or services.get('management') == 'process')
        for target in ('controller', 'dedicated', 'both'):
            group = menu.addMenu({'controller': 'Controller', 'dedicated': 'Dedicated server', 'both': 'Both components'}[target])
            group.setEnabled(capable and (target == 'controller' or bool(services.get('owns_dedicated'))))
            for caption, action in (('Start', 'start'), ('Stop', 'stop'), ('Restart', 'restart')):
                group.addAction(caption, lambda _checked=False, t=target, a=action: self.service_action(a, target=t))
        runtime = menu.addMenu('Controller connection')
        runtime.setEnabled(bool(sample.get('online')))
        runtime.addAction('Graceful restart', lambda: self.runtime_action('controller.restart'))
        runtime.addAction('Graceful stop', lambda: self.runtime_action('controller.stop'))
        menu.addSeparator()
        for caption, callback in (('Configure existing launchers...', self.configure_launchers),
                ('Python and database checks...', self.prerequisites),
                ('Upgrade, rollback or uninstall...', self.program_maintenance),
                ('Duplicate instance...', self.duplicate_instance), ('Create backup ZIP...', self.backup_instance)):
            action = menu.addAction(caption, callback)
            action.setEnabled(self.selected is not None)
        advanced = menu.addMenu('Advanced')
        attach = advanced.addAction('Connect existing OS services...', self.attach_plan)
        attach.setEnabled(self.selected is not None)
        attach.setToolTip('For already installed Windows/systemd services only. Not needed for batch launchers.')
        startup = advanced.addMenu('OS service startup (selected target)')
        for action in self.service_buttons[3:]:
            startup.addAction(action)
        menu.addSeparator()
        menu.addAction('Refresh all servers', self.refresh_all)

    def instance_context(self, position):
        item = self.instance_list.itemAt(position)
        if item is None:
            return
        if not item.isSelected():
            self.instance_list.clearSelection()
            item.setSelected(True)
        self.instance_list.setCurrentItem(item, QItemSelectionModel.SelectionFlag.NoUpdate)
        menu = QMenu(self)
        self.populate_server_menu(menu)
        menu.exec(self.instance_list.viewport().mapToGlobal(position))

    def fleet_context(self, position):
        index = self.fleet.indexAt(position)
        if index.isValid():
            if not self.fleet.selectionModel().isRowSelected(index.row()):
                self.fleet.selectRow(index.row())
            self.fleet_selection_changed()
            menu = QMenu(self)
            self.populate_server_menu(menu)
            menu.exec(self.fleet.viewport().mapToGlobal(position))

    def selected_instances(self):
        ids = {item.data(Qt.ItemDataRole.UserRole) for item in self.instance_list.selectedItems() if not item.isHidden()}
        return [item for item in self.instances if item.id in ids] or ([self.selected] if self.selected else [])

    def fleet_selection_changed(self):
        selected = [self.instances[index.row()] for index in self.fleet.selectionModel().selectedRows()
                    if index.row() < len(self.instances)]
        if not selected:
            return
        ids = {item.id for item in selected}
        current = self.fleet.currentRow()
        primary = self.instances[current].id if 0 <= current < len(self.instances) and self.instances[current].id in ids else selected[0].id
        self.instance_list.blockSignals(True)
        active = None
        for index in range(self.instance_list.count()):
            item = self.instance_list.item(index)
            item.setSelected(item.data(Qt.ItemDataRole.UserRole) in ids)
            if item.data(Qt.ItemDataRole.UserRole) == primary:
                active = item
        if active:
            self.instance_list.setCurrentItem(active, QItemSelectionModel.SelectionFlag.NoUpdate)
        self.instance_list.blockSignals(False)
        if active and (not self.selected or self.selected.id != primary):
            self.select_instance(active)

    def duplicate_instance(self):
        if self.selected and not self.batch_ids:
            from .instance_dialogs import DuplicateDialog
            DuplicateDialog(self.backend, self.selected, self).exec()
            self.reload_instances()

    def backup_instance(self):
        if self.selected and not self.batch_ids:
            from .instance_dialogs import BackupDialog
            BackupDialog(self.backend, self.selected, self).exec()

    def batch_action(self, instances, target, action):
        if self.batch_ids or any(key.startswith(('action:', 'batch-review')) for key in self.work.pending):
            self.message('Another lifecycle operation is pending. Wait for its result.')
            return
        instances = tuple(instances)
        def reviewed(value, error):
            if error:
                self.message(error)
                return
            names = '\n'.join(item.name for item in instances)
            failures = sum(bool(row.get('error')) for row in value)
            if not self.confirm('Selected instances', action.upper() + ' ' + target + ' for:\n\n' + names +
                    f'\n\n{len(value) - failures} ready; {failures} blocked. Each instance is handled separately; failures do not stop the others.'
                    '\nDedicated stop/restart disconnects players. No forced process killing.', json.dumps(value, indent=2)):
                return
            dialog = QDialog(self)
            self.batch_dialog = dialog
            dialog.setWindowTitle('Bulk ' + action + ' - ' + target)
            dialog.resize(840, 430)
            layout = QVBoxLayout(dialog)
            layout.addWidget(label('Sequential execution. Completed OS requests do not guarantee runtime readiness; refresh status afterwards.', 'muted'))
            results = table(['Instance', 'Result'])
            rows(results, [[row['name'], 'Blocked: ' + row['error'] if row.get('error') else 'Queued'] for row in value])
            layout.addWidget(results)
            close = button('Close', dialog.reject)
            layout.addWidget(close)
            self.batch_ids = {item.id for item in instances}
            def next_row(index=0):
                while index < len(value) and value[index].get('error'):
                    index += 1
                if index >= len(value):
                    self.batch_ids.clear()
                    self.message('Bulk action finished. Review each instance result; no automatic retry was performed.')
                    self.refresh_all()
                    return
                row = value[index]
                results.item(index, 1).setText('Running...')
                def done(result, failure):
                    text = 'Failed: ' + failure if failure else 'Completed' + (' (OS request; check status)' if row['mode'] == 'service' else '')
                    results.item(index, 1).setText(text)
                    results.item(index, 1).setToolTip(text)
                    next_row(index + 1)
                if not self.work.submit('action:' + row['instance'], lambda: self.backend.batch_step(row), done, priority=1):
                    done(None, 'Queue busy; no command sent')
            dialog.show()
            next_row()
        self.work.submit('batch-review', lambda: self.backend.batch_review(instances, target, action), reviewed, priority=1)

    def service_context(self, position):
        index = self.service_table.indexAt(position)
        if index.isValid():
            self.service_target.setCurrentText('controller' if index.row() == 0 else 'dedicated')
        menu = QMenu(self)
        self.populate_server_menu(menu)
        menu.exec(self.service_table.viewport().mapToGlobal(position))

    def configure_launchers(self):
        if self.selected is None:
            return
        selected, generation = self.selected, self.selection_generation
        def done(value, error):
            if error:
                self.message(error)
            elif self.is_current(selected, generation):
                from .launchers import LaunchersDialog
                LaunchersDialog(self.backend, selected, value, self).exec()
                self.refresh_all()
        self.work.submit('launch-profile:' + selected.id, lambda: self.backend.launch_profile(selected), done, priority=1)

    def prerequisites(self):
        if self.selected is not None:
            from .prerequisites import PrerequisitesDialog
            PrerequisitesDialog(self.selected.python, controller=self.selected.controller,
                                instance_id=self.selected.id, parent=self).exec()

    def program_maintenance(self):
        if self.selected is None:
            return
        from .maintenance import MaintenanceDialog
        MaintenanceDialog(self.backend, self.selected, self).exec()
        self.reload_instances()

    def _apps(self):
        layout = self.page('Apps')
        layout.addWidget(label('Enable/disable changes the next-start loadout. Reload applies supported configuration only.', 'muted'))
        self.apps_table = table(['App', 'Configured', 'Loaded', 'Started', 'Pending restart', 'Reload'])
        layout.addWidget(self.apps_table, 1)
        self.apps_table.itemSelectionChanged.connect(self.app_selected)
        actions = QHBoxLayout()
        self.app_menu = QMenu(self)
        self.enable_app = self.app_menu.addAction('Enable for next start', lambda: self.app_state(True))
        self.disable_app = self.app_menu.addAction('Disable for next start', lambda: self.app_state(False))
        self.reload_app = self.app_menu.addAction('Reload configuration', self.app_reload)
        self.app_menu.addSeparator()
        self.app_menu.addAction('Open configuration', self.app_configuration)
        self.app_menu.addAction('Refresh apps', self.load_apps)
        more = QPushButton('App actions')
        more.setMenu(self.app_menu)
        actions.addWidget(button('Open configuration', self.app_configuration))
        actions.addWidget(more)
        self.apps_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.apps_table.customContextMenuRequested.connect(self.app_context)
        actions.addStretch()
        layout.addLayout(actions)
        self.app_note = label('Select an app.', 'muted')
        self.app_note.setWordWrap(True)
        layout.addWidget(self.app_note)

    def app_context(self, position):
        index = self.apps_table.indexAt(position)
        if index.isValid():
            self.apps_table.selectRow(index.row())
            self.app_menu.exec(self.apps_table.viewport().mapToGlobal(position))

    def _configuration(self):
        layout = self.page('Configuration')
        toolbar = QHBoxLayout()
        self.file_choice = QComboBox()
        self.file_choice.setMinimumContentsLength(25)
        self.file_choice.currentTextChanged.connect(self.load_config)
        toolbar.addWidget(self.file_choice, 1)
        self.config_menu = QMenu(self)
        self.config_menu.addAction('Refresh file', lambda: self.load_config(self.file_choice.currentText()))
        self.config_menu.addAction('Restore a recent backup...', self.restore_backup)
        more = QPushButton('File actions')
        more.setMenu(self.config_menu)
        toolbar.addWidget(more)
        layout.addLayout(toolbar)
        self.config_note = label('Select an exact branch. No race/score/gamemode target is guessed.', 'muted')
        self.config_note.setWordWrap(True)
        layout.addWidget(self.config_note)
        splitter = QSplitter()
        self.config_tree = QTreeWidget()
        self.config_tree.setHeaderLabels(['Setting / Branch', 'Value', 'Type'])
        self.config_tree.setColumnWidth(0, 260)
        self.config_tree.setColumnWidth(1, 200)
        self.config_tree.currentItemChanged.connect(self.config_selected)
        splitter.addWidget(self.config_tree)
        editor = QWidget()
        form = QVBoxLayout(editor)
        self.key_label = label('Choose a setting', 'eyebrow')
        self.key_label.setWordWrap(True)
        form.addWidget(self.key_label)
        self.value_edit = QLineEdit()
        self.value_edit.setMaxLength(12000)
        self.value_edit.setPlaceholderText('String, number, boolean, or JSON array')
        form.addWidget(self.value_edit)
        self.value_bool = QComboBox()
        self.value_bool.addItems(['Enabled / true', 'Disabled / false'])
        self.value_bool.setVisible(False)
        form.addWidget(self.value_bool)
        self.secret_replace = QCheckBox('Replace this secret (blank means clear)')
        self.secret_replace.setVisible(False)
        form.addWidget(self.secret_replace)
        self.type_note = label('Strings stay strings, including legacy "true" flags.', 'muted')
        self.type_note.setWordWrap(True)
        form.addWidget(self.type_note)
        self.apply_config = QCheckBox('Apply supported runtime reload after saving')
        self.apply_config.setChecked(True)
        form.addWidget(self.apply_config)
        self.validate_button = button('Validate change', lambda: self.config_action(validate=True))
        self.save_button = button('Save setting', self.config_action, 'primary')
        self.validate_button.setEnabled(False)
        self.save_button.setEnabled(False)
        form.addWidget(self.validate_button)
        form.addWidget(self.save_button)
        form.addStretch()
        splitter.addWidget(editor)
        splitter.setSizes([620, 300])
        layout.addWidget(splitter, 1)

    def _console(self):
        layout = self.page('Console')
        sources = QHBoxLayout()
        sources.addWidget(label('Log source', 'eyebrow'))
        self.log_choice = QComboBox()
        self.log_choice.addItems(['logfile.txt', LATEST])
        self.log_choice.currentTextChanged.connect(self.log_source_changed)
        sources.addWidget(self.log_choice, 1)
        sources.addWidget(button('Refresh sources', self.refresh_log_sources))
        layout.addLayout(sources)
        controls = QHBoxLayout()
        self.follow = QCheckBox('Follow selected log')
        self.follow.setChecked(True)
        controls.addWidget(self.follow)
        controls.addWidget(button('Read recent log', lambda: self.follow_log(force=True)))
        controls.addWidget(button('Check last operation', self.check_operation))
        controls.addStretch()
        layout.addLayout(controls)
        self.operation_label = label('No operation submitted. There is no unrestricted command shell.', 'muted')
        self.operation_label.setWordWrap(True)
        layout.addWidget(self.operation_label)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(2000)
        self.log_view.setStyleSheet('font-family: "Cascadia Mono", "DejaVu Sans Mono"; font-size: 12px;')
        layout.addWidget(self.log_view, 1)
        self.log_notice = label('Bounded tail; known secrets are redacted. This is not a complete audit log.', 'muted')
        layout.addWidget(self.log_notice)

    def message(self, text):
        self.statusBar().showMessage(text)

    def confirm(self, title, text, details=None):
        dialog = QMessageBox(self)
        dialog.setWindowTitle(title)
        dialog.setTextFormat(Qt.TextFormat.PlainText)
        dialog.setText(text)
        if details:
            dialog.setDetailedText(details)
            text_label = dialog.findChild(QLabel, 'qt_msgbox_label')
            if text_label:
                text_label.setMinimumWidth(560)
        dialog.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)
        dialog.setDefaultButton(QMessageBox.StandardButton.Cancel)
        return dialog.exec() == QMessageBox.StandardButton.Ok

    def reload_instances(self):
        def done(value, error):
            if error:
                self.message(error)
                return
            previous = self.selected.id if self.selected else None
            previous_ids = {item.data(Qt.ItemDataRole.UserRole) for item in self.instance_list.selectedItems()}
            self.instances = value
            self.instance_list.blockSignals(True)
            self.instance_list.clear()
            for instance in value:
                item = QListWidgetItem(instance.name + '\nNot sampled')
                item.setData(Qt.ItemDataRole.UserRole, instance.id)
                item.setToolTip(instance.controller)
                self.instance_list.addItem(item)
                item.setSelected(instance.id in previous_ids)
                if instance.id == previous:
                    self.instance_list.setCurrentItem(item, QItemSelectionModel.SelectionFlag.NoUpdate)
            self.instance_list.blockSignals(False)
            if self.instance_list.currentRow() < 0 and value:
                self.instance_list.setCurrentRow(0)
            self.registry_label.setText(f'{len(value)} registered instance(s)\nIndependent controller processes')
            self.filter_instances()
            self.refresh_all()
        self.work.submit('registry', self.backend.instances, done)

    def filter_instances(self):
        query = self.search.text().casefold()
        for index in range(self.instance_list.count()):
            item = self.instance_list.item(index)
            item.setHidden(query not in item.text().casefold())

    def register_installation(self):
        dialog = RegisterDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        arguments = (dialog.folder.text(), dialog.name.text(), dialog.python.text(), dialog.dedicated.text())
        self.work.submit('register', lambda: self.backend.register(*arguments),
            lambda value, error: self.message(error) if error else self.reload_instances(), priority=1)

    def install_controller(self):
        from .setup import SetupDialog
        if SetupDialog(self.backend, self).exec() == QDialog.DialogCode.Accepted:
            self.reload_instances()

    def select_instance(self, item, _previous=None):
        if item is None:
            return
        identity = item.data(Qt.ItemDataRole.UserRole)
        previous_file = self.file_choice.currentText()
        self.selected = next(instance for instance in self.instances if instance.id == identity)
        self.selection_generation += 1
        self.config_generation += 1
        self.config_data = None
        self.config_tree.clear()
        self.value_edit.clear()
        self.value_edit.setVisible(True)
        self.value_bool.setVisible(False)
        self.app_data = []
        self.apps_table.setRowCount(0)
        self.log_view.clear()
        self.log_generation += 1
        self.tails.clear()
        self.log_choice.blockSignals(True)
        self.log_choice.clear()
        self.log_choice.addItems(['logfile.txt', LATEST])
        self.log_choice.blockSignals(False)
        previous_operation = self.last_operations.get(self.selected.id)
        self.operation_label.setText('Last request for this instance: ' + previous_operation[0]
                                     if previous_operation else 'No operation submitted for this instance.')
        self.title.setText(self.selected.name)
        self.subtitle.setText(self.selected.controller)
        self.subtitle.setToolTip(self.selected.controller)
        self.render_selected()
        selected, generation = self.selected, self.selection_generation
        def files(value, error):
            if not self.is_current(selected, generation):
                return
            if error:
                self.message(error)
                return
            self.file_choice.blockSignals(True)
            self.file_choice.clear()
            self.file_choice.addItems(value)
            preferred = previous_file if previous_file in value else '.env' if '.env' in value else 'config.toml'
            index = self.file_choice.findText(preferred)
            self.file_choice.setCurrentIndex(max(0, index))
            self.file_choice.blockSignals(False)
            if value:
                self.load_config(self.file_choice.currentText())
        self.work.submit(f'files:{selected.id}:{generation}', lambda: self.backend.config_files(selected), files)
        self.load_apps()
        self.tab_changed(self.tabs.currentIndex())

    def is_current(self, instance, generation):
        return self.selected is not None and self.selected.id == instance.id and generation == self.selection_generation

    def sample(self):
        return self.samples.get(self.selected.id, {}) if self.selected else {}

    def refresh_all(self):
        for instance in self.instances:
            def done(value, error, instance=instance):
                if error:
                    self.message(instance.name + ': ' + error)
                    return
                self.samples[instance.id] = value
                for index in range(self.instance_list.count()):
                    item = self.instance_list.item(index)
                    if item.data(Qt.ItemDataRole.UserRole) == instance.id:
                        process = value.get('services', {}).get('controller', {}).get('state')
                        detail = ('Connected' if value['online'] else 'Stopped' if process == 'stopped' else
                                  'Running / no connection' if process == 'running' else 'Connection unavailable')
                        text = instance.name + '\n' + detail
                        if item.text() != text:
                            item.setText(text)
                self.render_fleet()
                if self.selected and self.selected.id == instance.id:
                    self.render_selected()
                    if self.tabs.currentIndex() == 2:
                        self.load_apps()
            self.work.submit('poll:' + instance.id, lambda instance=instance: self.backend.poll(instance), done)

    def render_fleet(self):
        values = []
        for instance in self.instances:
            sample = self.samples.get(instance.id, {})
            runtime = sample.get('runtime') or {}
            elapsed = runtime.get('uptime_seconds')
            values.append([instance.name, 'Connected' if sample.get('online') else 'Unavailable / unknown',
                sample.get('services', {}).get('controller', {}).get('state', 'Unknown'),
                runtime.get('players', '-'), runtime.get('spectators', '-'),
                f'{elapsed // 3600}h {(elapsed % 3600) // 60}m' if elapsed is not None else '-'])
        self.fleet.blockSignals(True)
        rows(self.fleet, values)
        self.fleet.blockSignals(False)

    def select_fleet_row(self, row, _column=None):
        if row < len(self.instances):
            self.instance_list.setCurrentRow(row)

    def render_selected(self):
        sample = self.sample()
        runtime = sample.get('runtime') or {}
        services = sample.get('services', {})
        online = sample.get('online', False)
        controller_state = services.get('controller', {}).get('state')
        self.cards['CONTROLLER'].setText('Starting' if runtime.get('starting') else 'Connected' if online else
            'Stopped' if controller_state == 'stopped' else 'Running / no connection' if controller_state == 'running' else 'Unknown / offline')
        self.cards['DEDICATED SERVER'].setText(services.get('dedicated', {}).get('state', 'Unknown').replace('-', ' ').capitalize())
        self.cards['PLAYERS / SPECTATORS'].setText(f'{runtime.get("players", "-")} / {runtime.get("spectators", "-")}')
        self.cards['DATABASE / PROVIDERS'].setText('Not probed')
        context = runtime.get('context', {})
        self.context_label.setText(f'Mode: {context.get("mode", "unknown")}  |  Phase: {context.get("phase", "unknown")}  |  '
                                   f'Track: {runtime.get("track_name", "unknown")}\n'
                                   + (sample.get('runtime_error') or 'Authenticated local runtime snapshot.')
                                   + ('  Sampled ' + time.strftime('%H:%M:%S', time.localtime(sample['sampled_at']))
                                      if sample.get('sampled_at') else ''))
        rows(self.service_table, [[target.title(), services.get(target, {}).get('state', 'Unknown'),
            services.get(target, {}).get('startup', 'Existing launcher / manual' if services.get('management') == 'process' else 'Unknown'),
            services.get(target, {}).get('reason') or ('Use runtime snapshot' if target == 'controller' else 'Not probed')]
            for target in ('controller', 'dedicated')])
        for item in self.service_buttons:
            manual = services.get('management') == 'process'
            multiple = len(self.selected_instances()) > 1
            item.setEnabled(bool(services.get('plan_attached')) or (manual or multiple) and item.property('service_action') in {'start', 'stop', 'restart'})
            item.setToolTip('Automatic startup options require an OS service plan.' if manual and item.property('service_action') in {'enable', 'disable'} else '')
        self.service_target.model().item(1).setEnabled(bool(services.get('owns_dedicated')) or len(self.selected_instances()) > 1)
        self.service_target.model().item(2).setEnabled(bool(services.get('owns_dedicated')) or len(self.selected_instances()) > 1)

    def tab_changed(self, index):
        if self.selected and index == 2:
            self.load_apps()
        if self.selected and index == 4:
            self.refresh_log_sources()

    def load_apps(self):
        if not self.selected:
            return
        selected, generation = self.selected, self.selection_generation
        online = bool(self.sample().get('online'))
        def done(value, error):
            if not self.is_current(selected, generation):
                return
            if error:
                self.message(error)
                return
            previous = self.selected_app()
            previous_id = previous['id'] if previous else None
            self.app_data, self.app_revision = value['apps'], value['revision']
            rows(self.apps_table, [[row['name'], state(row['configured_enabled']), state(row['runtime_loaded']),
                state(row.get('runtime_started')), state(row.get('pending_restart')),
                'Available' if row.get('reload_supported') else 'Restart / offline'] for row in self.app_data])
            for index, row in enumerate(self.app_data):
                if row['id'] == previous_id:
                    self.apps_table.selectRow(index)
            self.app_selected()
        self.work.submit(f'apps:{selected.id}:{generation}', lambda: self.backend.apps(selected, online), done)

    def selected_app(self):
        row = self.apps_table.currentRow()
        return self.app_data[row] if 0 <= row < len(self.app_data) else None

    def app_selected(self):
        row = self.selected_app()
        manageable = bool(row and row['id'] in MANAGEABLE_STANDALONE_APPS and not row['protected'] and not row['metadata_error'])
        self.enable_app.setEnabled(manageable)
        self.disable_app.setEnabled(manageable)
        self.reload_app.setEnabled(bool(row and row.get('reload_supported') and self.sample().get('online')))
        self.app_note.setText((row.get('metadata_error') or ('Protected loadout entry.' if row['protected'] else
            'Dependencies: ' + (', '.join(row['dependencies']) or 'none'))) if row else 'Select an app.')

    def app_state(self, enabled):
        row = self.selected_app()
        if row:
            self.submit({'kind': 'app.state', 'app': row['id'], 'enabled': enabled, 'revision': self.app_revision},
                        f'{"Enable" if enabled else "Disable"} {row["name"]} for the next controller start?')

    def app_reload(self):
        row = self.selected_app()
        if row:
            self.runtime_action('app.reload', app=row['id'])

    def app_configuration(self):
        row = self.selected_app()
        if row:
            path = f'apps/{row["id"]}/app_defaults.toml'
            index = self.file_choice.findText(path)
            if index >= 0:
                self.file_choice.setCurrentIndex(index)
                self.tabs.setCurrentIndex(3)
            else:
                self.message('This app has no editable app_defaults.toml.')

    def load_config(self, relative):
        if not self.selected or not relative:
            return
        self.config_generation += 1
        config_generation = self.config_generation
        selected, generation = self.selected, self.selection_generation
        hidden = self.hide_sensitive
        self.config_data = None
        self.config_tree.clear()
        self.value_edit.clear()
        dedicated = relative in CONFIGS
        self.apply_config.setEnabled(not dedicated)
        self.apply_config.setVisible(not dedicated)
        self.apply_config.setToolTip('Dedicated XML saves affect disk only; no automatic restart or match reload.' if dedicated else '')
        def done(value, error):
            if not self.is_current(selected, generation) or self.config_generation != config_generation:
                return
            if error:
                self.message(error)
                return
            self.config_data = value
            self.config_context = (self.sample().get('runtime') or {}).get('context')
            notes = ' '.join(value.get('notes', []))
            self.config_note.setText(('Dedicated-server configuration. ' if dedicated else 'Explicit file/branch; no target is guessed. ') + notes)
            def add(parent, data, path=()):
                for key, item in data.items():
                    entry = QTreeWidgetItem(parent, [key])
                    keys = (*path, key)
                    if isinstance(item, dict):
                        add(entry, item, keys)
                    else:
                        entry.setText(1, '********' if hidden and self.config_secret(keys) else str(item)[:120])
                        entry.setText(2, type(item).__name__)
                        entry.setData(0, Qt.ItemDataRole.UserRole, (keys, item))
            add(self.config_tree.invisibleRootItem(), value['values'])
            self.config_tree.expandToDepth(0)
        if not self.work.submit('config:' + selected.id + ':' + str(config_generation),
                lambda: self.backend.read(selected, relative, hide_sensitive=hidden), done, priority=1):
            self.message('Read queue is busy. Wait briefly, then refresh this file.')

    def config_secret(self, path):
        return xml_secret(path) if self.file_choice.currentText() in CONFIGS else secret_key(path)

    def config_selected(self, entry, _previous=None):
        data = entry.data(0, Qt.ItemDataRole.UserRole) if entry else None
        self.value_edit.clear()
        self.value_edit.setVisible(True)
        self.value_bool.setVisible(False)
        self.secret_replace.setChecked(False)
        self.secret_replace.setVisible(False)
        if not data:
            self.key_label.setText('Choose a setting')
            self.save_button.setEnabled(False)
            self.validate_button.setEnabled(False)
            return
        path, value = data
        secret = self.config_secret(path)
        self.secret_replace.setVisible(secret)
        self.value_edit.setEchoMode(QLineEdit.EchoMode.Password if secret and self.hide_sensitive else QLineEdit.EchoMode.Normal)
        if not secret or not self.hide_sensitive:
            try:
                encoded = value if isinstance(value, str) else json.dumps(value, ensure_ascii=True, allow_nan=False)
            except (TypeError, ValueError):
                self.value_edit.setText(str(value))
                self.key_label.setText(' / '.join(path))
                self.type_note.setText('This value is read-only here; use a local editor for this TOML type.')
                self.save_button.setEnabled(False)
                self.validate_button.setEnabled(False)
                return
            if len(encoded) > self.value_edit.maxLength() or '\n' in encoded or '\r' in encoded:
                self.value_edit.setText(encoded[:200] + '...')
                self.key_label.setText(' / '.join(path))
                self.type_note.setText('Long or multiline value: read-only here. Use a local editor; no truncating save is allowed.')
                self.save_button.setEnabled(False)
                self.validate_button.setEnabled(False)
                return
            self.value_edit.setText(encoded)
            if type(value) is bool:
                self.value_edit.setVisible(False)
                self.value_bool.setVisible(True)
                self.value_bool.setCurrentIndex(0 if value else 1)
        self.key_label.setText(' / '.join(path))
        self.type_note.setText('XML text. Saves affect disk only. Repeated elements are numbered; attribute rules are not edited here.'
            if self.file_choice.currentText() in CONFIGS else
            'Text. Legacy true/false flags remain text.' if isinstance(value, str) else
            'Boolean. Choose enabled or disabled.' if type(value) is bool else
            'Array. Enter a JSON list.' if isinstance(value, list) else
            'Number. Decimal geometry values are supported; counts remain integers.')
        editable = self.file_choice.currentText() != 'apps.toml'
        self.save_button.setEnabled(editable)
        self.validate_button.setEnabled(editable)

    def config_action(self, _checked=False, *, validate=False):
        entry = self.config_tree.currentItem()
        data = entry.data(0, Qt.ItemDataRole.UserRole) if entry else None
        if not data or not self.config_data or not self.save_button.isEnabled():
            return
        path, old = data
        if self.config_secret(path) and not self.secret_replace.isChecked():
            self.message('Check Replace this secret before saving a password or other sensitive value.')
            return
        try:
            value = (self.value_bool.currentIndex() == 0) if type(old) is bool else self.value_edit.text() if isinstance(old, str) else json.loads(self.value_edit.text())
        except ValueError:
            self.message('Invalid JSON value. Strings do not need surrounding quotes.')
            return
        payload = {'kind': 'config.validate' if validate else 'config.write', 'file': self.file_choice.currentText(),
            'path': list(path), 'value': value, 'revision': self.config_data['revision'],
            'apply': self.apply_config.isChecked()}
        if self.config_context:
            payload['context'] = self.config_context
        if payload['file'] in CONFIGS:
            self.submit_dedicated(payload)
        else:
            self.submit(payload, 'Validate this setting?' if validate else 'Save this exact file/branch? A backup will be created.')

    def submit_dedicated(self, payload):
        selected, generation = self.selected, self.selection_generation
        validating = payload['kind'] == 'config.validate'
        if not validating and not self.confirm('Save dedicated-server file', selected.name + '\n' + payload['file'] +
                '\n\nSave on disk with a backup? No server restart or match reload will be performed.'
                '\nRunning settings remain unchanged until the next start or explicit settings load.'):
            return
        config_generation = self.config_generation
        def done(value, error):
            if error:
                self.message(error)
                return
            if not self.is_current(selected, generation):
                return
            self.show_operation(value)
            if not validating and config_generation == self.config_generation:
                self.load_config(payload['file'])
        if not self.work.submit('action:' + selected.id, lambda: self.backend.edit_dedicated(selected, payload), done, priority=1):
            self.message('Another operation is pending for this instance; no write performed.')

    def restore_backup(self):
        if not self.selected or not self.config_data:
            return
        selected, generation = self.selected, self.selection_generation
        relative, config_generation = self.file_choice.currentText(), self.config_generation
        revision = self.config_data['revision']
        def done(value, error):
            if not self.is_current(selected, generation) or config_generation != self.config_generation:
                return
            if error:
                self.message(error)
                return
            if not value:
                self.message('No recent backups for this file.')
                return
            chosen, accepted = QInputDialog.getItem(self, 'Restore backup', 'Whole-file restore; current file is backed up first:', value, 0, False)
            if accepted:
                payload = {'kind': 'config.restore', 'file': relative, 'backup': chosen, 'revision': revision,
                           'apply': self.apply_config.isChecked()}
                if self.config_context:
                    payload['context'] = self.config_context
                if relative in CONFIGS:
                    self.submit_dedicated(payload)
                else:
                    self.submit(payload, 'Restore this entire file from backup?')
        self.work.submit('backups:' + selected.id, lambda: self.backend.backups(selected, relative), done)

    def runtime_action(self, kind, **fields):
        self.submit({'kind': kind, **fields}, 'Request ' + kind + '?', runtime_only=True)

    def submit(self, payload, confirmation, *, runtime_only=False):
        if not self.selected:
            return
        if self.selected.id in self.batch_ids:
            self.message('A bulk lifecycle action is pending for this instance.')
            return
        selected, generation = self.selected, self.selection_generation
        online = runtime_only or self.edit_mode.currentIndex() == 0
        sample = self.sample()
        if online and not sample.get('online'):
            self.message('Runtime bridge unavailable. No write or offline fallback performed. Select Stopped controller explicitly for offline edits.')
            return
        if not self.confirm('Confirm for ' + selected.name, confirmation + '\n\n' + selected.controller +
                            ('\nAuthenticated running controller.' if online else '\nOffline mode: controller must be stopped.')):
            return
        run_id = (sample.get('runtime') or {}).get('context', {}).get('run_id') if online else None
        if 'action:' + selected.id in self.work.pending:
            self.message('Another operation is already pending for this instance. No new command sent.')
            return
        request_id = uuid4().hex
        def done(value, error):
            if error:
                self.message(selected.name + ': ' + error)
                if self.is_current(selected, generation):
                    self.operation_label.setText(error)
                return
            if not self.is_current(selected, generation):
                self.message(selected.name + ': operation returned ' + value.get('state', 'unknown'))
                return
            self.show_operation(value)
            if payload['kind'] in {'controller.stop', 'controller.restart'}:
                self.refresh_all()
                return
            if payload['kind'] != 'config.validate':
                self.value_edit.clear()
                self.secret_replace.setChecked(False)
                self.load_apps()
                self.load_config(self.file_choice.currentText())
                self.refresh_all()
        accepted = self.work.submit('action:' + selected.id,
            lambda: self.backend.execute(selected, payload, online=online, request_id=request_id, run_id=run_id), done, priority=1)
        if not accepted:
            self.message('Another operation is already pending for this instance. No new command sent.')
        else:
            self.last_operations[selected.id] = (request_id, run_id)
            self.operation_label.setText(f'{payload["kind"]} | request {request_id} | run {run_id or "offline"}')

    def show_operation(self, value):
        result = value.get('result') or {}
        message = value.get('state', 'unknown')
        if result.get('saved'):
            message += ' | saved on disk'
        if result.get('runtime_applied'):
            message += ' | runtime applied'
        if result.get('disk_only'):
            message += ' | disk only; no restart or match reload performed'
        if result.get('validated'):
            message += ' | XML syntax valid; dedicated-server rules are checked when the server loads it'
        if result.get('restart_required'):
            message += ' | restart required'
        if result.get('error'):
            message += ' | ' + result['error']
        if value.get('state') == 'accepted':
            message += ' | confirm with OS status / next run identity'
        if value.get('kind') in {'controller.stop', 'controller.restart'} and value.get('state') == 'queued':
            message += ' | queued only; confirm with OS status / next run identity'
        self.message(message)
        self.operation_label.setText(message + (' | request ' + value['id'] if value.get('id') else ''))

    def check_operation(self):
        if not self.selected:
            return
        selected, generation = self.selected, self.selection_generation
        operation = self.last_operations.get(selected.id)
        if not operation or not operation[1]:
            self.message('No runtime operation ID for this instance.')
            return
        self.work.submit('result:' + selected.id, lambda: self.backend.operation(selected, *operation),
            lambda value, error: self.message(error) if error else self.show_operation(value) if self.is_current(selected, generation) else None)

    def attach_plan(self):
        if not self.selected:
            return
        selected = self.selected
        if not self.confirm('Existing OS services only',
                'This connects controls to already installed Windows or systemd services using their saved service plan.'
                '\nBatch-launched servers do not need this. No service is installed by this action. Continue?'):
            return
        path = QFileDialog.getOpenFileName(self, 'Select plan for existing OS services', '', 'Service plan (*.json)')[0]
        if path and self.confirm('Attach plan', f'Enable controls for existing services of {selected.name}?\n{path}\nNo service will be installed or started.'):
            self.work.submit('plan:' + selected.id, lambda: self.backend.attach_plan(selected, path),
                lambda value, error: self.message(error) if error else self.refresh_all(), priority=1)

    def service_action(self, action, *, target=None):
        if not self.selected:
            return
        if self.batch_ids:
            self.message('A bulk lifecycle action is still running; wait for its results.')
            return
        if len(self.selected_instances()) > 1 and action in {'start', 'stop', 'restart'}:
            self.batch_action(self.selected_instances(), target or self.service_target.currentText(), action)
            return
        selected, target = self.selected, target or self.service_target.currentText()
        if self.sample().get('services', {}).get('management') == 'process':
            generation = self.selection_generation
            def reviewed(value, error):
                if error:
                    self.message(error)
                    return
                if not self.is_current(selected, generation):
                    return
                if not self.confirm('Local process action', action.upper() + ' ' + target + ' for ' + selected.name + '?\n\n' +
                        launch_summary(value) + '\n\nLaunchers run unchanged under your account. Stops are graceful; no forced killing.',
                        json.dumps(value, indent=2)):
                    return
                def done(result, failure):
                    self.message(failure or selected.name + ': process action completed; refresh the live controller status for readiness.')
                    self.refresh_all()
                if not self.work.submit('action:' + selected.id,
                        lambda: self.backend.process_action(selected, target, action, reviewed=value['review']), done, priority=1):
                    self.message('Another operation is pending; no process action sent.')
            self.work.submit('process-review:' + selected.id, lambda: self.backend.preview_launchers(selected), reviewed, priority=1)
            return
        if not self.confirm('OS service action', f'{action.upper()} {target} for {selected.name}?\n{selected.controller}\n'
                            'No automatic elevation or process-kill fallback is used.'):
            return
        def done(value, error):
            self.message(error or f'{selected.name}: OS request completed; this is not proof of runtime readiness.')
            self.refresh_all()
        if not self.work.submit('action:' + selected.id, lambda: self.backend.service_action(selected, target, action), done, priority=1):
            self.message('An operation is already pending; no service action sent.')

    def refresh_log_sources(self):
        if not self.selected:
            return
        selected, generation = self.selected, self.selection_generation
        def done(value, error):
            if not self.is_current(selected, generation):
                return
            if error:
                self.log_notice.setText(error)
                return
            previous = self.log_choice.currentText()
            self.log_choice.blockSignals(True)
            self.log_choice.clear()
            self.log_choice.addItems(value)
            self.log_choice.setCurrentIndex(max(0, self.log_choice.findText(previous)))
            self.log_choice.blockSignals(False)
            if previous != self.log_choice.currentText():
                self.log_source_changed()
            else:
                self.follow_log()
        self.work.submit(f'log-sources:{selected.id}:{generation}', lambda: self.backend.log_sources(selected), done)

    def log_source_changed(self, _source=None):
        self.log_generation += 1
        self.tails.clear()
        self.log_view.clear()
        self.log_notice.setText('Reading selected log...')
        self.follow_log(force=True)

    def follow_log(self, *, force=False):
        if not self.selected or not (force or self.follow.isChecked()) or self.tabs.currentIndex() != 4:
            return
        selected, generation = self.selected, self.selection_generation
        privacy_generation, hidden = self.privacy_generation, self.hide_sensitive
        log_generation, source = self.log_generation, self.log_choice.currentText()
        # Construct/resolve filesystem sources in the worker, not on Qt's UI thread.
        key = (selected.id, source, log_generation, privacy_generation)
        def read():
            tail = self.tails.get(key)
            if tail is None:
                tail = self.backend.log_tail(selected, source)
                self.tails[key] = tail
            return tail.read(hide_sensitive=hidden)
        def done(value, error):
            if (not self.is_current(selected, generation) or privacy_generation != self.privacy_generation
                    or log_generation != self.log_generation):
                return
            if error:
                self.log_notice.setText(error)
                return
            if value['text']:
                self.log_view.appendPlainText(value['text'])
            self.log_notice.setText(value['notice'] or
                ('Sensitive values hidden. ' if hidden else 'Sensitive values visible. ') + 'Source: ' + source)
        self.work.submit(f'log:{selected.id}:{generation}:{privacy_generation}:{log_generation}', read, done)

    def closeEvent(self, event):
        if self.batch_ids or any(key.startswith(('action:', 'register', 'plan:', 'display-settings-save')) for key in self.work.pending):
            self.message('An explicitly requested operation is still running. Wait for its result before closing.')
            event.ignore()
            return
        self.timer.stop()
        self.log_timer.stop()
        self.work.close()
        event.accept()
