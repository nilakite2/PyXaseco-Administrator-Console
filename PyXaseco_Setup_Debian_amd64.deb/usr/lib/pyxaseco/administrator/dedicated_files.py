"""Local dedicated-server documents; file edits never issue runtime commands."""

from collections import Counter
from pathlib import Path
import re
from xml.parsers import expat
from xml.sax.saxutils import escape

from pyxaseco.management.config_store import ManagementError, revision, update_file
from pyxaseco.management.editing import secret_key


CONFIGS = {
    'GameData/Config/dedicated_cfg.txt': 'dedicated',
    'GameData/Tracks/MatchSettings/MatchSettings.txt': 'playlist',
}
LATEST = 'Logs/ConsoleLog.*.txt (latest)'
LIMIT = 4 * 1024 * 1024


def xml_secret(path):
    return bool(path and (secret_key((path[-1],)) or path[-1].split('[', 1)[0] == 'validation_key'))


def xml_fields(raw, root_name):
    """Index UTF-8 leaf spans so editing one value preserves unrelated XML bytes."""
    if len(raw) > LIMIT:
        raise ManagementError('XML exceeds the 4 MiB editing limit')
    try:
        raw.decode('utf-8-sig')
        parser = expat.ParserCreate('utf-8')
        stack, roots = [], []

        def reject(*_args):
            raise ManagementError('DTD and entity declarations are not supported')

        def start(name, attributes):
            offset = parser.CurrentByteIndex
            # Find the closing bracket outside quoted attribute values.
            quote, end = None, offset
            while end < len(raw):
                char = raw[end]
                if quote:
                    if char == quote:
                        quote = None
                elif char in (34, 39):
                    quote = char
                elif char == 62:
                    break
                end += 1
            node = {'name': name, 'children': [], 'text': [], 'start': end + 1,
                    'tag': offset, 'empty': raw[offset:end].rstrip().endswith(b'/'),
                    'attributes': attributes, 'comment': False}
            (stack[-1]['children'] if stack else roots).append(node)
            stack.append(node)

        def finish(_name):
            node = stack.pop()
            node['end'] = parser.CurrentByteIndex

        def characters(value):
            if stack:
                stack[-1]['text'].append(value)

        def comment(_value):
            if stack:
                stack[-1]['comment'] = True

        parser.StartElementHandler, parser.EndElementHandler = start, finish
        parser.CharacterDataHandler, parser.CommentHandler = characters, comment
        parser.StartDoctypeDeclHandler = reject
        parser.EntityDeclHandler = reject
        parser.ExternalEntityRefHandler = reject
        parser.Parse(raw, True)
    except (UnicodeError, expat.ExpatError) as exc:
        raise ManagementError('Invalid UTF-8 XML; no change was saved') from exc
    if len(roots) != 1 or roots[0]['name'] != root_name:
        raise ManagementError('Unexpected dedicated-server XML document type')
    fields = {}

    def walk(nodes, path=()):
        counts, seen, values = Counter(node['name'] for node in nodes), Counter(), {}
        for node in nodes:
            name = node['name']
            seen[name] += 1
            key = f'{name}[{seen[name]}]' if counts[name] > 1 else name
            keys = (*path, key)
            if node['children']:
                values[key] = walk(node['children'], keys)
            elif not node['attributes'] and not node['comment']:
                values[key] = ''.join(node['text'])
                fields[keys] = node
        return values

    return walk(roots), fields


class DedicatedFiles:
    def __init__(self, root):
        self.root = Path(root).resolve()

    def safe(self, relative):
        path = self.root / relative
        if not path.resolve().is_relative_to(self.root):
            raise ManagementError('Dedicated file escapes the instance folder')
        for parent in (path, *path.parents):
            if parent == self.root:
                break
            if parent.is_symlink() or getattr(parent, 'is_junction', lambda: False)():
                raise ManagementError('Dedicated file links are not followed')
        return path

    def path(self, relative):
        if relative not in CONFIGS:
            raise ManagementError('Choose one of the listed dedicated-server XML files')
        return self.safe(relative)

    def read(self, relative, *, hide_sensitive=True):
        file = self.path(relative)
        with file.open('rb') as stream:
            raw = stream.read(LIMIT + 1)
        values, _fields = xml_fields(raw, CONFIGS[relative])
        if hide_sensitive:
            def mask(data, path=()):
                return {key: mask(value, (*path, key)) if isinstance(value, dict) else
                        '********' if xml_secret((*path, key)) else value for key, value in data.items()}
            values = mask(values)
        return {'revision': revision(raw), 'values': values, 'format': 'dedicated-xml',
                'notes': [str(file), 'Saved for the next start or explicit settings load; no automatic restart or match reload.']}

    def edit(self, relative, path, value, *, expected, validate=False, backup=None):
        file = self.path(relative)
        if not isinstance(expected, str) or not re.fullmatch(r'[a-f0-9]{64}', expected):
            raise ManagementError('Refresh the file before editing')

        def change(text):
            if backup is not None:
                if backup not in self.backups(relative):
                    raise ManagementError('Choose a recent backup for this exact XML file')
                saved = self.safe(str(file.relative_to(self.root).parent / '.management-backups' / backup))
                with saved.open('rb') as stream:
                    raw = stream.read(LIMIT + 1)
                xml_fields(raw, CONFIGS[relative])
                return raw.decode('utf-8')
            if not isinstance(value, str):
                raise ManagementError('XML settings require text')
            raw = text.encode('utf-8')
            _values, fields = xml_fields(raw, CONFIGS[relative])
            node = fields.get(tuple(path))
            if node is None:
                raise ManagementError('Select an existing XML setting')
            encoded = escape(value).encode('utf-8')
            if node['empty']:
                opening = raw[node['tag']:node['start']]
                replacement = opening[:opening.rfind(b'/')] + b'>' + encoded + b'</' + node['name'].encode('utf-8') + b'>'
                raw = raw[:node['tag']] + replacement + raw[node['start']:]
            else:
                raw = raw[:node['start']] + encoded + raw[node['end']:]
            xml_fields(raw, CONFIGS[relative])
            return raw.decode('utf-8')

        if validate:
            with file.open('rb') as stream:
                raw = stream.read(LIMIT + 1)
            if revision(raw) != expected:
                raise ManagementError('Configuration changed since it was read; refresh before saving')
            change(raw.decode('utf-8'))
            return {'state': 'completed', 'result': {'validated': True}}
        self.safe(str(file.relative_to(self.root).parent / '.management-backups'))
        result = update_file(file, change, expected=expected,
                             validator=lambda text: xml_fields(text.encode('utf-8'), CONFIGS[relative]))
        return {'state': 'completed', 'result': {'saved': True, 'runtime_applied': False,
                'disk_only': True, 'backup': result.backup, 'revision': result.revision}}

    def backups(self, relative):
        file = self.path(relative)
        directory = self.safe(str(file.relative_to(self.root).parent / '.management-backups'))
        return [path.name for path in sorted(directory.glob(file.name + '.*.bak'), reverse=True)
                if path.is_file() and not path.is_symlink()][:30]

    def log_sources(self):
        directory = self.safe('Logs')
        if not directory.is_dir():
            return ['logfile.txt', LATEST]
        # Discover only when opening/refreshing Console, never in fleet polling.
        candidates = []
        for path in directory.iterdir():
            if re.fullmatch(r'(?:ConsoleLog\..+|GameLog\..+)\.txt', path.name) and not path.is_symlink() and path.is_file():
                candidates.append((path.stat().st_mtime_ns, path.name))
        # Frequent console rotations must not push the persistent per-login log out.
        newest = sorted([*sorted((row for row in candidates if row[1].startswith('ConsoleLog.')), reverse=True)[:25],
                         *sorted((row for row in candidates if row[1].startswith('GameLog.')), reverse=True)[:25]], reverse=True)
        return ['logfile.txt', LATEST, *['Logs/' + name for _stamp, name in newest]]

    def log_path(self, source):
        if source == LATEST:
            directory = self.safe('Logs')
            candidates = [path for path in directory.glob('ConsoleLog.*.txt') if path.is_file() and not path.is_symlink()]
            chosen = max(candidates, key=lambda path: (path.stat().st_mtime_ns, path.name), default=None)
            return self.safe('Logs/' + chosen.name) if chosen else self.safe('Logs/ConsoleLog.pending.txt')
        if (not re.fullmatch(r'Logs/(?:ConsoleLog\.[^/\\]+|GameLog\.[^/\\]+)\.txt', source)
                or any(ord(char) < 32 or char in ':*?"<>|' for char in source)):
            raise ManagementError('Choose a listed dedicated-server log')
        return self.safe(source)
