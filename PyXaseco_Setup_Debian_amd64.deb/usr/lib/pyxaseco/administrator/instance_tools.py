"""Explicit local cloning and ZIP backups. Never start or stop an instance."""

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import tomllib
from uuid import uuid4
import zipfile

from pyxaseco.management.config_store import ManagementError, file_lock, revision
from pyxaseco.management.credentials import initialize_bridge, protect_token
from pyxaseco.management.editing import edit_dotenv
from pyxaseco.management.installation import (InstallRequest, _configure_dedicated,
    _launch_script, _run, _spawn, safe_path, server_file_stem)
from pyxaseco.management.instances import read_dotenv
from pyxaseco.management.prerequisites import database_action, ensure_dependencies
from pyxaseco.toml_tools import update_toml_table_scalar


def server_root(instance):
    controller = safe_path(instance.controller)
    root = controller.parent
    if root == root.parent or not (root / 'GameData').is_dir():
        raise ManagementError('Choose an instance with its own dedicated-server folder and GameData')
    return root


def clone_excluded_directory(name, operational):
    return (name.lower() in {'__pycache__', '.git'} or name.startswith('.venv') or
            operational and (name.lower() in {'logs', 'state', 'venv', 'service-definitions', '.management-backups'}
                             or name.startswith(('.management', '.pyxaseco'))))


def inventory(root, *, clone=False, controller=None):
    result = []
    for current, dirs, names in os.walk(root, followlinks=False):
        current = Path(current)
        operational = current == root or current == controller
        kept = []
        for name in sorted(dirs):
            if clone and clone_excluded_directory(name, operational):
                continue
            safe_path(current / name)
            kept.append(name)
        dirs[:] = kept
        for name in sorted(names):
            if name.endswith('.lock'):
                continue
            if clone and operational and Path(name).suffix.lower() in {'.bat', '.cmd', '.sh'}:
                continue  # Only regenerated entrypoints may launch the copy; never carry source-targeting batch commands.
            if clone and operational and (name.lower() in {'management.toml', 'installation.json', 'trackhist.txt'}
                          or name.startswith(('.management', '.pyxaseco', 'logfile.txt'))):
                continue
            path = safe_path(current / name)
            if not path.is_relative_to(root) or not path.is_file():
                raise ManagementError('Only regular files inside the instance can be copied')
            info = path.stat()
            result.append((path.relative_to(root).as_posix(), info.st_size, info.st_mtime_ns))
    return sorted(result)


def database_settings(instance):
    root = Path(instance.controller)
    base = tomllib.loads(Path(instance.config).read_text(encoding='utf-8')).get('database', {})
    env = read_dotenv(root / '.env')
    values = {f'DB_{key.upper()}': env.get(f'DB_{key.upper()}') or str(base.get(key, default))
              for key, default in (('host', '127.0.0.1'), ('port', 3306), ('name', ''), ('user', ''))}
    values['DB_PASSWORD'] = env.get('DB_PASSWORD', str(base.get('password', '')))
    return values


def sql_tool(kind):
    names = ('mariadb-dump', 'mysqldump') if kind == 'dump' else ('mariadb', 'mysql')
    for name in names:
        found = shutil.which(name)
        if found:
            return str(Path(found).resolve())
    if os.name == 'nt':
        for directory in sorted(Path(os.environ.get('ProgramFiles', 'C:/Program Files')).glob('MariaDB*/bin'), reverse=True):
            for name in names:
                if (directory / (name + '.exe')).is_file():
                    return str(directory / (name + '.exe'))
    return ''


def sql_transfer(settings, file, program, *, export):
    """Passwords travel through a private option file, never command arguments."""
    executable = Path(program).expanduser().resolve()
    if not program or not executable.is_file() or executable.suffix.lower() in {'.bat', '.cmd', '.sh'}:
        raise ManagementError('Select the MariaDB dump program' if export else 'Select the MariaDB SQL client')
    database = settings.get('DB_NAME', '')
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,63}', database):
        raise ManagementError('Use a database name containing letters, numbers and underscores')
    with tempfile.TemporaryDirectory(prefix='pyxaseco-sql-') as directory:
        options = Path(directory) / 'client.cnf'
        def quoted(value):
            return '"' + str(value).replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r') + '"'
        with options.open('x', encoding='utf-8') as stream:
            os.chmod(options, 0o600)
            protect_token(options)
            stream.write('[client]\ndefault-character-set=utf8mb4\n' + ''.join(key + '=' + quoted(settings.get(env, default)) + '\n'
                for key, env, default in (('host', 'DB_HOST', '127.0.0.1'), ('port', 'DB_PORT', '3306'),
                    ('user', 'DB_USER', ''), ('password', 'DB_PASSWORD', ''))))
        args = [str(executable), '--defaults-extra-file=' + str(options)]
        args += (['--single-transaction', '--skip-lock-tables', '--skip-add-locks', '--no-tablespaces',
                  '--hex-blob', '--skip-triggers', '--skip-routines', '--skip-events', database] if export else
                 ['--binary-mode', '--database=' + database])
        with Path(file).open('wb' if export else 'rb') as stream:
            if export:
                os.chmod(file, 0o600)
                protect_token(Path(file))
            process = _spawn(args, stdin=subprocess.DEVNULL if export else stream,
                stdout=stream if export else subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                shell=False, **({'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}))
            try:
                code = process.wait(timeout=1800)
            except subprocess.TimeoutExpired as exc:
                process.kill()  # Only this explicitly spawned SQL utility, never the database service.
                process.wait()
                raise ManagementError('SQL export/import timed out; inspect the new destination before retrying') from exc
            if code:
                raise ManagementError('SQL export/import failed; check the selected utility and database permissions')
        if export and not Path(file).stat().st_size:
            raise ManagementError('SQL export produced an empty file; no database backup was created')


@dataclass(frozen=True)
class CloneRequest:
    target: str
    name: str
    python: str
    environment: dict = field(repr=False)
    server_port: int = 2351
    p2p_port: int = 3451
    admin_user: str = 'root'
    admin_password: str = field(default='', repr=False)
    user_host: str = 'localhost'
    copy_records: bool = False
    dump_program: str = ''
    sql_program: str = ''
    install_libraries: bool = True
    player_password: str = field(default='', repr=False)
    spectator_password: str = field(default='', repr=False)
    validation_key: str = field(default='', repr=False)


def controller_launcher(controller, environment):
    names = ' '.join(sorted(environment))
    launcher = controller / ('StartController.bat' if os.name == 'nt' else 'StartController.sh')
    if os.name == 'nt':
        launcher.write_text('@echo off\ncd /d "%~dp0"\nfor %%V in (' + names + ') do set "%%V="\n'
            '"%~dp0.venv-pyxaseco\\Scripts\\python.exe" main.py %*\n', encoding='utf-8')
        alternate = controller / 'PyXaseco.bat'
    else:
        launcher.write_text('#!/bin/sh\ncd -- "$(dirname -- "$0")" || exit 1\nunset ' + names + '\nexec .venv-pyxaseco/bin/python main.py "$@"\n')
        launcher.chmod(0o700)
        alternate = controller / 'PyXaseco.sh'
    shutil.copy2(launcher, alternate)
    return launcher


class InstanceTools:
    def __init__(self, backend):
        self.backend = backend

    def clone_preview(self, instance, request):
        root, target = server_root(instance), safe_path(request.target)
        if Path(instance.config).resolve() != (Path(instance.controller) / 'config.toml').resolve():
            raise ManagementError('Duplication currently supports the standard controller config.toml with optional .env overrides')
        if not target.parent.is_dir() or target.exists() or target.is_relative_to(root) or root.is_relative_to(target):
            raise ManagementError('Choose a new folder outside the original instance under an existing parent')
        stem = server_file_stem(request.name)
        env = request.environment
        required = ('TM_PASSWORD', 'DEDI_LOGIN', 'DEDI_PASSWORD', 'DB_NAME', 'DB_USER')
        if any(not isinstance(env.get(key), str) or not env[key].strip() for key in required):
            raise ManagementError('Provide new server-account, XML-RPC and database settings')
        for key, value in env.items():
            edit_dotenv(key + '=\n', (key,), value)
        previous = database_settings(instance)
        if env['DB_NAME'].casefold() == previous['DB_NAME'].casefold() or env['DB_USER'].casefold() == previous['DB_USER'].casefold():
            raise ManagementError('Use a different database name and database user from the original')
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,63}', env['DB_NAME']) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,31}', env['DB_USER']):
            raise ManagementError('Database/user names must start with a letter and contain letters, digits or underscores')
        if env['DB_USER'].lower() in {'root', 'admin', 'mysql', 'mariadb'} or not request.admin_user:
            raise ManagementError('Provide a fresh instance database user and a database administrator')
        if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,253}', request.user_host) or not 1 <= int(env.get('DB_PORT') or 3306) <= 65535:
            raise ManagementError('Provide a valid database port and explicit user host (no wildcard)')
        ports = (request.server_port, request.p2p_port, int(env.get('TM_PORT', '0')))
        if any(not 1 <= port <= 65535 for port in ports) or len(set(ports)) != 3:
            raise ManagementError('Choose three distinct game, P2P and XML-RPC ports')
        cfg = root / 'GameData/Config/dedicated_cfg.txt'
        import xml.etree.ElementTree as ET
        xml = ET.parse(cfg).getroot()
        if env['DEDI_LOGIN'].casefold() == str(xml.findtext('masterserver_account/login') or '').casefold():
            raise ManagementError('Provide a different TrackMania server-account login')
        old_ports = [int(xml.findtext('system_config/' + key) or '0')
                     for key in ('server_port', 'server_p2p_port', 'xmlrpc_port')]
        if any(port in old_ports for port in ports):
            raise ManagementError('New ports must not reuse any of the original server ports')
        profile = self.backend.launch_profile(instance)
        if not profile.dedicated_executable or Path(profile.dedicated_executable).parent.resolve() != root:
            raise ManagementError('Register the dedicated executable inside this instance before duplicating it')
        executable = safe_path(profile.dedicated_executable)
        if profile.dedicated_launcher:
            script = Path(profile.dedicated_launcher)
            if script.stat().st_size > 65536:
                raise ManagementError('Source launcher exceeds the review limit')
            launch = script.read_text(encoding='utf-8', errors='replace')
            arguments = re.findall(r'/(?:dedicated_cfg|game_settings)=(?:"[^"]*"|\S+)', launch, re.I)
        else:
            arguments = profile.dedicated_args
        expected_files = {'dedicated_cfg': 'dedicated_cfg.txt', 'game_settings': 'MatchSettings/MatchSettings.txt'}
        for argument in arguments:
            key, separator, value = argument.lstrip('/').partition('=')
            if separator and key.lower() in expected_files and value.strip('"').replace('\\', '/').casefold() != expected_files[key.lower()].casefold():
                raise ManagementError('Duplication currently requires the default dedicated_cfg.txt and MatchSettings/MatchSettings.txt launch paths; custom paths are not guessed')
        if not executable.is_file() or not (root / 'GameData/Tracks/MatchSettings/MatchSettings.txt').is_file():
            raise ManagementError('Dedicated executable or default MatchSettings is missing')
        for other in self.backend.instances():
            if other.id != instance.id and Path(other.controller).resolve().is_relative_to(root):
                raise ManagementError('The source folder contains another instance; choose an isolated server folder')
            if other.name.casefold() == request.name.casefold():
                raise ManagementError('That instance name is already registered')
            from pyxaseco.management.instances import configured_endpoint
            if configured_endpoint(Path(other.controller))[1] in ports:
                raise ManagementError('A registered instance already uses one of these ports for XML-RPC')
            other_cfg = Path(other.controller).parent / 'GameData/Config/dedicated_cfg.txt'
            if other_cfg.is_file():
                other_xml = ET.parse(other_cfg).getroot()
                if any(int(other_xml.findtext('system_config/' + key) or '0') in ports
                       for key in ('server_port', 'server_p2p_port', 'xmlrpc_port')):
                    raise ManagementError('A registered dedicated server already uses one of these ports')
        from .discovery import probe_python
        python = probe_python(request.python, require_venv=True)['python']
        if Path(python).resolve().is_relative_to(root):
            raise ManagementError('Choose a shared/base Python outside the original server folder')
        if request.copy_records and not all(Path(path).is_file() for path in (request.dump_program, request.sql_program)):
            raise ManagementError('Select both a MariaDB dump program and SQL client to copy records')
        files = inventory(root, clone=True, controller=Path(instance.controller))
        details = {'request': asdict(request), 'source': asdict(instance), 'files': files,
                   'registry': revision(self.backend.registry.path.read_bytes()), 'executable': str(executable)}
        return {'review': revision(json.dumps(details, sort_keys=True).encode()), 'source': str(root),
                'target': str(target), 'name': stem, 'python': python, 'files': len(files),
                'source_executable': str(executable),
                'bytes': sum(size for _name, size, _stamp in files), 'database': env['DB_NAME'],
                'database_user': env['DB_USER'], 'copy_records': request.copy_records, 'ports': ports,
                'started': False, 'warnings': ['Custom app/API credentials remain copied; review Discord, provider and custom database settings.',
                    'Root/controller launch scripts are regenerated, not copied; OS services are not duplicated.',
                    'Logs, virtual environments, local runtime state and old management credentials are excluded.',
                    'New files/database/user are retained if a later step fails; the original is never changed.']}

    def clone(self, instance, request, reviewed):
        root = server_root(instance)
        target = safe_path(request.target)
        with file_lock(target.parent / '.pyxaseco-duplicate.lock'):
            plan = self.clone_preview(instance, request)
            if plan['review'] != reviewed:
                raise ManagementError('Duplication inputs/source changed; review again')
            stage = target.parent / ('.pyxaseco-duplicate-' + uuid4().hex)
            stage.mkdir(mode=0o700)
            published = False
            try:
                source_controller = Path(instance.controller)
                files = inventory(root, clone=True, controller=source_controller)
                for current, dirs, _names in os.walk(root, followlinks=False):
                    dirs[:] = [name for name in dirs if not clone_excluded_directory(name, Path(current) in (root, source_controller))]
                    for name in dirs:
                        path = safe_path(Path(current) / name)
                        (stage / path.relative_to(root)).mkdir(parents=True, exist_ok=True)
                for name, size, stamp in files:
                    source, destination = safe_path(root / name), stage / name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, destination)
                    if (source.stat().st_size, source.stat().st_mtime_ns) != (size, stamp):
                        raise ManagementError('Source changed while copying; review again')
                if inventory(root, clone=True, controller=source_controller) != files:
                    raise ManagementError('Source changed while copying; review again')
                relative = Path(instance.controller).relative_to(root)
                controller = stage / relative
                env_file = controller / '.env'
                text = env_file.read_bytes().decode('utf-8') if env_file.exists() else ''
                environment = {**request.environment, 'DB_HOST': request.environment.get('DB_HOST') or '127.0.0.1',
                               'DB_PORT': request.environment.get('DB_PORT') or '3306',
                               'TM_LOGIN': 'SuperAdmin', 'TM_IP': '127.0.0.1'}
                for key, value in environment.items():
                    if key not in read_dotenv(env_file):
                        text += ('\n' if text and not text.endswith('\n') else '') + key + '=\n'
                    text = edit_dotenv(text, (key,), value)
                env_file.write_text(text, encoding='utf-8')
                protect_token(env_file)
                for table, mapping in (('tmserver', {'login': 'TM_LOGIN', 'password': 'TM_PASSWORD', 'ip': 'TM_IP', 'port': 'TM_PORT'}),
                                       ('database', {key: 'DB_' + key.upper() for key in ('host', 'port', 'name', 'user', 'password')}),
                                       ('dedimania', {'login': 'DEDI_LOGIN', 'password': 'DEDI_PASSWORD'})):
                    for key, name in mapping.items():
                        value = environment.get(name, '')
                        update_toml_table_scalar(controller / 'config.toml', (table,), key,
                                                 int(value) if key == 'port' else value)
                new_name = server_file_stem(request.name)
                old_executable = Path(plan['source_executable'])
                native = new_name + ('.exe' if os.name == 'nt' else '')
                for file in list(stage.iterdir()):
                    prefix = next((value for value in (old_executable.stem, 'TrackmaniaServer')
                                   if file.name.casefold().startswith(value.casefold())), None)
                    if file.is_file() and prefix:
                        renamed = stage / (native if file.name == old_executable.name else new_name + file.name[len(prefix):])
                        if renamed != file:
                            if renamed.exists():
                                raise ManagementError('Duplicate server filename collides with another copied file')
                            file.rename(renamed)
                (stage / (new_name + ('.bat' if os.name == 'nt' else '.sh'))).write_bytes(_launch_script(new_name))
                _configure_dedicated(stage, InstallRequest('', '', str(target), new_name, plan['python'],
                    environment=environment, server_port=request.server_port, p2p_port=request.p2p_port,
                    dedicated_settings={'server_options/password': request.player_password,
                        'server_options/password_spectator': request.spectator_password,
                        'masterserver_account/validation_key': request.validation_key}))
                protect_token(stage / 'GameData/Config/dedicated_cfg.txt')
                initialize_bridge(controller, enable=(controller / 'apps/management_bridge/app.py').is_file(), offline=True)
                # Prepare safe launchers before publication, including partial-install cases.
                controller_launcher(controller, environment)
                if os.name != 'nt':
                    (stage / (new_name + '.sh')).chmod(0o700)
                dump = stage / '.source-records.sql'
                if request.copy_records:
                    sql_transfer(database_settings(instance), dump, request.dump_program, export=True)
                for backups in stage.rglob('.management-backups'):
                    safe_path(backups)
                    inventory(backups)
                    shutil.rmtree(backups)
                if target.exists():
                    raise ManagementError('Destination appeared while copying; nothing was replaced')
                stage.rename(target)
                published = True
                controller = target / relative
                venv = controller / '.venv-pyxaseco'
                _run([plan['python'], '-I', '-m', 'venv', str(venv)], timeout=120)
                python = venv / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
                libraries = ensure_dependencies(python, controller / 'requirements.txt', install=request.install_libraries)
                if not libraries.get('ready'):
                    raise ManagementError('New isolated environment is missing libraries; repair it before starting')
                database_action(python, {**environment, 'DB_USER_HOST': request.user_host}, create=True,
                    admin_user=request.admin_user, admin_password=request.admin_password,
                    schema=controller / 'database/pyxaseco_default_schema.sql')
                if request.copy_records:
                    try:
                        sql_transfer(environment, target / dump.name, request.sql_program, export=False)
                    finally:
                        (target / dump.name).unlink(missing_ok=True)
                item = self.backend.register(controller, request.name, str(python), str(target / native))
                launcher = controller / ('StartController.bat' if os.name == 'nt' else 'StartController.sh')
                from .processes import LaunchProfile
                profile = LaunchProfile(controller_launcher=str(launcher), dedicated_executable=str(target / native),
                    dedicated_launcher=str(target / (new_name + ('.bat' if os.name == 'nt' else '.sh'))))
                self.backend.save_launchers(item, profile, reviewed=profile.review(item)['review'])
                return {'instance': item.id, 'folder': str(target), 'database': environment['DB_NAME'],
                        'records_copied': request.copy_records, 'started': False}
            except Exception as exc:
                if published:
                    raise ManagementError('Duplication stopped after creating the new folder. Nothing started. '
                        'Inspect the new folder/database/user before retrying; the original is unchanged.') from exc
                raise
            finally:
                if published and request.copy_records:
                    safe_path(target / '.source-records.sql').unlink(missing_ok=True)
                if stage.exists():
                    # Only this operation's verified private staging directory is removed.
                    safe_path(stage)
                    inventory(stage)
                    if stage.parent == target.parent and stage.name.startswith('.pyxaseco-duplicate-'):
                        shutil.rmtree(stage)

    def backup(self, instance, destination, *, allow_live=False, include_database=False, dump_program=''):
        root, destination = server_root(instance), safe_path(destination)
        if destination.is_relative_to(root) or destination.exists() or not destination.parent.is_dir() or destination.suffix.lower() != '.zip':
            raise ManagementError('Choose a new ZIP file outside the server folder')
        status = self.backend.poll(instance)
        states = status.get('services', {})
        stopped = not status.get('online') and all(states.get(key, {}).get('state') == 'stopped' for key in ('controller', 'dedicated'))
        if not stopped and not allow_live:
            raise ManagementError('Server state is running or unknown. Stop it, or explicitly allow a possibly inconsistent snapshot')
        files = inventory(root)
        temporary = destination.parent / ('.pyxaseco-backup-' + uuid4().hex + '.zip')
        try:
            with temporary.open('xb') as stream:
                os.chmod(temporary, 0o600)
                protect_token(temporary)
                with tempfile.TemporaryDirectory(prefix='pyxaseco-backup-sql-') as directory:
                    dump = Path(directory) / 'database.sql'
                    if include_database:
                        sql_transfer(database_settings(instance), dump, dump_program, export=True)
                    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
                        for current, dirs, _names in os.walk(root, followlinks=False):
                            for directory_name in dirs:
                                path = safe_path(Path(current) / directory_name)
                                archive.write(path, root.name + '/' + path.relative_to(root).as_posix() + '/')
                        for name, size, stamp in files:
                            file = safe_path(root / name)
                            archive.write(file, root.name + '/' + name)
                            if not allow_live and (file.stat().st_size, file.stat().st_mtime_ns) != (size, stamp):
                                raise ManagementError('Server files changed during backup; no ZIP was published')
                        if include_database:
                            archive.write(dump, '__pyxaseco_backup__/database.sql')
                        archive.writestr('__pyxaseco_backup__/manifest.json', json.dumps({
                            'instance': instance.name, 'folder': root.name, 'created_utc': datetime.now(timezone.utc).isoformat(),
                            'files': len(files), 'database_included': include_database, 'live_snapshot': not stopped,
                            'warning': 'Contains credentials. SQL covers tables/data, not database users, routines, events or triggers.'}, indent=2))
            if not allow_live and inventory(root) != files:
                raise ManagementError('Server files changed during backup; no ZIP was published')
            # Hard-link publication refuses overwriting a file created by another process.
            if os.name == 'nt':
                temporary.rename(destination)  # Windows rename refuses an existing destination, including on USB/SMB.
            else:
                os.link(temporary, destination)
            return {'zip': str(destination), 'files': len(files), 'database_included': include_database,
                    'live_snapshot': not stopped, 'bytes': destination.stat().st_size}
        finally:
            temporary.unlink(missing_ok=True)
