"""Bounded Qt work dispatch. Worker results never update widgets directly."""

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal, Slot

from pyxaseco.management.config_store import ManagementError


class _Signals(QObject):
    finished = Signal(str, object, object)


class _Task(QRunnable):
    def __init__(self, key, function, signals):
        super().__init__()
        self.key, self.function, self.signals = key, function, signals

    @Slot()
    def run(self):
        try:
            value, error = self.function(), None
        except Exception as exc:
            value = None
            error = str(exc) if isinstance(exc, ManagementError) else f'Operation failed ({type(exc).__name__}); check access, paths and input.'
        self.signals.finished.emit(self.key, value, error)


class WorkQueue(QObject):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(4)
        self.foreground = QThreadPool(self)
        self.foreground.setMaxThreadCount(2)
        self.signals = _Signals(self)
        self.signals.finished.connect(self._finished)
        self.pending = {}
        self.closing = False

    def submit(self, key, function, callback, *, priority=0):
        if self.closing or key in self.pending or len(self.pending) >= 24:
            return False
        self.pending[key] = callback
        pool = self.foreground if priority > 0 else self.pool
        pool.start(_Task(key, function, self.signals), priority)
        return True

    @Slot(str, object, object)
    def _finished(self, key, value, error):
        callback = self.pending.pop(key, None)
        if not self.closing and callback:
            callback(value, error)

    def close(self):
        self.closing = True
        self.pool.clear()
        self.foreground.clear()
        self.pending.clear()
        # Finish bounded in-flight reads before Qt destroys their signal owner.
        # This does not stop controller/server processes or replay any operation.
        self.pool.waitForDone()
        self.foreground.waitForDone()
