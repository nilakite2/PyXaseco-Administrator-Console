"""Review-first duplication and backup dialogs for one selected instance."""

import json
import os
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QTabWidget, QVBoxLayout, QWidget)

from .discovery import discover_python
from .instance_tools import CloneRequest, database_settings, server_root, sql_tool
from .theme import STYLE
from .workers import WorkQueue


class InstanceDialog(QDialog):
    def __init__(self, backend, instance, parent=None):
        super().__init__(parent)
        self.backend, self.instance = backend, instance
        self.work, self.busy = WorkQueue(self), False
        if parent is not None:
            self.setWindowIcon(parent.windowIcon())
        self.setStyleSheet(STYLE)
        self.resize(760, 680)
        self.layout = QVBoxLayout(self)

    def notice(self, text):
        label = QLabel(text)
        label.setTextFormat(Qt.TextFormat.PlainText)
        label.setWordWrap(True)
        self.layout.addWidget(label)

    def field(self, form, caption, value='', *, password=False, folder=False, file=False):
        edit = QLineEdit(value)
        if password:
            edit.setEchoMode(QLineEdit.EchoMode.Password)
        if folder or file:
            row = QHBoxLayout()
            row.addWidget(edit)
            pick = QPushButton('Browse')
            def browse():
                chosen = (QFileDialog.getExistingDirectory(self, 'Choose existing parent folder') if folder else
                          QFileDialog.getOpenFileName(self, 'Choose program')[0])
                if chosen:
                    edit.setText(str(Path(chosen) / self.fields['name'].text()) if folder else chosen)
            pick.clicked.connect(browse)
            row.addWidget(pick)
            form.addRow(caption, row)
        else:
            form.addRow(caption, edit)
        return edit

    def buttons(self, primary, callback):
        row = QHBoxLayout()
        self.go = QPushButton(primary)
        self.go.setObjectName('primary')
        self.go.clicked.connect(callback)
        close = QPushButton('Close')
        close.clicked.connect(self.reject)
        row.addWidget(self.go)
        row.addWidget(close)
        self.layout.addLayout(row)

    def reject(self):
        if not self.busy:
            self.work.close()
            super().reject()

    def closeEvent(self, event):
        if self.busy:
            event.ignore()
        else:
            self.work.close()
            event.accept()


class DuplicateDialog(InstanceDialog):
    def __init__(self, backend, instance, parent=None):
        super().__init__(backend, instance, parent)
        self.setWindowTitle('Duplicate instance - ' + instance.name)
        self.notice('Copy apps, maps and configuration into a new instance. The original stays untouched; nothing starts automatically. '
                    'Use a new database/user. Review copied API/Discord and custom database settings before starting.')
        self.fields, self.review = {}, None
        self.tabs = QTabWidget()
        self.layout.addWidget(self.tabs)
        for title, entries in (
            ('Instance', [('name', 'New instance name', instance.name + ' Copy'), ('target', 'New folder', ''),
                          ('python', 'Python (detected; shared/base installation)', '')]),
            ('Server', [('DEDI_LOGIN', 'New TrackMania account login', ''), ('DEDI_PASSWORD', 'New TrackMania account password', ''),
                        ('TM_PASSWORD', 'New SuperAdmin / XML-RPC password', ''), ('TM_PORT', 'XML-RPC port', ''),
                        ('server_port', 'Game port', ''), ('p2p_port', 'P2P port', ''),
                        ('player_password', 'Player password (blank = none)', ''),
                        ('spectator_password', 'Spectator password (blank = none)', ''), ('validation_key', 'New account validation key (optional)', '')]),
            ('Database', [('DB_HOST', 'Database host', '127.0.0.1'), ('DB_PORT', 'Database port', '3306'),
                          ('DB_NAME', 'New database name', ''), ('DB_USER', 'New database user', ''),
                          ('DB_PASSWORD', 'New database password (optional)', ''), ('admin_user', 'Database administrator', 'root'),
                          ('admin_password', 'Administrator password (optional; not saved)', ''), ('user_host', 'New user allowed host', 'localhost')]),
            ('Options', [('dump_program', 'MariaDB dump program (copy records only)', ''),
                         ('sql_program', 'MariaDB SQL client (copy records only)', '')]),
        ):
            page = QWidget()
            form = QFormLayout(page)
            self.tabs.addTab(page, title)
            for key, caption, value in entries:
                self.fields[key] = self.field(form, caption, value, password=('PASSWORD' in key or 'password' in key or key == 'validation_key'),
                    folder=key == 'target', file=key in {'python', 'dump_program', 'sql_program'})
            if title == 'Options':
                self.copy_records = QCheckBox('Also copy existing database records (off = fresh empty database)')
                self.libraries = QCheckBox('Install required libraries into the new isolated Python environment (may download)')
                self.libraries.setChecked(True)
                form.addRow(self.copy_records)
                form.addRow(self.libraries)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setMaximumHeight(160)
        self.layout.addWidget(self.output)
        self.buttons('Review duplicate', self.prepare)
        self.apply_button = QPushButton('Create reviewed duplicate')
        self.apply_button.setEnabled(False)
        self.apply_button.clicked.connect(self.apply)
        self.layout.addWidget(self.apply_button)
        self.tabs.setEnabled(False)
        self.go.setEnabled(False)
        self.output.setPlainText('Detecting Python and suggesting unused ports...')
        for edit in self.fields.values():
            edit.textChanged.connect(self.invalidate)
        self.copy_records.toggled.connect(self.invalidate)
        self.libraries.toggled.connect(self.invalidate)
        def defaults():
            root = server_root(instance)
            db = database_settings(instance)
            xml = ET.parse(root / 'GameData/Config/dedicated_cfg.txt').getroot()
            used = set()
            for item in backend.instances():
                file = Path(item.controller).parent / 'GameData/Config/dedicated_cfg.txt'
                if file.is_file():
                    tree = ET.parse(file).getroot()
                    used.update(int(tree.findtext('system_config/' + key) or '0')
                                for key in ('server_port', 'server_p2p_port', 'xmlrpc_port'))
            ports = []
            for key, fallback in (('xmlrpc_port', 5000), ('server_port', 2350), ('server_p2p_port', 3450)):
                value = int(xml.findtext('system_config/' + key) or str(fallback)) + 1
                while value in used or value in ports:
                    value += 1
                ports.append(value)
            python = discover_python([instance.python] if not Path(instance.python).resolve().is_relative_to(root) else [], require_venv=True)
            return dict(target=str(root.parent / (instance.name + ' Copy')), python=python['python'] if python else '',
                        DB_HOST=db['DB_HOST'], DB_PORT=db['DB_PORT'], TM_PORT=str(ports[0]), server_port=str(ports[1]),
                        p2p_port=str(ports[2]), dump_program=sql_tool('dump'), sql_program=sql_tool('client'))
        def loaded(value, error):
            self.tabs.setEnabled(True)
            self.go.setEnabled(True)
            if error:
                self.output.setPlainText(error)
            else:
                for key, text in value.items():
                    if not self.fields[key].text() or key in {'DB_HOST', 'DB_PORT'}:
                        self.fields[key].setText(text)
                self.output.setPlainText('Provide the new account, passwords, database name and user, then review. Nothing has been changed.')
        self.work.submit('duplicate-defaults', defaults, loaded)

    def invalidate(self, *_args):
        self.review = None
        self.apply_button.setEnabled(False)

    def collect(self):
        values = {key: edit.text() for key, edit in self.fields.items()}
        return CloneRequest(**{key: values[key] for key in ('target', 'name', 'python', 'admin_user', 'admin_password', 'user_host',
            'dump_program', 'sql_program', 'player_password', 'spectator_password', 'validation_key')},
            server_port=int(values['server_port']), p2p_port=int(values['p2p_port']),
            environment={key: value for key, value in values.items() if key.startswith(('DB_', 'TM_', 'DEDI_'))},
            copy_records=self.copy_records.isChecked(), install_libraries=self.libraries.isChecked())

    def prepare(self):
        try:
            request = self.collect()
        except ValueError:
            self.output.setPlainText('Enter valid port numbers.')
            return
        self.busy = True
        self.tabs.setEnabled(False)
        self.go.setEnabled(False)
        self.apply_button.setEnabled(False)
        def done(value, error):
            self.busy = False
            self.tabs.setEnabled(True)
            self.go.setEnabled(True)
            self.review = (request, value['review']) if not error else None
            self.apply_button.setEnabled(not error)
            if error:
                self.output.setPlainText(error)
            else:
                source, target = Path(value['source']), Path(value['target'])
                destination = target.name if target.parent == source.parent else str(target)
                self.output.setPlainText('Parent: ' + str(source.parent) + '\nCopy: ' + source.name + ' -> ' + destination +
                    f'\nFiles: {value["files"]} | Size: {value["bytes"] / (1024 * 1024):.1f} MB'
                    '\nPorts (game / P2P / XML-RPC): ' + ' / '.join(map(str, (value['ports'][0], value['ports'][1], value['ports'][2]))) +
                    '\nNew database: ' + value['database'] + ' | User: ' + value['database_user'] +
                    '\nRecords: ' + ('copy tables/data from source' if value['copy_records'] else 'empty database; no records copied') +
                    '\nNothing starts automatically.\n\n' + '\n'.join(value['warnings']))
        self.work.submit('duplicate-review', lambda: self.backend.instance_tools().clone_preview(self.instance, request), done, priority=1)

    def apply(self):
        if not self.review or self.busy:
            return
        if QMessageBox.question(self, 'Create duplicate?',
                'Create the reviewed files, isolated Python environment, new database and scoped user?\n'
                'Partial new resources are retained on failure. The original is not changed; nothing starts.') != QMessageBox.StandardButton.Yes:
            return
        request, stamp = self.review
        self.busy = True
        self.tabs.setEnabled(False)
        self.go.setEnabled(False)
        self.apply_button.setEnabled(False)
        self.output.setPlainText('Creating duplicate. Large map folders and library installation can take several minutes...')
        def done(value, error):
            self.busy = False
            self.tabs.setEnabled(True)
            self.go.setEnabled(True)
            self.review = None
            self.fields['admin_password'].clear()
            self.output.setPlainText(error or json.dumps(value, indent=2))
        self.work.submit('duplicate-apply', lambda: self.backend.instance_tools().clone(self.instance, request, stamp), done, priority=1)


class BackupDialog(InstanceDialog):
    def __init__(self, backend, instance, parent=None):
        super().__init__(backend, instance, parent)
        self.setWindowTitle('Create backup ZIP - ' + instance.name)
        self.resize(730, 440)
        self.notice('The ZIP contains the complete server folder, including credentials. Store it securely. '
                    'Database records require the optional SQL export. No server is stopped or restarted automatically.')
        form = QFormLayout()
        self.destination = QLineEdit()
        row = QHBoxLayout()
        row.addWidget(self.destination)
        browse = QPushButton('Save as...')
        browse.clicked.connect(lambda: self.choose())
        row.addWidget(browse)
        form.addRow('Backup ZIP (outside server folder)', row)
        self.dump = self.field(form, 'MariaDB dump program (SQL export only)', '', file=True)
        self.layout.addLayout(form)
        self.sql = QCheckBox('Include database tables and records using .env/TOML credentials')
        self.live = QCheckBox('Allow a running/unknown-state snapshot (files and SQL may not represent one consistent point)')
        self.layout.addWidget(self.sql)
        self.layout.addWidget(self.live)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.layout.addWidget(self.output)
        self.buttons('Create backup ZIP', self.create)
        self.work.submit('find-dump', lambda: sql_tool('dump'),
                         lambda value, error: self.dump.setText(value) if not error and not self.dump.text() else None)

    def choose(self):
        from datetime import datetime
        name = re.sub(r'[^A-Za-z0-9_.-]', '_', self.instance.name)
        path = QFileDialog.getSaveFileName(self, 'Save backup', name + '-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '.zip', 'ZIP archive (*.zip)')[0]
        if path:
            self.destination.setText(path)

    def create(self):
        destination, include_sql, live, program = self.destination.text(), self.sql.isChecked(), self.live.isChecked(), self.dump.text()
        if not destination:
            self.output.setPlainText('Choose a ZIP destination first.')
            return
        self.busy = True
        self.go.setEnabled(False)
        self.output.setPlainText('Creating backup. Large server folders and SQL exports can take several minutes...')
        def done(value, error):
            self.busy = False
            self.go.setEnabled(True)
            self.output.setPlainText(error or json.dumps(value, indent=2))
        self.work.submit('backup-apply', lambda: self.backend.instance_tools().backup(self.instance, destination,
            allow_live=live, include_database=include_sql, dump_program=program), done, priority=1)
