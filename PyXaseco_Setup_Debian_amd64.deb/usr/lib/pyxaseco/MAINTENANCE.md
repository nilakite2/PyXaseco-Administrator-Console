# Stage F: Program Maintenance

Implemented 2026-10-19 and included in the unsigned 1.3 production release. This
documents filesystem/recovery behavior, not certification of every clean-host,
service-account, reboot or Linux deployment; see the release validation scope.

## Use

Select one installation in the console, open **Services**, then **Program maintenance**.
Choose Upgrade, Adopt baseline, Rollback or Uninstall. Review the paths/conflicts,
then confirm the exact operation. The controller must already be stopped; these
operations never stop/start services automatically and never update all servers.

The same backend works headlessly, with no Qt:

```sh
python -B -m pyxaseco.management.maintenance --registry INVENTORY --instance ID upgrade --payload RELEASE.zip --sha256 TRUSTED_SHA256
python -B -m pyxaseco.management.maintenance --registry INVENTORY --instance ID upgrade --payload RELEASE.zip --sha256 TRUSTED_SHA256 --apply REVIEW_HASH
python -B -m pyxaseco.management.maintenance --registry INVENTORY --instance ID transactions
python -B -m pyxaseco.management.maintenance --registry INVENTORY --instance ID rollback --transaction TRANSACTION_ID
```

Rollback also requires `--apply REVIEW_HASH` from its preview to make changes.
The headless package's entrypoint supports `maintain` followed by these arguments,
for example `python install.py maintain --registry ... --instance ... transactions`.
Use an external management copy/packaged GUI for recovery if target program files
are missing. Do not rely on importing a partially removed controller's own modules.

## Ownership And Preservation

Fresh installations now write a schema-2 ownership receipt (`installation.json`):
installation ID/root, release inventory/hashes and replaceable program-file hashes.
It contains no passwords. It is local bookkeeping, not publisher authentication.

- Upgrade replaces/deletes only unchanged, recorded program files. Local code
  changes, missing owned code and unowned collisions block the entire preview.
  There is no force-overwrite or automatic merge option.
- Existing TOML files, including UI defaults, and intentionally deleted old config
  files stay as they are. Incoming defaults go under that transaction's `defaults/`
  folder for review. A genuinely new default can be installed only at a new path.
  New settings are not silently merged; review any required config changes before
  restarting. Changed requirements are not installed automatically either.
- New release apps cannot take over a pre-existing custom app folder/name.
  Custom code/files outside the release inventory are neither adopted nor removed.
  Incoming app metadata is checked against the retained loadout/dependencies without
  importing or executing apps; a removed/invalid enabled app blocks the upgrade.
- Uninstall removes unchanged owned program files only. Modified program files
  are retained and reported. `.env`, TOML, maps, dedicated executables/configs,
  databases, logs, replays, record state, custom apps, venv, bridge credentials,
  inventory identity and recovery backups remain. The folder is deliberately not
  recursively deleted. Empty directories and coordination lock files can remain.
- Uninstall refuses a registered controller OS service, including a stopped one.
  Explicit service deregistration is separate; this implementation does not claim
  to perform it. Upgrade requires registered services to be confirmed stopped.
  Failed/unknown OS status is not treated as absence. Dedicated services are not
  modified. The runtime OS lock also rejects an interactive controller still running.

The registry entry remains after uninstall so the retained transaction can be
rolled back. It is not a running/healthy installation merely because it is listed.
Until rollback, app/config operations that require program files can be unavailable.

## Older Installations

Stage E receipts did not record owned files. They must be explicitly **adopted**
against their original trusted payload ZIP/SHA256, not blindly treated as owned.
The preview lists exact matching code and unmatched/unowned files; apply writes
only an ownership receipt. Existing settings are never normalized or overwritten.

The controller needs the management runtime-lock entrypoint. Untouched older
controllers without it cannot be safely adopted here. A schema-2 receipt cannot
be reset through adoption to bypass local-change conflicts. Keep the original
payload when packaging/installing releases; a new release is not a substitute for
the baseline used to establish ownership. Resolve local code differences manually.

## Interrupted Operations / Rollback

Management creates `.management-maintenance/` only when an operation is applied.
It stores private per-transaction backups, JSON inventory/state and incoming defaults.
This is optional installer recovery bookkeeping, not a runtime SQLite database,
record-delivery store or mandatory daemon.

Before changing program files, backups and the transaction journal are saved and
an active marker is set. Upgrade installs the new startup guard first; uninstall
removes the launcher first. A pending marker blocks new controller startup and
ordinary offline config writes until the transaction is reviewed/recovered.
Legacy baseline adoption changes metadata only; the original Stage E code does not
gain the new guard until the guarded upgrade's first program-file replacement.

Rollback verifies backup hashes and refuses to overwrite files edited since the
operation. It preserves settings edited after an upgrade. A newer committed release
must be rolled back first. If rollback itself is interrupted, review the same
transaction again and resume it; backups and the active marker remain.
Never delete the marker/backups to bypass an incomplete operation. This recovery
is tested with process/disk-error injection; sudden-power-loss/filesystem durability
and real service-recovery/reboot behavior still need OS acceptance testing.

No database rollback is performed. File rollback does not undo schema changes,
records or other data produced by a controller that was run after an upgrade.

## Remaining Stage F Work

Actual service registration/deregistration and account access, clean Windows/Linux
machines, systemd/SCM recovery/reboot, wrong-credential/occupied-port integration,
database backup/restore acceptance, code signing and distribution/license approval
remain outstanding. The portable build is still a development proof.
