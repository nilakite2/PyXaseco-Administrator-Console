"""Installed shared-tool entrypoint; never runs a controller implicitly."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    root = Path(__file__).resolve().parent
    if not args or args[0] in ('-h', '--help'):
        print('PyXaseco 1.3 management tools\n'
              '  setup         Preview/apply a fresh installation using a private JSON request\n'
              '  manage        Instance inventory, configuration, bridge and service commands\n'
              '  maintain      Ownership-checked upgrade, rollback and program removal\n'
              '  console       Open the optional Administrator Console (--setup for wizard)\n'
              '  payload-info  Show local source payload identity/location\n'
              'Add --help after a command for its arguments. No server starts automatically.')
        return 0
    action = args.pop(0)
    if action not in {'setup', 'manage', 'maintain', 'console', 'payload-info'}:
        print('Unknown command. Use --help.', file=sys.stderr)
        return 2
    try:
        payload = root / 'controller-payload.zip'
        record = json.loads((root / 'payload-build.json').read_text(encoding='utf-8'))
        if hashlib.sha256(payload.read_bytes()).hexdigest() != record['sha256']:
            raise ValueError('payload integrity')
    except (OSError, ValueError, KeyError):
        print('Installed source payload/build record is missing or changed; repair the tools package.', file=sys.stderr)
        return 2
    if action == 'payload-info':
        print(json.dumps({'payload': str(payload), **record}, indent=2))
        return 0
    if sys.version_info[0] != 3 or sys.version_info[1] < 12:
        print('The management tools require Python 3.12 or newer.', file=sys.stderr)
        return 2
    sys.path.insert(0, str(payload))
    sys.path.insert(0, str(root))
    if action == 'console':
        if sys.platform == 'win32':
            executable = root / 'PyXasecoAdministrator.exe'
            if not executable.is_file():
                print('Install the optional Administrator Console component first.', file=sys.stderr)
                return 2
            subprocess.Popen([str(executable), *args])
            return 0
        from administrator.__main__ import main as console
        sys.argv = [sys.argv[0], *args]
        return console()
    if action == 'setup':
        from pyxaseco.management.installation import main as run
    elif action == 'manage':
        from pyxaseco.management.__main__ import main as run
    else:
        from pyxaseco.management.maintenance import main as run
    return run(args)


if __name__ == '__main__':
    raise SystemExit(main())
